--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.16
-- Dumped by pg_dump version 9.5.16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: tiger; Type: SCHEMA; Schema: -; Owner: alshamelah_admin
--

CREATE SCHEMA tiger;


ALTER SCHEMA tiger OWNER TO alshamelah_admin;

--
-- Name: tiger_data; Type: SCHEMA; Schema: -; Owner: alshamelah_admin
--

CREATE SCHEMA tiger_data;


ALTER SCHEMA tiger_data OWNER TO alshamelah_admin;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: alshamelah_admin
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO alshamelah_admin;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: alshamelah_admin
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry, geography, and raster spatial types and functions';


--
-- Name: postgis_tiger_geocoder; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder WITH SCHEMA tiger;


--
-- Name: EXTENSION postgis_tiger_geocoder; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_tiger_geocoder IS 'PostGIS tiger geocoder and reverse geocoder';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account_emailaddress; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.account_emailaddress (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    verified boolean NOT NULL,
    "primary" boolean NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.account_emailaddress OWNER TO alshamelah_admin;

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.account_emailaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailaddress_id_seq OWNER TO alshamelah_admin;

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.account_emailaddress_id_seq OWNED BY public.account_emailaddress.id;


--
-- Name: account_emailconfirmation; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.account_emailconfirmation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    sent timestamp with time zone,
    key character varying(64) NOT NULL,
    email_address_id integer NOT NULL
);


ALTER TABLE public.account_emailconfirmation OWNER TO alshamelah_admin;

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.account_emailconfirmation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailconfirmation_id_seq OWNER TO alshamelah_admin;

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.account_emailconfirmation_id_seq OWNED BY public.account_emailconfirmation.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO alshamelah_admin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO alshamelah_admin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO alshamelah_admin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO alshamelah_admin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO alshamelah_admin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO alshamelah_admin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO alshamelah_admin;

--
-- Name: books_book; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.books_book (
    id integer NOT NULL,
    title character varying(100) NOT NULL,
    content text NOT NULL,
    data jsonb NOT NULL,
    author character varying(1000) NOT NULL,
    author_id integer,
    has_audio boolean NOT NULL,
    approved boolean NOT NULL,
    creation_time timestamp with time zone,
    last_update_time timestamp with time zone,
    publish_date date,
    cover_image character varying(100),
    read_count integer,
    download_count integer,
    page_count integer,
    search_count integer,
    category_id integer,
    sub_category_id integer,
    uploader_id integer,
    CONSTRAINT books_book_author_id_check CHECK ((author_id >= 0)),
    CONSTRAINT books_book_download_count_check CHECK ((download_count >= 0)),
    CONSTRAINT books_book_page_count_check CHECK ((page_count >= 0)),
    CONSTRAINT books_book_read_count_check CHECK ((read_count >= 0)),
    CONSTRAINT books_book_search_count_check CHECK ((search_count >= 0))
);


ALTER TABLE public.books_book OWNER TO alshamelah_admin;

--
-- Name: books_book_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.books_book_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.books_book_id_seq OWNER TO alshamelah_admin;

--
-- Name: books_book_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.books_book_id_seq OWNED BY public.books_book.id;


--
-- Name: books_bookcomment; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.books_bookcomment (
    id integer NOT NULL,
    comment text NOT NULL,
    page smallint NOT NULL,
    line smallint NOT NULL,
    book_id integer NOT NULL,
    user_id integer NOT NULL,
    CONSTRAINT books_bookcomment_line_check CHECK ((line >= 0)),
    CONSTRAINT books_bookcomment_page_check CHECK ((page >= 0))
);


ALTER TABLE public.books_bookcomment OWNER TO alshamelah_admin;

--
-- Name: books_bookcomment_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.books_bookcomment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.books_bookcomment_id_seq OWNER TO alshamelah_admin;

--
-- Name: books_bookcomment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.books_bookcomment_id_seq OWNED BY public.books_bookcomment.id;


--
-- Name: books_bookhighlight; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.books_bookhighlight (
    id integer NOT NULL,
    page smallint NOT NULL,
    line smallint NOT NULL,
    start integer NOT NULL,
    "end" integer NOT NULL,
    book_id integer NOT NULL,
    user_id integer NOT NULL,
    CONSTRAINT books_bookhighlight_end_check CHECK (("end" >= 0)),
    CONSTRAINT books_bookhighlight_line_check CHECK ((line >= 0)),
    CONSTRAINT books_bookhighlight_page_check CHECK ((page >= 0)),
    CONSTRAINT books_bookhighlight_start_check CHECK ((start >= 0))
);


ALTER TABLE public.books_bookhighlight OWNER TO alshamelah_admin;

--
-- Name: books_bookhighlight_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.books_bookhighlight_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.books_bookhighlight_id_seq OWNER TO alshamelah_admin;

--
-- Name: books_bookhighlight_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.books_bookhighlight_id_seq OWNED BY public.books_bookhighlight.id;


--
-- Name: books_bookmark; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.books_bookmark (
    id integer NOT NULL,
    page smallint NOT NULL,
    book_id integer NOT NULL,
    user_id integer NOT NULL,
    CONSTRAINT books_bookmark_page_check CHECK ((page >= 0))
);


ALTER TABLE public.books_bookmark OWNER TO alshamelah_admin;

--
-- Name: books_bookmark_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.books_bookmark_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.books_bookmark_id_seq OWNER TO alshamelah_admin;

--
-- Name: books_bookmark_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.books_bookmark_id_seq OWNED BY public.books_bookmark.id;


--
-- Name: books_bookmedia; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.books_bookmedia (
    id integer NOT NULL,
    type character varying(10) NOT NULL,
    url character varying(200) NOT NULL,
    approved boolean NOT NULL,
    book_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.books_bookmedia OWNER TO alshamelah_admin;

--
-- Name: books_bookmedia_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.books_bookmedia_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.books_bookmedia_id_seq OWNER TO alshamelah_admin;

--
-- Name: books_bookmedia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.books_bookmedia_id_seq OWNED BY public.books_bookmedia.id;


--
-- Name: books_bookrating; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.books_bookrating (
    id integer NOT NULL,
    rating smallint NOT NULL,
    book_id integer NOT NULL,
    user_id integer NOT NULL,
    CONSTRAINT books_bookrating_rating_check CHECK ((rating >= 0))
);


ALTER TABLE public.books_bookrating OWNER TO alshamelah_admin;

--
-- Name: books_bookrating_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.books_bookrating_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.books_bookrating_id_seq OWNER TO alshamelah_admin;

--
-- Name: books_bookrating_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.books_bookrating_id_seq OWNED BY public.books_bookrating.id;


--
-- Name: books_bookreview; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.books_bookreview (
    id integer NOT NULL,
    comment text NOT NULL,
    book_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.books_bookreview OWNER TO alshamelah_admin;

--
-- Name: books_bookreview_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.books_bookreview_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.books_bookreview_id_seq OWNER TO alshamelah_admin;

--
-- Name: books_bookreview_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.books_bookreview_id_seq OWNED BY public.books_bookreview.id;


--
-- Name: categories_category; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.categories_category (
    id integer NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.categories_category OWNER TO alshamelah_admin;

--
-- Name: categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.categories_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_category_id_seq OWNER TO alshamelah_admin;

--
-- Name: categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.categories_category_id_seq OWNED BY public.categories_category.id;


--
-- Name: categories_subcategory; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.categories_subcategory (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    category_id integer
);


ALTER TABLE public.categories_subcategory OWNER TO alshamelah_admin;

--
-- Name: categories_subcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.categories_subcategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_subcategory_id_seq OWNER TO alshamelah_admin;

--
-- Name: categories_subcategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.categories_subcategory_id_seq OWNED BY public.categories_subcategory.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO alshamelah_admin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO alshamelah_admin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO alshamelah_admin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO alshamelah_admin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO alshamelah_admin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO alshamelah_admin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO alshamelah_admin;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO alshamelah_admin;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO alshamelah_admin;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: socialaccount_socialaccount; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.socialaccount_socialaccount (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    uid character varying(191) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    extra_data text NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialaccount OWNER TO alshamelah_admin;

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.socialaccount_socialaccount_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialaccount_id_seq OWNER TO alshamelah_admin;

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.socialaccount_socialaccount_id_seq OWNED BY public.socialaccount_socialaccount.id;


--
-- Name: socialaccount_socialapp; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.socialaccount_socialapp (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    name character varying(40) NOT NULL,
    client_id character varying(191) NOT NULL,
    secret character varying(191) NOT NULL,
    key character varying(191) NOT NULL
);


ALTER TABLE public.socialaccount_socialapp OWNER TO alshamelah_admin;

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.socialaccount_socialapp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_id_seq OWNER TO alshamelah_admin;

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.socialaccount_socialapp_id_seq OWNED BY public.socialaccount_socialapp.id;


--
-- Name: socialaccount_socialapp_sites; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.socialaccount_socialapp_sites (
    id integer NOT NULL,
    socialapp_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialapp_sites OWNER TO alshamelah_admin;

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.socialaccount_socialapp_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_sites_id_seq OWNER TO alshamelah_admin;

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.socialaccount_socialapp_sites_id_seq OWNED BY public.socialaccount_socialapp_sites.id;


--
-- Name: socialaccount_socialtoken; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.socialaccount_socialtoken (
    id integer NOT NULL,
    token text NOT NULL,
    token_secret text NOT NULL,
    expires_at timestamp with time zone,
    account_id integer NOT NULL,
    app_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialtoken OWNER TO alshamelah_admin;

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.socialaccount_socialtoken_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialtoken_id_seq OWNER TO alshamelah_admin;

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.socialaccount_socialtoken_id_seq OWNED BY public.socialaccount_socialtoken.id;


--
-- Name: users_otp; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.users_otp (
    id integer NOT NULL,
    code character varying(6) NOT NULL,
    type character varying(2) NOT NULL,
    creation_time timestamp with time zone,
    last_update_time timestamp with time zone,
    verified boolean NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.users_otp OWNER TO alshamelah_admin;

--
-- Name: users_otp_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.users_otp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_otp_id_seq OWNER TO alshamelah_admin;

--
-- Name: users_otp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.users_otp_id_seq OWNED BY public.users_otp.id;


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.users_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    name character varying(50),
    phone_code character varying(50),
    phone character varying(50),
    phone_verified boolean NOT NULL,
    birthday date,
    gender character varying(1),
    membership character varying(1),
    address character varying(1000) NOT NULL,
    country character varying(100) NOT NULL,
    photo character varying(100)
);


ALTER TABLE public.users_user OWNER TO alshamelah_admin;

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.users_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_user_groups OWNER TO alshamelah_admin;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.users_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_groups_id_seq OWNER TO alshamelah_admin;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.users_user_groups_id_seq OWNED BY public.users_user_groups.id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO alshamelah_admin;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users_user.id;


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: alshamelah_admin
--

CREATE TABLE public.users_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_user_user_permissions OWNER TO alshamelah_admin;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: alshamelah_admin
--

CREATE SEQUENCE public.users_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_user_permissions_id_seq OWNER TO alshamelah_admin;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alshamelah_admin
--

ALTER SEQUENCE public.users_user_user_permissions_id_seq OWNED BY public.users_user_user_permissions.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.account_emailaddress ALTER COLUMN id SET DEFAULT nextval('public.account_emailaddress_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.account_emailconfirmation ALTER COLUMN id SET DEFAULT nextval('public.account_emailconfirmation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_book ALTER COLUMN id SET DEFAULT nextval('public.books_book_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookcomment ALTER COLUMN id SET DEFAULT nextval('public.books_bookcomment_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookhighlight ALTER COLUMN id SET DEFAULT nextval('public.books_bookhighlight_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookmark ALTER COLUMN id SET DEFAULT nextval('public.books_bookmark_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookmedia ALTER COLUMN id SET DEFAULT nextval('public.books_bookmedia_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookrating ALTER COLUMN id SET DEFAULT nextval('public.books_bookrating_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookreview ALTER COLUMN id SET DEFAULT nextval('public.books_bookreview_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.categories_category ALTER COLUMN id SET DEFAULT nextval('public.categories_category_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.categories_subcategory ALTER COLUMN id SET DEFAULT nextval('public.categories_subcategory_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.socialaccount_socialaccount ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialaccount_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.socialaccount_socialapp ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_sites_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.socialaccount_socialtoken ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialtoken_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.users_otp ALTER COLUMN id SET DEFAULT nextval('public.users_otp_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.users_user ALTER COLUMN id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.users_user_groups ALTER COLUMN id SET DEFAULT nextval('public.users_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.users_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_user_user_permissions_id_seq'::regclass);


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM stdin;
2	adhm_n4@yahoo.com	f	t	4
3	fatma1211994@hotmail.com	f	t	6
4	okaoko@ssd.com	f	t	8
5	asd@dfdf.com	f	t	9
6	moh@df.com	f	t	10
7	ism@sdfd.com	f	t	11
8	ismaosfdf@wesad.com	f	t	12
9	mohsa@dfdf.com	f	t	13
10	mohww@df.com	f	t	14
11	asad@sad.com	f	t	15
12	sdsd@ddf.com	f	t	16
13	ismad@sds.com	f	t	17
14	Ahsh@ddd.com	f	t	18
15	user@example.com	f	t	19
16	Shs@djd.com	f	t	20
17	Sjsj@dfdjdj.com	f	t	21
18	Jxjd@xnxn.com	f	t	22
19	sdhnhsh@sjk.com	f	t	23
20	Gfgh@fgh.com	f	t	24
21	Xbxbs@dhdj.com	f	t	25
22	Dhfhdh@xjdj.com	f	t	26
23	Xnxn@nxnx.com	f	t	27
24	Moh@hdhd.com	f	t	28
25	ism@ism.com	f	t	29
\.


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.account_emailaddress_id_seq', 25, true);


--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM stdin;
\.


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.account_emailconfirmation_id_seq', 1, false);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.auth_group (id, name) FROM stdin;
1	user
2	admin
3	reviewer
4	chat_admin
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 4, true);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	4	add_logentry
2	Can change log entry	4	change_logentry
3	Can delete log entry	4	delete_logentry
4	Can view log entry	4	view_logentry
5	Can add permission	5	add_permission
6	Can change permission	5	change_permission
7	Can delete permission	5	delete_permission
8	Can view permission	5	view_permission
9	Can add group	6	add_group
10	Can change group	6	change_group
11	Can delete group	6	delete_group
12	Can view group	6	view_group
13	Can add content type	7	add_contenttype
14	Can change content type	7	change_contenttype
15	Can delete content type	7	delete_contenttype
16	Can view content type	7	view_contenttype
17	Can add session	8	add_session
18	Can change session	8	change_session
19	Can delete session	8	delete_session
20	Can view session	8	view_session
21	Can add site	9	add_site
22	Can change site	9	change_site
23	Can delete site	9	delete_site
24	Can view site	9	view_site
25	Can add Token	10	add_token
26	Can change Token	10	change_token
27	Can delete Token	10	delete_token
28	Can view Token	10	view_token
29	Can add email address	11	add_emailaddress
30	Can change email address	11	change_emailaddress
31	Can delete email address	11	delete_emailaddress
32	Can view email address	11	view_emailaddress
33	Can add email confirmation	12	add_emailconfirmation
34	Can change email confirmation	12	change_emailconfirmation
35	Can delete email confirmation	12	delete_emailconfirmation
36	Can view email confirmation	12	view_emailconfirmation
37	Can add social account	13	add_socialaccount
38	Can change social account	13	change_socialaccount
39	Can delete social account	13	delete_socialaccount
40	Can view social account	13	view_socialaccount
41	Can add social application	14	add_socialapp
42	Can change social application	14	change_socialapp
43	Can delete social application	14	delete_socialapp
44	Can view social application	14	view_socialapp
45	Can add social application token	15	add_socialtoken
46	Can change social application token	15	change_socialtoken
47	Can delete social application token	15	delete_socialtoken
48	Can view social application token	15	view_socialtoken
49	Can add category	16	add_category
50	Can change category	16	change_category
51	Can delete category	16	delete_category
52	Can view category	16	view_category
53	Can add sub category	17	add_subcategory
54	Can change sub category	17	change_subcategory
55	Can delete sub category	17	delete_subcategory
56	Can view sub category	17	view_subcategory
57	Can add book	18	add_book
58	Can change book	18	change_book
59	Can delete book	18	delete_book
60	Can view book	18	view_book
61	Can add book rating	19	add_bookrating
62	Can change book rating	19	change_bookrating
63	Can delete book rating	19	delete_bookrating
64	Can view book rating	19	view_bookrating
65	Can add book comment	20	add_bookcomment
66	Can change book comment	20	change_bookcomment
67	Can delete book comment	20	delete_bookcomment
68	Can view book comment	20	view_bookcomment
69	Can add book mark	21	add_bookmark
70	Can change book mark	21	change_bookmark
71	Can delete book mark	21	delete_bookmark
72	Can view book mark	21	view_bookmark
73	Can add book highlight	22	add_bookhighlight
74	Can change book highlight	22	change_bookhighlight
75	Can delete book highlight	22	delete_bookhighlight
76	Can view book highlight	22	view_bookhighlight
77	Can add book media	1	add_bookmedia
78	Can change book media	1	change_bookmedia
79	Can delete book media	1	delete_bookmedia
80	Can view book media	1	view_bookmedia
81	Can add book audio	2	add_bookaudio
82	Can change book audio	2	change_bookaudio
83	Can delete book audio	2	delete_bookaudio
84	Can view book audio	2	view_bookaudio
85	Can add book pdf	3	add_bookpdf
86	Can change book pdf	3	change_bookpdf
87	Can delete book pdf	3	delete_bookpdf
88	Can view book pdf	3	view_bookpdf
89	Can add user	23	add_user
90	Can change user	23	change_user
91	Can delete user	23	delete_user
92	Can view user	23	view_user
93	Can add otp	24	add_otp
94	Can change otp	24	change_otp
95	Can delete otp	24	delete_otp
96	Can view otp	24	view_otp
97	Can add email otp	25	add_emailotp
98	Can change email otp	25	change_emailotp
99	Can delete email otp	25	delete_emailotp
100	Can view email otp	25	view_emailotp
101	Can add phone otp	26	add_phoneotp
102	Can change phone otp	26	change_phoneotp
103	Can delete phone otp	26	delete_phoneotp
104	Can view phone otp	26	view_phoneotp
105	View Book Marks	23	view_book_marks
106	Create Book Pdf	23	create_book_pdf
107	View Book Pdf	23	view_book_pdf
108	View Book Comments	23	view_book_comments
109	Create Book Highlights	23	create_book_highlights
110	View Book Audio	23	view_book_audio
111	Edit Book Marks	23	edit_book_marks
112	Create Book Comments	23	create_book_comments
113	Edit Password	23	edit_password
114	View Books	23	view_books
115	Verify Email	23	verify_email
116	Create Book Audio	23	create_book_audio
117	Edit Book Highlights	23	edit_book_highlights
118	Create Book Marks	23	create_book_marks
119	Create Book Ratings	23	create_book_ratings
120	Edit Book Ratings	23	edit_book_ratings
121	Edit Book Audio	23	edit_book_audio
122	Edit Book Comments	23	edit_book_comments
123	Edit Book Pdf	23	edit_book_pdf
124	View Book Highlights	23	view_book_highlights
125	View Book Ratings	23	view_book_ratings
126	Verify Phone	23	verify_phone
127	Create Books	23	create_books
128	Delete Book Highlights	23	delete_book_highlights
129	Delete Book Audio	23	delete_book_audio
130	Delete Book Marks	23	delete_book_marks
131	Delete Book Pdf	23	delete_book_pdf
132	Delete Book Ratings	23	delete_book_ratings
133	Delete Book Comments	23	delete_book_comments
134	Edit Categories	23	edit_categories
135	View Categories	23	view_categories
136	Edit Books	23	edit_books
137	Create Categories	23	create_categories
138	Delete Books	23	delete_books
139	Submit Books	23	submit_books
140	Submit Audio	23	submit_audio
141	Create Chat Room	23	create_chat_room
142	Can add book review	27	add_bookreview
143	Can change book review	27	change_bookreview
144	Can delete book review	27	delete_bookreview
145	Can view book review	27	view_bookreview
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 145, true);


--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
\.


--
-- Data for Name: books_book; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.books_book (id, title, content, data, author, author_id, has_audio, approved, creation_time, last_update_time, publish_date, cover_image, read_count, download_count, page_count, search_count, category_id, sub_category_id, uploader_id) FROM stdin;
2	الأربعون النووية	[{'text': 'بسم الله الرحمن الرحيم\\n\\nمقدمة المؤلف\\nالحمد لله رب العالمين قيوم السموات والأرضين. مدبر الخلائق أجمعين. باعث الرسل - صلواته وسلامه عليهم- إلى المكلفين لهدايتهم وبيان شرائع الدين بالدلائل القطعية، وواضحات البراهين.', 'vol': 1, 'page': 35}, {'text': 'أحمده على جميع نعمه. وأسأله المزيد من فضله وكرمه.\\nوأشهد أن لا إله إلا الله الواحد القهار. الكريم الغفار وأشهد أن سيدنا محمداً عبده ورسوله وحبيبه وخليله أفضل المخلوقين، المكرم بالقرآن العزيز المعجزة المستمرة على تعاقب السنين، وبالسنن المستنيرة للمسترشدين المخصوص بجوامع الكلم وسماحة الدين صلوات الله وسلامه عليه وعلى سائر النبيين والمرسلين وآل كل وسائر الصالحين.', 'vol': 1, 'page': 36}, {'text': 'أما بعد: فقد روينا عن علي بن أبي طالب، وعبد الله بن مسعود، ومعاذ بن جبل، وأبي الدرداء، وابن عمر، وابن عباس، وأنس بن مالك، وأبي هريرة، وأبي سعيد الخدري رضي الله تعالى عنهم من طرق كثيرات بروايات متنوعات: أن رسول الله ﷺ قال: "من حفظ على أمتي أربعين حديثاً من أمر دينها', 'vol': 1, 'page': 37}, {'text': 'بعثه الله يوم القيامة في زمرة الفقهاء والعلماء" وفي رواية: "بعثه الله فقيها عالما".\\nوفي رواية أبي الدرداء: "وكنت له يوم القيامة شافعا وشهيدا". وفي رواية ابن مسعود: قيل له: "ادخل من أي أبوب الجنة شئت" وفي رواية ابن عمر "كُتِب في زمرة العلماء وحشر في زمرة الشهداء". واتفق الحفاظ على أنه حديث ضعيف وإن كثرت طرقه.', 'vol': 1, 'page': 38}, {'text': 'وقد صنّف العلماء رضي الله تعالى عنهم في هذا الباب ما لا يُحصى من المصنّفات. فأول من علمته صنف فيه: عبد الله بن المبارك، ثم محمد بن أسلم الطوسي العالم الرباني، ثم الحسن بن سفيان النسائي، وأبو بكر', 'vol': 1, 'page': 39}, {'text': 'الآجري، وأبو بكر بن إبراهيم الأصفهاني، والدارقطني، والحاكم،', 'vol': 1, 'page': 40}, {'text': 'وأبو نعيم، وأبو عبد الرحمن السلميّ، وأبو سعيد الماليني، وأبو عثمان الصابوني، وعبد الله بن', 'vol': 1, 'page': 41}, {'text': 'محمد الأنصاري. وأبو بكر البيهقي، وخلائق لا يحصون من المتقدمين والمتأخرين، وقد استخرت الله تعالى في جمع أربعين حديثاً اقتداء بهؤلاء الأئمة الأعلام وحفاظ الإسلام. وقد اتفق العلماء على جواز العمل بالحديث الضعيف', 'vol': 1, 'page': 42}, {'text': 'في فضائل الأعمال.\\nومع هذا فليس اعتمادي على هذا الحديث، بل على قوله ﷺ في الأحاديث الصحيحة: "ليبلغ الشاهد منكم الغائب" وقوله ﷺ: "نضر الله امرأً سمع مقالتي فوعاها فأدّاها كما سمعها".\\nثم من العلماء من جمع الأربعين في أصول الدين، وبعضهم في الفروع، وبعضهم في الجهاد، وبعضهم في الزهد، وبعضهم في الآداب، وبعضهم في الخطب،', 'vol': 1, 'page': 43}, {'text': 'وكلها مقاصة صالحة رضي الله تعالى عن قاصديها.\\nقد رأيت جمع أربعين أهم من هذا كله، وهي أربعون حديثاً مشتملة على جميع ذلك، وكل حديث منها قاعدة عظيمة من قواعد الدين قد وصفه العلماء بأن مدار الإسلام عليه، أو هو نصف الإسلام أو ثلثه أو نحو ذلك.\\nثم ألتزم في هذه الأربعين أن تكون صحيحة، ومعظمها في صحيحي البخاري ومسلم،', 'vol': 1, 'page': 44}, {'text': 'وأذكرها محذوفة الأسانيد، ليسهل حفظها، ويعم الانتفاع بها إن شاء الله تعالى، ثم أُتبعها بباب في ضبط خفي ألفاظها. وينبغي لكل راغب في الآخرة أن يعرف هذه الأحاديث، لما اشتملت عليه من المهمات، واحتوت عليه من التنبيه على جميع الطاعات وذلك ظاهر لمن تدبّره، وعلى الله اعتمادي، وإليه تفويضي واستنادي وله الحمد والنعمة، وبه التوفيق والعصمة.', 'vol': 1, 'page': 45}, {'text': 'الحديث الأول\\n«عن أمير المؤمنين أبي حفص عمر بن الخطاب رضي الله تعالى عنه قال: سمعت رسول الله صلى الله تعالى عليه وعلى آله وسلم يقول: إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى، فمن كانت هجرته إلى الله ورسوله فهجرته إلى الله ورسوله، ومن كانت هجرته لدنيا يصيبها أو امرأة ينكحها فهجرته إلى ما هاجر إليه» .\\nرواه إماما المحدثين:', 'vol': 1, 'page': 46}, {'text': 'أبو عبد الله محمد ابن إسماعيل بن إبراهيم بن المغيرة بن بردزبه البخاري، وأبو الحسين مسلم ابن الحجاج بن مسلم القشيري النيسابوري: في صحيحيهما اللذين هما أصح الكتب المصنفة.', 'vol': 1, 'page': 47}, {'text': 'الحديث الثاني\\n«عن عمر رضي الله تعالى عنه أيضاً قال: بينما نحن جلوس عند رسول الله صلى الله عليه وآله وسلم ذات يوم إذ طلع علينا رجل شديد بياض الثياب شديد سواد الشعر لا يرى عليه أثر السفر ولا يعرفه منا أحد، حتى جلس إلى النبي صلى الله عليه وآله وسلم فأسند ركبتيه إلى ركبتيه ووضع كفيه على فخذيه وقال: يا محمد أخبرني عن الإسلام،', 'vol': 1, 'page': 48}, {'text': 'فقال رسول الله صلى الله عليه وآله وسلم: الإسلام أن تشهد أن لا إله إلا الله وأن محمداً رسول الله، وتقيم الصلاة، وتؤتي الزكاة، وتصوم رمضان، وتحج البيت إن استطعت إليه سبيلاً قال: صدقت، فعجبنا له يسأله ويصدقه.\\nقال: فأخبرني عن الإيمان، قال أن تؤمن بالله وملائكته وكتبه ورسله واليوم الآخر، وتؤمن بالقدر خيره وشره، قال: صدقت، قال: فأخبرني عن الإحسان، قال أن تعبد الله كأنك تراه، فإن لم تكن تراه فإنه يراك،', 'vol': 1, 'page': 49}, {'text': 'قال: فأخبرني عن الساعة، قال ما المسئول عنها بأعلم من السائل، قال: فأخبرني عن أماراتها، قال أن تلد الأمة ربتها، وأن ترى الحفاة العراة العالة رعاء الشاء يتطاولون في البنيان', 'vol': 1, 'page': 50}, {'text': 'ثم انطلق فلبثت ملياً ثم قال يا عمر أتدري من السائل؟ قلت: الله ورسوله أعلم، قال فإنه جبريل أتاكم يعلمكم دينكم» .\\nرواه مسلم.', 'vol': 1, 'page': 51}, {'text': 'الحديث الثالث\\n«عن أبي عبد الرحمن عبد الله بن عمر بن الخطاب رضي الله تعالى عنهما قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: بني الإسلام على خمس: شهادة أن لا إله إلا الله وأن محمداً رسول الله، وإقام الصلاة، وإيتاء الزكاة، وحج البيت، وصوم رمضان» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 52}, {'text': 'الحديث الرابع\\n«عن أبي عبد الرحمن عبد الله بن مسعود \\ufd41 قال: حدثنا رسول الله صلى الله عليه وآله وسلم وهو الصادق المصدوق: إن أحدكم يجمع خلقه في بطن أمه أربعين يوماً نطفة، ثم يكون علقة مثل ذلك، ثم يكون مضغة مثل ذلك، ثم يرسل إليه الملك فينفخ فيه الروح ويؤمر بأربع كلمات: بكتب رزقه، وأجله، وعمله، وشقي أو سعيد،', 'vol': 1, 'page': 53}, {'text': 'فو الله الذي لا إله غيره إن أحدكم ليعمل بعمل أهل الجنة حتى ما يكون بينه وبينها إلا ذراع فيسبق عليه الكتاب فيعمل بعمل أهل النار فيدخلها، وإن أحدكم ليعمل بعمل أهل النار حتى ما يكون بينه وبينها إلا ذراع فيسبق عليه الكتاب فيعمل بعمل أهل الجنة فيدخلها» رواه البخاري ومسلم.', 'vol': 1, 'page': 54}, {'text': 'الحديث الخامس\\n«عن أم المؤمنين أم عبد الله عائشة \\ufd42 قالت: قال رسول الله صلى الله عليه وآله وسلم: من أحدث في أمرنا هذا ما ليس منه فهو رد» .\\nرواه البخاري ومسلم.\\nوفي رواية لمسلم «من عمل عملاً ليس عليه أمرنا فهو رد» .', 'vol': 1, 'page': 55}, {'text': 'الحديث السادس\\n«عن أبي عبد الله النعمان بن بشير \\ufd44 قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: إن الحلال بين وإن الحرام بين وبينهما أمور مشتبهات لا يعلمهن كثير من الناس، فمن اتقى الشبهات فقد استبرأ لدينه وعرضه، ومن وقع في الشبهات وقع في', 'vol': 1, 'page': 56}, {'text': 'الحرام كالراعي يرعى حول الحمى يوشك أن يرتع فيه، ألا وإن لكل ملك حمى، ألا وإن حمى الله محارمه، ألا وإن في الجسد مضغة إذا صلحت صلح الجسد كله وإذا فسدت فسد الجسد كله ألا وهي القلب» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 57}, {'text': 'الحديث السابع\\n«عن أبي رقية تميم بن أوس الداري رضي الله تعالى عنه أن النبي صلى الله عليه وآله وسلم قال الدين النصيحة.\\nقلنا: لمن؟ قال لله، ولكتابه، ولرسوله، ولأئمة المسلمين وعامتهم» .\\nرواه مسلم.', 'vol': 1, 'page': 58}, {'text': 'الحديث الثامن\\n«عن ابن عمر رضي الله تعالى عنهما أن رسول الله صلى الله تعالى عليه وعلى آله وسلم قال أمرت أن أقاتل الناس حتى يشهدوا أن لا إله إلا الله وأن محمداً رسول الله، ويقيموا الصلاة، ويؤتوا الزكاة: فإذا فعلوا ذلك عصموا مني دماءهم وأموالهم إلا بحق الإسلام وحسابهم على الله تعالى» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 59}, {'text': 'الحديث التاسع\\n«عن أبي هريرة عبد الرحمن بن صخر رضي الله تعالى عنه قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول مانهيتكم عنه فاجتنبوه، وما أمرتكم به فأتوا منه ما استطعتم، فإنما أهلك الذين من قبلكم كثرة مسائلهم واختلافهم على أنبيائهم» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 60}, {'text': 'الحديث العاشر\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم: إن الله تعالى طيب لا يقبل إلا طيباً، وإن الله أمر المؤمنين بما أمر به المرسلين فقال تعالى {يا أيها الرسل كلوا من الطيبات واعملوا صالحا} وقال تعالى {يا أيها الذين آمنوا كلوا من طيبات ما رزقناكم} ثم ذكر الرجل يطيل السفر أشعث أغبر يمد يديه إلى السماء: يا رب يا رب، ومطعمه حرام', 'vol': 1, 'page': 61}, {'text': 'وملبسه حرام وغذي بالحرام فأنى يستجاب له» .\\nرواه مسلم.', 'vol': 1, 'page': 62}, {'text': 'الحديث الحادي عشر\\n«عن أبي محمد الحسن بن علي بن أبي طالب سبط رسول الله صلى الله عليه وآله وسلم وريحانته \\ufd44 قال: حفظت من رسول الله صلى الله عليه وآله وسلم دع ما يريبك إلى ما لا يريبك» .\\nرواه الترمذي والنسائي، وقال الترمذي: حديث حسن صحيح.', 'vol': 1, 'page': 63}, {'text': 'الحديث الثانى عشر\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم من حسن إسلام المرء تركه ما لا يعنيه» .\\nحديث حسن، رواه الترمذي وغيره وهكذا.', 'vol': 1, 'page': 64}, {'text': 'الحديث الثالث عشر\\n«عن أبي حمزة أنس بن مالك رضي الله تعالى عنه خادم رسول الله صلى الله عليه وآله وسلم عن النبي صلى الله عليه وآله وسلم قال لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 65}, {'text': 'الحديث الرابع عشر\\n«عن ابن مسعود رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم لا يحل دم امرئ مسلم إلا بإحدى ثلاث: الثيب الزاني، والنفس بالنفس، والتارك لدينه المفارق للجماعة» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 66}, {'text': 'الحديث الخامس عشر\\n«عن أبي هريرة رضي الله تعالى عنه أن رسول الله صلى الله عليه وآله وسلم قال: من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت، ومن كان يؤمن بالله واليوم الآخر فليكرم جاره، ومن كان يؤمن بالله واليوم الآخر فليكرم ضيفه» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 67}, {'text': 'الحديث السادس عشر\\n«عن أبي هريرة رضي الله تعالى عنه أن رجلاً قال للنبي صلى الله عليه وآله وسلم: أوصني، قال لا تغضب فردد مراراً، قال لا تغضب» .\\nرواه البخاري.', 'vol': 1, 'page': 68}, {'text': 'الحديث السابع عشر\\n«عن أبي يعلى شداد بن أوس رضي الله تعالى عنه عن رسول الله صلى الله عليه وآله وسلم قال إن الله كتب الإحسان على كل شئ، فإذا قتلتم فأحسنوا القتلة وإذا ذبحتم فأحسنوا الذبحة، وليحد أحدكم شفرته وليرح ذبيحته» .\\nرواه مسلم.', 'vol': 1, 'page': 69}, {'text': 'الحديث الثامن عشر\\n«عن أبي ذر جندب بن جنادة، وأبي عبد الرحمن معاذ بن جبل رضي الله تعالى عنهما عن رسول الله صلى الله عليه وآله وسلم قال: إتق الله حيثما كنت، وأتبع السيئة الحسنة تمحها، وخالق الناس بخلق حسن» .\\nرواه الترمذي وقال: حديث حسن، وفي بعض النسخ: حسن صحيح.', 'vol': 1, 'page': 70}, {'text': 'الحديث التاسع عشر\\n«عن أبي العباس عبد الله بن عباس رضي الله تعالى عنهما قال: كنت خلف النبي صلى الله عليه وآله وسلم يوماً فقال يا غلام، إني أعلمك كلمات: إحفظ الله يحفظك، إحفظ الله تجده تجاهك، إذا سألت فاسأل الله، وإذا استعنت فاستعن بالله، واعلم أن الأمة لو اجتمعت على أن ينفعوك بشئ لم ينفعوك إلا بشئ قد كتبه الله لك،', 'vol': 1, 'page': 71}, {'text': 'وإن اجتمعوا على أن يضروك بشئ لم يضروك إلا بشئ قد كتبه الله عليك، رفعت الأقلام وجفت الصحف» .\\nرواه الترمذي وقال حديث حسن صحيح.\\nوفي رواية غير الترمذي «إحفظ الله تجده أمامك، تعرف إلى الله في الرخاء يعرفك في الشدة، واعلم أن ما أخطأك لم يكن ليصيبك، وما أصابك لم يكن ليخطئك، واعلم أن النصر مع الصبر، وأن الفرج مع الكرب، وأن مع العسر يسراً» .', 'vol': 1, 'page': 72}, {'text': 'الحديث العشرون\\n«عن أبي مسعود عقبة بن عمرو الأنصاري البدري \\ufd41 قال: قال رسول الله صلى الله عليه وآله وسلم: إن مما أدرك الناس من كلام النبوة الأولى: إذا لم تستح فاصنع ما شئت» .\\nرواه البخاري.', 'vol': 1, 'page': 73}, {'text': 'الحديث الحادي والعشرون\\n«عن أبي عمرو - وقيل أبي عمرة - سفيان ابن عبد الله \\ufd41 قال: قلت يا رسول الله قل لي في الإسلام قولاً لا أسال عنه أحداً غيرك، قال قل آمنت بالله، ثم استقم» .\\nرواه مسلم.', 'vol': 1, 'page': 74}, {'text': 'الحديث الثانى والعشرون\\n«عن أبي عبد الله جابر بن عبد الله الأنصاري \\ufd44 أن رجلاً سأل رسول الله صلى الله عليه وآله وسلم فقال: أرأيت إذا صليت المكتوبات، وصمت رمضان، وأحللت الحلال، وحرمت الحرام، ولم أزد على ذلك شيئاً، أدخل الجنة؟ قال نعم» .\\nرواه مسلم.\\nومعنى حرمت الحرام: اجتنبته،', 'vol': 1, 'page': 75}, {'text': 'ومعنى أحللت الحلال: فعلته معتقداً حله.', 'vol': 1, 'page': 76}, {'text': 'الحديث الثالث والعشرون\\n«عن أبي مالك الحارث بن الأشعري \\ufd41 قال: قال رسول الله صلى الله عليه وآله وسلم الطهور شطر الإيمان، والحمد لله تملأ الميزان، وسبحان الله والحمد لله تملآن - أو تملأ - ما بين', 'vol': 1, 'page': 77}, {'text': 'السماء والأرض، والصلاة نور، والصدقة برهان، والصبر ضياء، والقرآن حجة لك أو عليك، كل الناس يغدو: فبائع نفسه فمعتقها أو موبقها» .\\nرواه مسلم.', 'vol': 1, 'page': 78}, {'text': 'الحديث الرابع والعشرون\\n«عن أبي ذر الغفاري رضي الله تعالى عنه عن النبي صلى الله تعالى عليه وآله وسلم فيما يرويه عن ربه \\ufdff أنه قال يا عبادي، إني حرمت الظلم على نفسي وجعلته بينكم محرماً فلا تظالموا،', 'vol': 1, 'page': 79}, {'text': 'يا عبادي، كلكم ضال إلا من هديته فاستهدوني أهدكم، يا عبادي، كلكم جائع إلا من أطعمته فاستطعموني أطعمكم، يا عبادي، كلكم عار إلا من كسوته فاستكسوني أكسكم: يا عبادي، إنكم تخطئون بالليل والنهار وأنا أغفر الذنوب جميعاً فاستغفروني أغفر لكم، ياعبادي، إنكم لن تبلغوا ضري فتضروني ولن تبلغوا نفعي فتنفعوني، يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم كانوا على أتقى قلب رجل واحد منكم ما زاد ذلك في ملكي شيئاً:', 'vol': 1, 'page': 80}, {'text': 'يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم كانوا على أفجر قلب رجل واحد منكم ما نقص ذلك من ملكي شيئاً: يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم قاموا في صعيد واحد فسألوني فأعطيت كل واحد مسألته ما نقص ذلك مما عندي إلا كما ينقص المخيط إذا أدخل البحر، يا عبادي، إنما هي أعمالكم أحصيها لكم ثم أوفيكم إياها فمن وجد خيراً فليحمد الله ومن', 'vol': 1, 'page': 81}, {'text': 'وجد غير ذلك فلا يلومن إلا نفسه» .\\nرواه مسلم.', 'vol': 1, 'page': 82}, {'text': 'الحديث الخامس والعشرون\\n«عن أبي ذر \\ufd41 أيضاً أن ناساً من أصحاب رسول الله صلى الله عليه وآله وسلم قالوا للنبي صلى الله تعالى وعليه وآله وسلم: يا رسول الله، ذهب أهل الدثور بالأجور: يصلون كما نصلي ويصومون كما نصوم، ويتصدقون بفضول أموالهم.\\nقال: أوليس قد جعل الله لكم ما تصدقون: إن بكل تسبيحة صدقة، وكل تكبيرة صدقة، وكل', 'vol': 1, 'page': 83}, {'text': 'تحميدة صدقة، وكل تهليلة صدقة، وأمر بمعروف صدقة، ونهي عن منكر صدقة، وفي بضع أحدكم صدقة، قالوا: يا رسول الله، أيأتي أحدنا شهوته ويكون له فيها أجر؟ قال أرأيتم لو وضعها في حرام أكان عليه وزر؟ فكذلك إذا وضعها في الحلال كان له أجر» .\\nرواه مسلم.', 'vol': 1, 'page': 84}, {'text': 'الحديث السادس والعشرون\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم كل سلامى من الناس عليه صدقة كل يوم تطلع فيه الشمس: تعدل بين اثنين صدقة، وتعين الرجل في دابته فتحمله عليها أو ترفع', 'vol': 1, 'page': 85}, {'text': 'له عليها متاعه صدقة، والكلمة الطيبة صدقة، وبكل خطوة تمشيها إلى الصلاة صدقة، وتميط الأذى عن الطريق صدقة» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 86}, {'text': 'الحديث السابع والعشرون\\n«عن النواس بن سمعان رضي الله تعالى عنه عن النبي صلى الله عليه وعلى آله وسلم قال البر حسن الخلق، والإثم ما حاك في نفسك وكرهت أن يطلع عليه الناس» .\\nرواه مسلم\\nوعن وابصة بن معبد رضي الله تعالى عنه قال: «أتيت رسول الله صلى الله عليه وآله وسلم فقال: جئت تسأل عن البر؟ قلت: نعم، وقال: إستفت قلبك، البر ما', 'vol': 1, 'page': 87}, {'text': 'اطمأنت إليه النفس واطمأن إليه القلب، والإثم ما حاك في النفس وتردد في الصدر وإن أفتاك الناس وأفتوك» .\\nحديث حسن.\\nرويناه في مسندي الإمامين أحمد بن حنبل والدرامي بإسناد حسن.', 'vol': 1, 'page': 88}, {'text': 'الحديث الثامن والعشرون\\n«عن أبي نجيح العرباض بن سارية رضي الله تعالى عنه قال: وعظنا رسول الله صلى الله عليه وآله وسلم موعظة وجلت منها القلوب وذرفت منها العيون، فقلنا: يا رسول الله كأنها موعظة مودع فأوصنا، قال أوصيكم بتقوى الله \\ufdff والسمع والطاعة وإن تأمر عليكم عبد،', 'vol': 1, 'page': 89}, {'text': 'فإنه من يعش منكم فسيري اختلافاً كثيراً، فعليكم بسنتي وسنة الخلفاء الراشدين المهديين عضوا عليها بالنواجذ، وإياكم ومحدثات الأمور فإن كل بدعة ضلالة» .\\nرواه أبو داود والترمذي وقال: حديث حسن صحيح.', 'vol': 1, 'page': 90}, {'text': 'الحديث التاسع والعشرون\\n«عن معاذ بن جبل \\ufd41 قال: قلت يا رسول الله أخبرني بعمل يدخلني الجنة ويباعدني عن النار، قال: لقد سألت عن عظيم وإنه ليسير على من يسره الله تعالى عليه: تعبد الله لا تشرك به شيئاً، وتقيم الصلاة، وتؤتي الزكاة، وتصوم رمضان، وتحج البيت ثم قال: ألا أدلك على أبواب الخير؟ : الصوم جنة، والصدقة تطفئ الخطيئة كما يطفئ الماء النار، وصلاة الرجل في جوف الليل', 'vol': 1, 'page': 91}, {'text': 'ثم تلا: {تتجافى جنوبهم عن المضاجع} {حتى إذا بلغ} {يعملون} ثم قال ألا أخبرك برأس الأمر وعموده وذروة سنامه؟ قلت: بلى يا رسول الله.\\nقال رأس الأمر الإسلام، وعموده الصلاة، وذروة سنامه الجهاد', 'vol': 1, 'page': 92}, {'text': 'ثم قال: ألا أخبرك بملاك ذلك كله؟ قلت: بلى يا رسول الله، فأخذ بلسانه وقال كف عليك هذا قلت: يا نبي الله، وإنا لمؤاخذون بما نتكلم به؟ فقال ثكلتك أمك، وهل يكب الناس في النار على وجوههم - أو قال على مناخرهم - إلا حصائد ألسنتهم؟» .\\nرواه الترمذي وقال: حديث حسن صحيح.', 'vol': 1, 'page': 93}, {'text': 'الحديث الثلاثون\\n«عن أبي ثعلبة الخشبي جرثوم بن ناشر رضي الله تعالى عنه عن رسول الله ﷺ قال إن الله تعالى فرض فرائض فلا تضيعوها، وحد حدوداً فلا تعتدوها، وحرم أشياء فلا تنتهكوها،', 'vol': 1, 'page': 94}, {'text': 'وسكت عن أشياء رحمة لكم غير نسيان فلا تبحثوا عنها» .\\nحديث حسن رواه الدارقطني وغيره.', 'vol': 1, 'page': 95}, {'text': 'الحديث الحادي والثلاثون\\n«عن أبي العباس سهل بن سعد الساعدى رضي الله تعالى عنه قال جاء رجل إلى النبي صلى الله عليه وآله وسلم فقال: يا رسول الله، دلني على عمل إذا عملته أحبني الله وأحبني الناس: فقال إزهد في الدنيا يحبك الله، وازهد فيما عند الناس يحبك الناس» .\\nحديث حسن، رواه ابن ماجة وغيره بأسانيد حسنة.', 'vol': 1, 'page': 96}, {'text': 'الحديث الثاني والثلاثون\\n«عن أبي سعيد سعد بن مالك بن سنان الخدري رضي الله تعالى عنه أن رسول الله صلى الله وعليه وآله وسلم قال: لا ضرر ولا ضرار» .\\nحديث حسن، رواه ابن ماجة والدارقطني وغيرهما مسنداً.', 'vol': 1, 'page': 97}, {'text': 'ورواه مالك في الموطإ مرسلاً عن عمرو بن يحيى عن أبيه عن النبي صلى الله عليه وآله وسلم، فأسقط أبا سعيد، وله طرق يقوي بعضها بعضاً.', 'vol': 1, 'page': 98}, {'text': 'الحديث الثالث والثلاثون\\n«عن ابن عباس \\ufd44 أن رسول الله صلى الله عليه وآله وسلم قال: لو يعطى الناس بدعواهم لادعى رجال أموال قوم ودماءهم، لكن البينة على المدعى واليمين على من أنكر» .\\nحديث حسن، رواه البيهقي وغيره هكذا، وبعضه في الصحيحين.', 'vol': 1, 'page': 99}, {'text': 'الحديث الرابع والثلاثون\\n«عن أبي سعيد الخدري \\ufd41 قال: سمعت رسول الله صلى الله عليه وآله وسلم يقوم: من رأى منكم منكراً فليغيره بيده، فإن لم يستطع فبلسانه، فإن لم يستطع فبقلبه، وذلك أضعف الإيمان» .\\nرواه مسلم.', 'vol': 1, 'page': 100}, {'text': 'الحديث الخامس والثلاثون\\n«عن أبي هريرة \\ufd41 قال: قال رسول الله صلى الله عليه وآله وسلم لا تحاسدوا، ولا تناجشوا ولا تباغضوا، ولا تدابروا، ولا يبع بعضكم على بيع بعض، وكونوا عباد الله إخواناً، المسلم أخو المسلم لا يظلمه ولا يخذله ولا يكذبه ولا يحقره، التقوى ههنا - ويشير', 'vol': 1, 'page': 101}, {'text': 'إلى صدور ثلاث مرات - بحسب امرئ من الشر أن يحقر أخاه المسلم، كل المسلم على المسلم حرام: دمه وماله وعرضه» .\\nرواه مسلم.', 'vol': 1, 'page': 102}, {'text': 'الحديث السادس والثلاثون\\n«عن أبي هريرة \\ufd41 عن النبي صلى الله عليه وآله وسلم قال من نفس عن مؤمن كربة من كرب الدنيا نفس الله عنه كربة من كرب يوم القيامة، ومن يسر على معسر يسر الله عليه في الدنيا والآخرة، ومن ستر مسلماً ستره الله في الدنيا والآخرة، والله في عون العبد ما كان العبد في عون أخيه، ومن سلك طريقاً يلتمس فيه علماً سهل الله له به طريقاً إلى الجنة، وما اجتمع قوم في بيت من بيوت الله يتلون كتاب الله ويتدارسونه بينهم إلا نزلت عليهم السكينة', 'vol': 1, 'page': 103}, {'text': 'وغشيتهم الرحمة وحفتهم الملائكة وذكرهم الله فيمن عنده، ومن بطأ به عمله لم يسرع به نسبه» .\\nرواه مسلم بهذا اللفظ.', 'vol': 1, 'page': 104}, {'text': 'الحديث السابع والثلاثون\\n«عن ابن عباس \\ufd44 عن رسول الله صلى الله عليه وآله وسلم فيما يرويه عن ربه تبارك وتعالى قال إن الله كتب الحسنات والسيئات ثم بين ذلك، فمن هم بحسنة فلم يعملها كتبها الله عنده حسنة كاملة، وإن هم بها فعملها كتبها الله عنده عشر حسنات إلى سبعمائة ضعف إلى أضعاف كثيرة، وإن هم بسيئة فلم يعملها كتبها الله عنده حسنة كاملة، وإن هم بها فعملها كتبها الله سيئة واحدة» .', 'vol': 1, 'page': 105}, {'text': 'رواه البخاري ومسلم في صحيحيهما بهذه الحروف فانظر يا أخي وفقنا الله وإياك إلى عظيم لطف الله تعالى، وتأمل هذه الألفاظ، وقوله عنده إشارة إلى الإعتناء بها، وقوله كاملة للتأكيد وشدة الإعتناء بها، وقال في السيئة التي هم بها ثم تركها كتبها الله عنه حسنة كاملة فأكدها بـ (كاملة) وإن عملها كتبها سيئة واحدة، فأكد تقليلها', 'vol': 1, 'page': 106}, {'text': 'بـ (واحدة) ولم يؤكدها بـ (كاملة) فلله الحمد والمنة، سبحانه لا نحصي ثناء عليه، وبالله التوفيق.', 'vol': 1, 'page': 107}, {'text': 'الحديث الثامن والثلاثون\\n«عن أبي هريرة \\ufd41 قال: قال رسول الله صلى الله عليه وآله وسلم: إن الله تعالى قال: من عادى لي ولياً فقد آذنته بالحرب، وما تقرب إلى عبدي بشئ أحب إلي مما افترضته عليه، ولا يزال عبدي يتقرب إلي', 'vol': 1, 'page': 108}, {'text': 'بالنوافل حتى أحبه، فإذا أحببته كنت سمعه الذي يسمع به وبصره الذي يبصر به ويده التي يبطش بها ورجله التي يمشي بها، ولئن سألني لأعطينه، ولئن استعاذني لأعيذنه» .\\nرواه البخاري.', 'vol': 1, 'page': 109}, {'text': 'الحديث التاسع والثلاثون\\n«عن ابن عباس \\ufd44 أن رسول الله صلى الله عليه وآله وسلم قال إن الله تجاوز لي عن أمتى الخطأ والنسيان وما اسكترهوا عليه» .\\nحديث حسن رواه ابن ماجة والبيهقي وغيرهما.', 'vol': 1, 'page': 110}, {'text': 'الحديث الأربعون\\n«عن ابن عمر \\ufd44 قال: أخذ رسول الله صلى الله عليه وآله وسلم بمنكبي فقال: كن في الدنيا كأنك غريب أو عابر سبيل» وكان ابن عمر رضي الله تعالى عنهما يقول: إذا أمسيت فلا تنتظر الصباح، وإذا أصبحت فلا تنتظر', 'vol': 1, 'page': 111}, {'text': 'المساء، وخذ من صحتك لمرضك، ومن حياتك لموتك.\\nرواه البخاري.', 'vol': 1, 'page': 112}, {'text': 'الحديث الحادي والأربعون\\n«عن أبي محمد عبد الله بن عمرو بن العاص \\ufd44 قال: قال رسول الله صلى الله عليه وآله وسلم: لا يؤمن أحدكم حتى يكون هواه تبعاً لما جئت به» .\\nحديث حسن صحيح، رويناه في كتاب الحجة بإسناد صحيح.', 'vol': 1, 'page': 113}, {'text': 'الحديث الثاني والأربعون\\n«عن أنس \\ufd41 قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: قال الله تعالى يابن آدم، إنك ما دعوتني ورجوتني غفرت للك على ما كان منك ولا أبالي، يا ابن آدم لو بلغت ذنوبك عنان السماء ثم', 'vol': 1, 'page': 114}, {'text': 'استغفرتني غفرت لك، يا ابن آدم لو أتيتني بقراب الأرض خطايا ثم لقيتني لا تشرك بي شيئاً لأتيتك بقرابها مغفرة» .\\nرواه الترمذي وقال: حديث حسن صحيح.', 'vol': 1, 'page': 115}]	{"meta": {"id": 12836, "info": "", "name": "الأربعون النووية", "size": 39275, "betaka": "الكتاب: الأربعون النووية\\nالمؤلف: أبو زكريا محيي الدين يحيى بن شرف النووي (المتوفى: 676هـ)\\nعُنِيَ بِهِ: قصي محمد نورس الحلاق، أنور بن أبي بكر الشيخي\\nالناشر: دار المنهاج للنشر والتوزيع، لبنان - بيروت\\nالطبعة: الأولى، 1430 هـ - 2009 م\\nعدد الأجزاء: 1\\n[ترقيم الكتاب موافق للمطبوع]", "author_id": 44, "categories": ["الرقاق والآداب والأذكار"], "page_count": 81}, "pages": [{"vol": 1, "page": 35, "text": "بسم الله الرحمن الرحيم\\n\\nمقدمة المؤلف\\nالحمد لله رب العالمين قيوم السموات والأرضين. مدبر الخلائق أجمعين. باعث الرسل - صلواته وسلامه عليهم- إلى المكلفين لهدايتهم وبيان شرائع الدين بالدلائل القطعية، وواضحات البراهين."}, {"vol": 1, "page": 36, "text": "أحمده على جميع نعمه. وأسأله المزيد من فضله وكرمه.\\nوأشهد أن لا إله إلا الله الواحد القهار. الكريم الغفار وأشهد أن سيدنا محمداً عبده ورسوله وحبيبه وخليله أفضل المخلوقين، المكرم بالقرآن العزيز المعجزة المستمرة على تعاقب السنين، وبالسنن المستنيرة للمسترشدين المخصوص بجوامع الكلم وسماحة الدين صلوات الله وسلامه عليه وعلى سائر النبيين والمرسلين وآل كل وسائر الصالحين."}, {"vol": 1, "page": 37, "text": "أما بعد: فقد روينا عن علي بن أبي طالب، وعبد الله بن مسعود، ومعاذ بن جبل، وأبي الدرداء، وابن عمر، وابن عباس، وأنس بن مالك، وأبي هريرة، وأبي سعيد الخدري رضي الله تعالى عنهم من طرق كثيرات بروايات متنوعات: أن رسول الله ﷺ قال: \\"من حفظ على أمتي أربعين حديثاً من أمر دينها"}, {"vol": 1, "page": 38, "text": "بعثه الله يوم القيامة في زمرة الفقهاء والعلماء\\" وفي رواية: \\"بعثه الله فقيها عالما\\".\\nوفي رواية أبي الدرداء: \\"وكنت له يوم القيامة شافعا وشهيدا\\". وفي رواية ابن مسعود: قيل له: \\"ادخل من أي أبوب الجنة شئت\\" وفي رواية ابن عمر \\"كُتِب في زمرة العلماء وحشر في زمرة الشهداء\\". واتفق الحفاظ على أنه حديث ضعيف وإن كثرت طرقه."}, {"vol": 1, "page": 39, "text": "وقد صنّف العلماء رضي الله تعالى عنهم في هذا الباب ما لا يُحصى من المصنّفات. فأول من علمته صنف فيه: عبد الله بن المبارك، ثم محمد بن أسلم الطوسي العالم الرباني، ثم الحسن بن سفيان النسائي، وأبو بكر"}, {"vol": 1, "page": 40, "text": "الآجري، وأبو بكر بن إبراهيم الأصفهاني، والدارقطني، والحاكم،"}, {"vol": 1, "page": 41, "text": "وأبو نعيم، وأبو عبد الرحمن السلميّ، وأبو سعيد الماليني، وأبو عثمان الصابوني، وعبد الله بن"}, {"vol": 1, "page": 42, "text": "محمد الأنصاري. وأبو بكر البيهقي، وخلائق لا يحصون من المتقدمين والمتأخرين، وقد استخرت الله تعالى في جمع أربعين حديثاً اقتداء بهؤلاء الأئمة الأعلام وحفاظ الإسلام. وقد اتفق العلماء على جواز العمل بالحديث الضعيف"}, {"vol": 1, "page": 43, "text": "في فضائل الأعمال.\\nومع هذا فليس اعتمادي على هذا الحديث، بل على قوله ﷺ في الأحاديث الصحيحة: \\"ليبلغ الشاهد منكم الغائب\\" وقوله ﷺ: \\"نضر الله امرأً سمع مقالتي فوعاها فأدّاها كما سمعها\\".\\nثم من العلماء من جمع الأربعين في أصول الدين، وبعضهم في الفروع، وبعضهم في الجهاد، وبعضهم في الزهد، وبعضهم في الآداب، وبعضهم في الخطب،"}, {"vol": 1, "page": 44, "text": "وكلها مقاصة صالحة رضي الله تعالى عن قاصديها.\\nقد رأيت جمع أربعين أهم من هذا كله، وهي أربعون حديثاً مشتملة على جميع ذلك، وكل حديث منها قاعدة عظيمة من قواعد الدين قد وصفه العلماء بأن مدار الإسلام عليه، أو هو نصف الإسلام أو ثلثه أو نحو ذلك.\\nثم ألتزم في هذه الأربعين أن تكون صحيحة، ومعظمها في صحيحي البخاري ومسلم،"}, {"vol": 1, "page": 45, "text": "وأذكرها محذوفة الأسانيد، ليسهل حفظها، ويعم الانتفاع بها إن شاء الله تعالى، ثم أُتبعها بباب في ضبط خفي ألفاظها. وينبغي لكل راغب في الآخرة أن يعرف هذه الأحاديث، لما اشتملت عليه من المهمات، واحتوت عليه من التنبيه على جميع الطاعات وذلك ظاهر لمن تدبّره، وعلى الله اعتمادي، وإليه تفويضي واستنادي وله الحمد والنعمة، وبه التوفيق والعصمة."}, {"vol": 1, "page": 46, "text": "الحديث الأول\\n«عن أمير المؤمنين أبي حفص عمر بن الخطاب رضي الله تعالى عنه قال: سمعت رسول الله صلى الله تعالى عليه وعلى آله وسلم يقول: إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى، فمن كانت هجرته إلى الله ورسوله فهجرته إلى الله ورسوله، ومن كانت هجرته لدنيا يصيبها أو امرأة ينكحها فهجرته إلى ما هاجر إليه» .\\nرواه إماما المحدثين:"}, {"vol": 1, "page": 47, "text": "أبو عبد الله محمد ابن إسماعيل بن إبراهيم بن المغيرة بن بردزبه البخاري، وأبو الحسين مسلم ابن الحجاج بن مسلم القشيري النيسابوري: في صحيحيهما اللذين هما أصح الكتب المصنفة."}, {"vol": 1, "page": 48, "text": "الحديث الثاني\\n«عن عمر رضي الله تعالى عنه أيضاً قال: بينما نحن جلوس عند رسول الله صلى الله عليه وآله وسلم ذات يوم إذ طلع علينا رجل شديد بياض الثياب شديد سواد الشعر لا يرى عليه أثر السفر ولا يعرفه منا أحد، حتى جلس إلى النبي صلى الله عليه وآله وسلم فأسند ركبتيه إلى ركبتيه ووضع كفيه على فخذيه وقال: يا محمد أخبرني عن الإسلام،"}, {"vol": 1, "page": 49, "text": "فقال رسول الله صلى الله عليه وآله وسلم: الإسلام أن تشهد أن لا إله إلا الله وأن محمداً رسول الله، وتقيم الصلاة، وتؤتي الزكاة، وتصوم رمضان، وتحج البيت إن استطعت إليه سبيلاً قال: صدقت، فعجبنا له يسأله ويصدقه.\\nقال: فأخبرني عن الإيمان، قال أن تؤمن بالله وملائكته وكتبه ورسله واليوم الآخر، وتؤمن بالقدر خيره وشره، قال: صدقت، قال: فأخبرني عن الإحسان، قال أن تعبد الله كأنك تراه، فإن لم تكن تراه فإنه يراك،"}, {"vol": 1, "page": 50, "text": "قال: فأخبرني عن الساعة، قال ما المسئول عنها بأعلم من السائل، قال: فأخبرني عن أماراتها، قال أن تلد الأمة ربتها، وأن ترى الحفاة العراة العالة رعاء الشاء يتطاولون في البنيان"}, {"vol": 1, "page": 51, "text": "ثم انطلق فلبثت ملياً ثم قال يا عمر أتدري من السائل؟ قلت: الله ورسوله أعلم، قال فإنه جبريل أتاكم يعلمكم دينكم» .\\nرواه مسلم."}, {"vol": 1, "page": 52, "text": "الحديث الثالث\\n«عن أبي عبد الرحمن عبد الله بن عمر بن الخطاب رضي الله تعالى عنهما قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: بني الإسلام على خمس: شهادة أن لا إله إلا الله وأن محمداً رسول الله، وإقام الصلاة، وإيتاء الزكاة، وحج البيت، وصوم رمضان» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 53, "text": "الحديث الرابع\\n«عن أبي عبد الرحمن عبد الله بن مسعود ﵁ قال: حدثنا رسول الله صلى الله عليه وآله وسلم وهو الصادق المصدوق: إن أحدكم يجمع خلقه في بطن أمه أربعين يوماً نطفة، ثم يكون علقة مثل ذلك، ثم يكون مضغة مثل ذلك، ثم يرسل إليه الملك فينفخ فيه الروح ويؤمر بأربع كلمات: بكتب رزقه، وأجله، وعمله، وشقي أو سعيد،"}, {"vol": 1, "page": 54, "text": "فو الله الذي لا إله غيره إن أحدكم ليعمل بعمل أهل الجنة حتى ما يكون بينه وبينها إلا ذراع فيسبق عليه الكتاب فيعمل بعمل أهل النار فيدخلها، وإن أحدكم ليعمل بعمل أهل النار حتى ما يكون بينه وبينها إلا ذراع فيسبق عليه الكتاب فيعمل بعمل أهل الجنة فيدخلها» رواه البخاري ومسلم."}, {"vol": 1, "page": 55, "text": "الحديث الخامس\\n«عن أم المؤمنين أم عبد الله عائشة ﵂ قالت: قال رسول الله صلى الله عليه وآله وسلم: من أحدث في أمرنا هذا ما ليس منه فهو رد» .\\nرواه البخاري ومسلم.\\nوفي رواية لمسلم «من عمل عملاً ليس عليه أمرنا فهو رد» ."}, {"vol": 1, "page": 56, "text": "الحديث السادس\\n«عن أبي عبد الله النعمان بن بشير ﵄ قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: إن الحلال بين وإن الحرام بين وبينهما أمور مشتبهات لا يعلمهن كثير من الناس، فمن اتقى الشبهات فقد استبرأ لدينه وعرضه، ومن وقع في الشبهات وقع في"}, {"vol": 1, "page": 57, "text": "الحرام كالراعي يرعى حول الحمى يوشك أن يرتع فيه، ألا وإن لكل ملك حمى، ألا وإن حمى الله محارمه، ألا وإن في الجسد مضغة إذا صلحت صلح الجسد كله وإذا فسدت فسد الجسد كله ألا وهي القلب» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 58, "text": "الحديث السابع\\n«عن أبي رقية تميم بن أوس الداري رضي الله تعالى عنه أن النبي صلى الله عليه وآله وسلم قال الدين النصيحة.\\nقلنا: لمن؟ قال لله، ولكتابه، ولرسوله، ولأئمة المسلمين وعامتهم» .\\nرواه مسلم."}, {"vol": 1, "page": 59, "text": "الحديث الثامن\\n«عن ابن عمر رضي الله تعالى عنهما أن رسول الله صلى الله تعالى عليه وعلى آله وسلم قال أمرت أن أقاتل الناس حتى يشهدوا أن لا إله إلا الله وأن محمداً رسول الله، ويقيموا الصلاة، ويؤتوا الزكاة: فإذا فعلوا ذلك عصموا مني دماءهم وأموالهم إلا بحق الإسلام وحسابهم على الله تعالى» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 60, "text": "الحديث التاسع\\n«عن أبي هريرة عبد الرحمن بن صخر رضي الله تعالى عنه قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول مانهيتكم عنه فاجتنبوه، وما أمرتكم به فأتوا منه ما استطعتم، فإنما أهلك الذين من قبلكم كثرة مسائلهم واختلافهم على أنبيائهم» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 61, "text": "الحديث العاشر\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم: إن الله تعالى طيب لا يقبل إلا طيباً، وإن الله أمر المؤمنين بما أمر به المرسلين فقال تعالى {يا أيها الرسل كلوا من الطيبات واعملوا صالحا} وقال تعالى {يا أيها الذين آمنوا كلوا من طيبات ما رزقناكم} ثم ذكر الرجل يطيل السفر أشعث أغبر يمد يديه إلى السماء: يا رب يا رب، ومطعمه حرام"}, {"vol": 1, "page": 62, "text": "وملبسه حرام وغذي بالحرام فأنى يستجاب له» .\\nرواه مسلم."}, {"vol": 1, "page": 63, "text": "الحديث الحادي عشر\\n«عن أبي محمد الحسن بن علي بن أبي طالب سبط رسول الله صلى الله عليه وآله وسلم وريحانته ﵄ قال: حفظت من رسول الله صلى الله عليه وآله وسلم دع ما يريبك إلى ما لا يريبك» .\\nرواه الترمذي والنسائي، وقال الترمذي: حديث حسن صحيح."}, {"vol": 1, "page": 64, "text": "الحديث الثانى عشر\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم من حسن إسلام المرء تركه ما لا يعنيه» .\\nحديث حسن، رواه الترمذي وغيره وهكذا."}, {"vol": 1, "page": 65, "text": "الحديث الثالث عشر\\n«عن أبي حمزة أنس بن مالك رضي الله تعالى عنه خادم رسول الله صلى الله عليه وآله وسلم عن النبي صلى الله عليه وآله وسلم قال لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 66, "text": "الحديث الرابع عشر\\n«عن ابن مسعود رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم لا يحل دم امرئ مسلم إلا بإحدى ثلاث: الثيب الزاني، والنفس بالنفس، والتارك لدينه المفارق للجماعة» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 67, "text": "الحديث الخامس عشر\\n«عن أبي هريرة رضي الله تعالى عنه أن رسول الله صلى الله عليه وآله وسلم قال: من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت، ومن كان يؤمن بالله واليوم الآخر فليكرم جاره، ومن كان يؤمن بالله واليوم الآخر فليكرم ضيفه» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 68, "text": "الحديث السادس عشر\\n«عن أبي هريرة رضي الله تعالى عنه أن رجلاً قال للنبي صلى الله عليه وآله وسلم: أوصني، قال لا تغضب فردد مراراً، قال لا تغضب» .\\nرواه البخاري."}, {"vol": 1, "page": 69, "text": "الحديث السابع عشر\\n«عن أبي يعلى شداد بن أوس رضي الله تعالى عنه عن رسول الله صلى الله عليه وآله وسلم قال إن الله كتب الإحسان على كل شئ، فإذا قتلتم فأحسنوا القتلة وإذا ذبحتم فأحسنوا الذبحة، وليحد أحدكم شفرته وليرح ذبيحته» .\\nرواه مسلم."}, {"vol": 1, "page": 70, "text": "الحديث الثامن عشر\\n«عن أبي ذر جندب بن جنادة، وأبي عبد الرحمن معاذ بن جبل رضي الله تعالى عنهما عن رسول الله صلى الله عليه وآله وسلم قال: إتق الله حيثما كنت، وأتبع السيئة الحسنة تمحها، وخالق الناس بخلق حسن» .\\nرواه الترمذي وقال: حديث حسن، وفي بعض النسخ: حسن صحيح."}, {"vol": 1, "page": 71, "text": "الحديث التاسع عشر\\n«عن أبي العباس عبد الله بن عباس رضي الله تعالى عنهما قال: كنت خلف النبي صلى الله عليه وآله وسلم يوماً فقال يا غلام، إني أعلمك كلمات: إحفظ الله يحفظك، إحفظ الله تجده تجاهك، إذا سألت فاسأل الله، وإذا استعنت فاستعن بالله، واعلم أن الأمة لو اجتمعت على أن ينفعوك بشئ لم ينفعوك إلا بشئ قد كتبه الله لك،"}, {"vol": 1, "page": 72, "text": "وإن اجتمعوا على أن يضروك بشئ لم يضروك إلا بشئ قد كتبه الله عليك، رفعت الأقلام وجفت الصحف» .\\nرواه الترمذي وقال حديث حسن صحيح.\\nوفي رواية غير الترمذي «إحفظ الله تجده أمامك، تعرف إلى الله في الرخاء يعرفك في الشدة، واعلم أن ما أخطأك لم يكن ليصيبك، وما أصابك لم يكن ليخطئك، واعلم أن النصر مع الصبر، وأن الفرج مع الكرب، وأن مع العسر يسراً» ."}, {"vol": 1, "page": 73, "text": "الحديث العشرون\\n«عن أبي مسعود عقبة بن عمرو الأنصاري البدري ﵁ قال: قال رسول الله صلى الله عليه وآله وسلم: إن مما أدرك الناس من كلام النبوة الأولى: إذا لم تستح فاصنع ما شئت» .\\nرواه البخاري."}, {"vol": 1, "page": 74, "text": "الحديث الحادي والعشرون\\n«عن أبي عمرو - وقيل أبي عمرة - سفيان ابن عبد الله ﵁ قال: قلت يا رسول الله قل لي في الإسلام قولاً لا أسال عنه أحداً غيرك، قال قل آمنت بالله، ثم استقم» .\\nرواه مسلم."}, {"vol": 1, "page": 75, "text": "الحديث الثانى والعشرون\\n«عن أبي عبد الله جابر بن عبد الله الأنصاري ﵄ أن رجلاً سأل رسول الله صلى الله عليه وآله وسلم فقال: أرأيت إذا صليت المكتوبات، وصمت رمضان، وأحللت الحلال، وحرمت الحرام، ولم أزد على ذلك شيئاً، أدخل الجنة؟ قال نعم» .\\nرواه مسلم.\\nومعنى حرمت الحرام: اجتنبته،"}, {"vol": 1, "page": 76, "text": "ومعنى أحللت الحلال: فعلته معتقداً حله."}, {"vol": 1, "page": 77, "text": "الحديث الثالث والعشرون\\n«عن أبي مالك الحارث بن الأشعري ﵁ قال: قال رسول الله صلى الله عليه وآله وسلم الطهور شطر الإيمان، والحمد لله تملأ الميزان، وسبحان الله والحمد لله تملآن - أو تملأ - ما بين"}, {"vol": 1, "page": 78, "text": "السماء والأرض، والصلاة نور، والصدقة برهان، والصبر ضياء، والقرآن حجة لك أو عليك، كل الناس يغدو: فبائع نفسه فمعتقها أو موبقها» .\\nرواه مسلم."}, {"vol": 1, "page": 79, "text": "الحديث الرابع والعشرون\\n«عن أبي ذر الغفاري رضي الله تعالى عنه عن النبي صلى الله تعالى عليه وآله وسلم فيما يرويه عن ربه ﷿ أنه قال يا عبادي، إني حرمت الظلم على نفسي وجعلته بينكم محرماً فلا تظالموا،"}, {"vol": 1, "page": 80, "text": "يا عبادي، كلكم ضال إلا من هديته فاستهدوني أهدكم، يا عبادي، كلكم جائع إلا من أطعمته فاستطعموني أطعمكم، يا عبادي، كلكم عار إلا من كسوته فاستكسوني أكسكم: يا عبادي، إنكم تخطئون بالليل والنهار وأنا أغفر الذنوب جميعاً فاستغفروني أغفر لكم، ياعبادي، إنكم لن تبلغوا ضري فتضروني ولن تبلغوا نفعي فتنفعوني، يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم كانوا على أتقى قلب رجل واحد منكم ما زاد ذلك في ملكي شيئاً:"}, {"vol": 1, "page": 81, "text": "يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم كانوا على أفجر قلب رجل واحد منكم ما نقص ذلك من ملكي شيئاً: يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم قاموا في صعيد واحد فسألوني فأعطيت كل واحد مسألته ما نقص ذلك مما عندي إلا كما ينقص المخيط إذا أدخل البحر، يا عبادي، إنما هي أعمالكم أحصيها لكم ثم أوفيكم إياها فمن وجد خيراً فليحمد الله ومن"}, {"vol": 1, "page": 82, "text": "وجد غير ذلك فلا يلومن إلا نفسه» .\\nرواه مسلم."}, {"vol": 1, "page": 83, "text": "الحديث الخامس والعشرون\\n«عن أبي ذر ﵁ أيضاً أن ناساً من أصحاب رسول الله صلى الله عليه وآله وسلم قالوا للنبي صلى الله تعالى وعليه وآله وسلم: يا رسول الله، ذهب أهل الدثور بالأجور: يصلون كما نصلي ويصومون كما نصوم، ويتصدقون بفضول أموالهم.\\nقال: أوليس قد جعل الله لكم ما تصدقون: إن بكل تسبيحة صدقة، وكل تكبيرة صدقة، وكل"}, {"vol": 1, "page": 84, "text": "تحميدة صدقة، وكل تهليلة صدقة، وأمر بمعروف صدقة، ونهي عن منكر صدقة، وفي بضع أحدكم صدقة، قالوا: يا رسول الله، أيأتي أحدنا شهوته ويكون له فيها أجر؟ قال أرأيتم لو وضعها في حرام أكان عليه وزر؟ فكذلك إذا وضعها في الحلال كان له أجر» .\\nرواه مسلم."}, {"vol": 1, "page": 85, "text": "الحديث السادس والعشرون\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم كل سلامى من الناس عليه صدقة كل يوم تطلع فيه الشمس: تعدل بين اثنين صدقة، وتعين الرجل في دابته فتحمله عليها أو ترفع"}, {"vol": 1, "page": 86, "text": "له عليها متاعه صدقة، والكلمة الطيبة صدقة، وبكل خطوة تمشيها إلى الصلاة صدقة، وتميط الأذى عن الطريق صدقة» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 87, "text": "الحديث السابع والعشرون\\n«عن النواس بن سمعان رضي الله تعالى عنه عن النبي صلى الله عليه وعلى آله وسلم قال البر حسن الخلق، والإثم ما حاك في نفسك وكرهت أن يطلع عليه الناس» .\\nرواه مسلم\\nوعن وابصة بن معبد رضي الله تعالى عنه قال: «أتيت رسول الله صلى الله عليه وآله وسلم فقال: جئت تسأل عن البر؟ قلت: نعم، وقال: إستفت قلبك، البر ما"}, {"vol": 1, "page": 88, "text": "اطمأنت إليه النفس واطمأن إليه القلب، والإثم ما حاك في النفس وتردد في الصدر وإن أفتاك الناس وأفتوك» .\\nحديث حسن.\\nرويناه في مسندي الإمامين أحمد بن حنبل والدرامي بإسناد حسن."}, {"vol": 1, "page": 89, "text": "الحديث الثامن والعشرون\\n«عن أبي نجيح العرباض بن سارية رضي الله تعالى عنه قال: وعظنا رسول الله صلى الله عليه وآله وسلم موعظة وجلت منها القلوب وذرفت منها العيون، فقلنا: يا رسول الله كأنها موعظة مودع فأوصنا، قال أوصيكم بتقوى الله ﷿ والسمع والطاعة وإن تأمر عليكم عبد،"}, {"vol": 1, "page": 90, "text": "فإنه من يعش منكم فسيري اختلافاً كثيراً، فعليكم بسنتي وسنة الخلفاء الراشدين المهديين عضوا عليها بالنواجذ، وإياكم ومحدثات الأمور فإن كل بدعة ضلالة» .\\nرواه أبو داود والترمذي وقال: حديث حسن صحيح."}, {"vol": 1, "page": 91, "text": "الحديث التاسع والعشرون\\n«عن معاذ بن جبل ﵁ قال: قلت يا رسول الله أخبرني بعمل يدخلني الجنة ويباعدني عن النار، قال: لقد سألت عن عظيم وإنه ليسير على من يسره الله تعالى عليه: تعبد الله لا تشرك به شيئاً، وتقيم الصلاة، وتؤتي الزكاة، وتصوم رمضان، وتحج البيت ثم قال: ألا أدلك على أبواب الخير؟ : الصوم جنة، والصدقة تطفئ الخطيئة كما يطفئ الماء النار، وصلاة الرجل في جوف الليل"}, {"vol": 1, "page": 92, "text": "ثم تلا: {تتجافى جنوبهم عن المضاجع} {حتى إذا بلغ} {يعملون} ثم قال ألا أخبرك برأس الأمر وعموده وذروة سنامه؟ قلت: بلى يا رسول الله.\\nقال رأس الأمر الإسلام، وعموده الصلاة، وذروة سنامه الجهاد"}, {"vol": 1, "page": 93, "text": "ثم قال: ألا أخبرك بملاك ذلك كله؟ قلت: بلى يا رسول الله، فأخذ بلسانه وقال كف عليك هذا قلت: يا نبي الله، وإنا لمؤاخذون بما نتكلم به؟ فقال ثكلتك أمك، وهل يكب الناس في النار على وجوههم - أو قال على مناخرهم - إلا حصائد ألسنتهم؟» .\\nرواه الترمذي وقال: حديث حسن صحيح."}, {"vol": 1, "page": 94, "text": "الحديث الثلاثون\\n«عن أبي ثعلبة الخشبي جرثوم بن ناشر رضي الله تعالى عنه عن رسول الله ﷺ قال إن الله تعالى فرض فرائض فلا تضيعوها، وحد حدوداً فلا تعتدوها، وحرم أشياء فلا تنتهكوها،"}, {"vol": 1, "page": 95, "text": "وسكت عن أشياء رحمة لكم غير نسيان فلا تبحثوا عنها» .\\nحديث حسن رواه الدارقطني وغيره."}, {"vol": 1, "page": 96, "text": "الحديث الحادي والثلاثون\\n«عن أبي العباس سهل بن سعد الساعدى رضي الله تعالى عنه قال جاء رجل إلى النبي صلى الله عليه وآله وسلم فقال: يا رسول الله، دلني على عمل إذا عملته أحبني الله وأحبني الناس: فقال إزهد في الدنيا يحبك الله، وازهد فيما عند الناس يحبك الناس» .\\nحديث حسن، رواه ابن ماجة وغيره بأسانيد حسنة."}, {"vol": 1, "page": 97, "text": "الحديث الثاني والثلاثون\\n«عن أبي سعيد سعد بن مالك بن سنان الخدري رضي الله تعالى عنه أن رسول الله صلى الله وعليه وآله وسلم قال: لا ضرر ولا ضرار» .\\nحديث حسن، رواه ابن ماجة والدارقطني وغيرهما مسنداً."}, {"vol": 1, "page": 98, "text": "ورواه مالك في الموطإ مرسلاً عن عمرو بن يحيى عن أبيه عن النبي صلى الله عليه وآله وسلم، فأسقط أبا سعيد، وله طرق يقوي بعضها بعضاً."}, {"vol": 1, "page": 99, "text": "الحديث الثالث والثلاثون\\n«عن ابن عباس ﵄ أن رسول الله صلى الله عليه وآله وسلم قال: لو يعطى الناس بدعواهم لادعى رجال أموال قوم ودماءهم، لكن البينة على المدعى واليمين على من أنكر» .\\nحديث حسن، رواه البيهقي وغيره هكذا، وبعضه في الصحيحين."}, {"vol": 1, "page": 100, "text": "الحديث الرابع والثلاثون\\n«عن أبي سعيد الخدري ﵁ قال: سمعت رسول الله صلى الله عليه وآله وسلم يقوم: من رأى منكم منكراً فليغيره بيده، فإن لم يستطع فبلسانه، فإن لم يستطع فبقلبه، وذلك أضعف الإيمان» .\\nرواه مسلم."}, {"vol": 1, "page": 101, "text": "الحديث الخامس والثلاثون\\n«عن أبي هريرة ﵁ قال: قال رسول الله صلى الله عليه وآله وسلم لا تحاسدوا، ولا تناجشوا ولا تباغضوا، ولا تدابروا، ولا يبع بعضكم على بيع بعض، وكونوا عباد الله إخواناً، المسلم أخو المسلم لا يظلمه ولا يخذله ولا يكذبه ولا يحقره، التقوى ههنا - ويشير"}, {"vol": 1, "page": 102, "text": "إلى صدور ثلاث مرات - بحسب امرئ من الشر أن يحقر أخاه المسلم، كل المسلم على المسلم حرام: دمه وماله وعرضه» .\\nرواه مسلم."}, {"vol": 1, "page": 103, "text": "الحديث السادس والثلاثون\\n«عن أبي هريرة ﵁ عن النبي صلى الله عليه وآله وسلم قال من نفس عن مؤمن كربة من كرب الدنيا نفس الله عنه كربة من كرب يوم القيامة، ومن يسر على معسر يسر الله عليه في الدنيا والآخرة، ومن ستر مسلماً ستره الله في الدنيا والآخرة، والله في عون العبد ما كان العبد في عون أخيه، ومن سلك طريقاً يلتمس فيه علماً سهل الله له به طريقاً إلى الجنة، وما اجتمع قوم في بيت من بيوت الله يتلون كتاب الله ويتدارسونه بينهم إلا نزلت عليهم السكينة"}, {"vol": 1, "page": 104, "text": "وغشيتهم الرحمة وحفتهم الملائكة وذكرهم الله فيمن عنده، ومن بطأ به عمله لم يسرع به نسبه» .\\nرواه مسلم بهذا اللفظ."}, {"vol": 1, "page": 105, "text": "الحديث السابع والثلاثون\\n«عن ابن عباس ﵄ عن رسول الله صلى الله عليه وآله وسلم فيما يرويه عن ربه تبارك وتعالى قال إن الله كتب الحسنات والسيئات ثم بين ذلك، فمن هم بحسنة فلم يعملها كتبها الله عنده حسنة كاملة، وإن هم بها فعملها كتبها الله عنده عشر حسنات إلى سبعمائة ضعف إلى أضعاف كثيرة، وإن هم بسيئة فلم يعملها كتبها الله عنده حسنة كاملة، وإن هم بها فعملها كتبها الله سيئة واحدة» ."}, {"vol": 1, "page": 106, "text": "رواه البخاري ومسلم في صحيحيهما بهذه الحروف فانظر يا أخي وفقنا الله وإياك إلى عظيم لطف الله تعالى، وتأمل هذه الألفاظ، وقوله عنده إشارة إلى الإعتناء بها، وقوله كاملة للتأكيد وشدة الإعتناء بها، وقال في السيئة التي هم بها ثم تركها كتبها الله عنه حسنة كاملة فأكدها بـ (كاملة) وإن عملها كتبها سيئة واحدة، فأكد تقليلها"}, {"vol": 1, "page": 107, "text": "بـ (واحدة) ولم يؤكدها بـ (كاملة) فلله الحمد والمنة، سبحانه لا نحصي ثناء عليه، وبالله التوفيق."}, {"vol": 1, "page": 108, "text": "الحديث الثامن والثلاثون\\n«عن أبي هريرة ﵁ قال: قال رسول الله صلى الله عليه وآله وسلم: إن الله تعالى قال: من عادى لي ولياً فقد آذنته بالحرب، وما تقرب إلى عبدي بشئ أحب إلي مما افترضته عليه، ولا يزال عبدي يتقرب إلي"}, {"vol": 1, "page": 109, "text": "بالنوافل حتى أحبه، فإذا أحببته كنت سمعه الذي يسمع به وبصره الذي يبصر به ويده التي يبطش بها ورجله التي يمشي بها، ولئن سألني لأعطينه، ولئن استعاذني لأعيذنه» .\\nرواه البخاري."}, {"vol": 1, "page": 110, "text": "الحديث التاسع والثلاثون\\n«عن ابن عباس ﵄ أن رسول الله صلى الله عليه وآله وسلم قال إن الله تجاوز لي عن أمتى الخطأ والنسيان وما اسكترهوا عليه» .\\nحديث حسن رواه ابن ماجة والبيهقي وغيرهما."}, {"vol": 1, "page": 111, "text": "الحديث الأربعون\\n«عن ابن عمر ﵄ قال: أخذ رسول الله صلى الله عليه وآله وسلم بمنكبي فقال: كن في الدنيا كأنك غريب أو عابر سبيل» وكان ابن عمر رضي الله تعالى عنهما يقول: إذا أمسيت فلا تنتظر الصباح، وإذا أصبحت فلا تنتظر"}, {"vol": 1, "page": 112, "text": "المساء، وخذ من صحتك لمرضك، ومن حياتك لموتك.\\nرواه البخاري."}, {"vol": 1, "page": 113, "text": "الحديث الحادي والأربعون\\n«عن أبي محمد عبد الله بن عمرو بن العاص ﵄ قال: قال رسول الله صلى الله عليه وآله وسلم: لا يؤمن أحدكم حتى يكون هواه تبعاً لما جئت به» .\\nحديث حسن صحيح، رويناه في كتاب الحجة بإسناد صحيح."}, {"vol": 1, "page": 114, "text": "الحديث الثاني والأربعون\\n«عن أنس ﵁ قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: قال الله تعالى يابن آدم، إنك ما دعوتني ورجوتني غفرت للك على ما كان منك ولا أبالي، يا ابن آدم لو بلغت ذنوبك عنان السماء ثم"}, {"vol": 1, "page": 115, "text": "استغفرتني غفرت لك، يا ابن آدم لو أتيتني بقراب الأرض خطايا ثم لقيتني لا تشرك بي شيئاً لأتيتك بقرابها مغفرة» .\\nرواه الترمذي وقال: حديث حسن صحيح."}], "indexes": {"hadiths": {"1": 12, "2": 14, "3": 18, "4": 19, "5": 21, "6": 22, "7": 24, "8": 25, "9": 26, "10": 27, "11": 29, "12": 30, "13": 31, "14": 32, "15": 33, "16": 34, "17": 35, "18": 36, "19": 37, "20": 39, "21": 40, "22": 41, "23": 43, "24": 45, "25": 49, "26": 51, "27": 53, "28": 55, "29": 57, "30": 60, "31": 62, "32": 63, "33": 65, "34": 66, "35": 67, "36": 69, "37": 71, "38": 74, "39": 76, "40": 77, "41": 79, "42": 80}, "headings": [{"page": 1, "level": 1, "title": "مقدمة المؤلف"}, {"page": 12, "level": 1, "title": "الحديث الأول"}, {"page": 14, "level": 1, "title": "الحديث الثاني"}, {"page": 18, "level": 1, "title": "الحديث الثالث"}, {"page": 19, "level": 1, "title": "الحديث الرابع"}, {"page": 21, "level": 1, "title": "الحديث الخامس"}, {"page": 22, "level": 1, "title": "الحديث السادس"}, {"page": 24, "level": 1, "title": "الحديث السابع"}, {"page": 25, "level": 1, "title": "الحديث الثامن"}, {"page": 26, "level": 1, "title": "الحديث التاسع"}, {"page": 27, "level": 1, "title": "الحديث العاشر"}, {"page": 29, "level": 1, "title": "الحديث الحادي عشر"}, {"page": 30, "level": 1, "title": "الحديث الثانى عشر"}, {"page": 31, "level": 1, "title": "الحديث الثالث عشر"}, {"page": 32, "level": 1, "title": "الحديث الرابع عشر"}, {"page": 33, "level": 1, "title": "الحديث الخامس عشر"}, {"page": 34, "level": 1, "title": "الحديث السادس عشر"}, {"page": 35, "level": 1, "title": "الحديث السابع عشر"}, {"page": 36, "level": 1, "title": "الحديث الثامن عشر"}, {"page": 37, "level": 1, "title": "الحديث التاسع عشر"}, {"page": 39, "level": 1, "title": "الحديث العشرون"}, {"page": 40, "level": 1, "title": "الحديث الحادي والعشرون"}, {"page": 41, "level": 1, "title": "الحديث الثانى والعشرون"}, {"page": 43, "level": 1, "title": "الحديث الثالث والعشرون"}, {"page": 45, "level": 1, "title": "الحديث الرابع والعشرون"}, {"page": 49, "level": 1, "title": "الحديث الخامس والعشرون"}, {"page": 51, "level": 1, "title": "الحديث السادس والعشرون"}, {"page": 53, "level": 1, "title": "الحديث السابع والعشرون"}, {"page": 55, "level": 1, "title": "الحديث الثامن والعشرون"}, {"page": 57, "level": 1, "title": "الحديث التاسع والعشرون"}, {"page": 60, "level": 1, "title": "الحديث الثلاثون"}, {"page": 62, "level": 1, "title": "الحديث الحادي والثلاثون"}, {"page": 63, "level": 1, "title": "الحديث الثاني والثلاثون"}, {"page": 65, "level": 1, "title": "الحديث الثالث والثلاثون"}, {"page": 66, "level": 1, "title": "الحديث الرابع والثلاثون"}, {"page": 67, "level": 1, "title": "الحديث الخامس والثلاثون"}, {"page": 69, "level": 1, "title": "الحديث السادس والثلاثون"}, {"page": 71, "level": 1, "title": "الحديث السابع والثلاثون"}, {"page": 74, "level": 1, "title": "الحديث الثامن والثلاثون"}, {"page": 76, "level": 1, "title": "الحديث التاسع والثلاثون"}, {"page": 77, "level": 1, "title": "الحديث الأربعون"}, {"page": 79, "level": 1, "title": "الحديث الحادي والأربعون"}, {"page": 80, "level": 1, "title": "الحديث الثاني والأربعون"}]}}		44	f	t	2020-06-15 03:07:41.570932+00	2020-06-15 05:23:02.337619+00	\N		\N	\N	81	\N	1	\N	4
1	الأربعون النووية	[{'text': 'بسم الله الرحمن الرحيم\\n\\nمقدمة المؤلف\\nالحمد لله رب العالمين قيوم السموات والأرضين. مدبر الخلائق أجمعين. باعث الرسل - صلواته وسلامه عليهم- إلى المكلفين لهدايتهم وبيان شرائع الدين بالدلائل القطعية، وواضحات البراهين.', 'vol': 1, 'page': 35}, {'text': 'أحمده على جميع نعمه. وأسأله المزيد من فضله وكرمه.\\nوأشهد أن لا إله إلا الله الواحد القهار. الكريم الغفار وأشهد أن سيدنا محمداً عبده ورسوله وحبيبه وخليله أفضل المخلوقين، المكرم بالقرآن العزيز المعجزة المستمرة على تعاقب السنين، وبالسنن المستنيرة للمسترشدين المخصوص بجوامع الكلم وسماحة الدين صلوات الله وسلامه عليه وعلى سائر النبيين والمرسلين وآل كل وسائر الصالحين.', 'vol': 1, 'page': 36}, {'text': 'أما بعد: فقد روينا عن علي بن أبي طالب، وعبد الله بن مسعود، ومعاذ بن جبل، وأبي الدرداء، وابن عمر، وابن عباس، وأنس بن مالك، وأبي هريرة، وأبي سعيد الخدري رضي الله تعالى عنهم من طرق كثيرات بروايات متنوعات: أن رسول الله ﷺ قال: "من حفظ على أمتي أربعين حديثاً من أمر دينها', 'vol': 1, 'page': 37}, {'text': 'بعثه الله يوم القيامة في زمرة الفقهاء والعلماء" وفي رواية: "بعثه الله فقيها عالما".\\nوفي رواية أبي الدرداء: "وكنت له يوم القيامة شافعا وشهيدا". وفي رواية ابن مسعود: قيل له: "ادخل من أي أبوب الجنة شئت" وفي رواية ابن عمر "كُتِب في زمرة العلماء وحشر في زمرة الشهداء". واتفق الحفاظ على أنه حديث ضعيف وإن كثرت طرقه.', 'vol': 1, 'page': 38}, {'text': 'وقد صنّف العلماء رضي الله تعالى عنهم في هذا الباب ما لا يُحصى من المصنّفات. فأول من علمته صنف فيه: عبد الله بن المبارك، ثم محمد بن أسلم الطوسي العالم الرباني، ثم الحسن بن سفيان النسائي، وأبو بكر', 'vol': 1, 'page': 39}, {'text': 'الآجري، وأبو بكر بن إبراهيم الأصفهاني، والدارقطني، والحاكم،', 'vol': 1, 'page': 40}, {'text': 'وأبو نعيم، وأبو عبد الرحمن السلميّ، وأبو سعيد الماليني، وأبو عثمان الصابوني، وعبد الله بن', 'vol': 1, 'page': 41}, {'text': 'محمد الأنصاري. وأبو بكر البيهقي، وخلائق لا يحصون من المتقدمين والمتأخرين، وقد استخرت الله تعالى في جمع أربعين حديثاً اقتداء بهؤلاء الأئمة الأعلام وحفاظ الإسلام. وقد اتفق العلماء على جواز العمل بالحديث الضعيف', 'vol': 1, 'page': 42}, {'text': 'في فضائل الأعمال.\\nومع هذا فليس اعتمادي على هذا الحديث، بل على قوله ﷺ في الأحاديث الصحيحة: "ليبلغ الشاهد منكم الغائب" وقوله ﷺ: "نضر الله امرأً سمع مقالتي فوعاها فأدّاها كما سمعها".\\nثم من العلماء من جمع الأربعين في أصول الدين، وبعضهم في الفروع، وبعضهم في الجهاد، وبعضهم في الزهد، وبعضهم في الآداب، وبعضهم في الخطب،', 'vol': 1, 'page': 43}, {'text': 'وكلها مقاصة صالحة رضي الله تعالى عن قاصديها.\\nقد رأيت جمع أربعين أهم من هذا كله، وهي أربعون حديثاً مشتملة على جميع ذلك، وكل حديث منها قاعدة عظيمة من قواعد الدين قد وصفه العلماء بأن مدار الإسلام عليه، أو هو نصف الإسلام أو ثلثه أو نحو ذلك.\\nثم ألتزم في هذه الأربعين أن تكون صحيحة، ومعظمها في صحيحي البخاري ومسلم،', 'vol': 1, 'page': 44}, {'text': 'وأذكرها محذوفة الأسانيد، ليسهل حفظها، ويعم الانتفاع بها إن شاء الله تعالى، ثم أُتبعها بباب في ضبط خفي ألفاظها. وينبغي لكل راغب في الآخرة أن يعرف هذه الأحاديث، لما اشتملت عليه من المهمات، واحتوت عليه من التنبيه على جميع الطاعات وذلك ظاهر لمن تدبّره، وعلى الله اعتمادي، وإليه تفويضي واستنادي وله الحمد والنعمة، وبه التوفيق والعصمة.', 'vol': 1, 'page': 45}, {'text': 'الحديث الأول\\n«عن أمير المؤمنين أبي حفص عمر بن الخطاب رضي الله تعالى عنه قال: سمعت رسول الله صلى الله تعالى عليه وعلى آله وسلم يقول: إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى، فمن كانت هجرته إلى الله ورسوله فهجرته إلى الله ورسوله، ومن كانت هجرته لدنيا يصيبها أو امرأة ينكحها فهجرته إلى ما هاجر إليه» .\\nرواه إماما المحدثين:', 'vol': 1, 'page': 46}, {'text': 'أبو عبد الله محمد ابن إسماعيل بن إبراهيم بن المغيرة بن بردزبه البخاري، وأبو الحسين مسلم ابن الحجاج بن مسلم القشيري النيسابوري: في صحيحيهما اللذين هما أصح الكتب المصنفة.', 'vol': 1, 'page': 47}, {'text': 'الحديث الثاني\\n«عن عمر رضي الله تعالى عنه أيضاً قال: بينما نحن جلوس عند رسول الله صلى الله عليه وآله وسلم ذات يوم إذ طلع علينا رجل شديد بياض الثياب شديد سواد الشعر لا يرى عليه أثر السفر ولا يعرفه منا أحد، حتى جلس إلى النبي صلى الله عليه وآله وسلم فأسند ركبتيه إلى ركبتيه ووضع كفيه على فخذيه وقال: يا محمد أخبرني عن الإسلام،', 'vol': 1, 'page': 48}, {'text': 'فقال رسول الله صلى الله عليه وآله وسلم: الإسلام أن تشهد أن لا إله إلا الله وأن محمداً رسول الله، وتقيم الصلاة، وتؤتي الزكاة، وتصوم رمضان، وتحج البيت إن استطعت إليه سبيلاً قال: صدقت، فعجبنا له يسأله ويصدقه.\\nقال: فأخبرني عن الإيمان، قال أن تؤمن بالله وملائكته وكتبه ورسله واليوم الآخر، وتؤمن بالقدر خيره وشره، قال: صدقت، قال: فأخبرني عن الإحسان، قال أن تعبد الله كأنك تراه، فإن لم تكن تراه فإنه يراك،', 'vol': 1, 'page': 49}, {'text': 'قال: فأخبرني عن الساعة، قال ما المسئول عنها بأعلم من السائل، قال: فأخبرني عن أماراتها، قال أن تلد الأمة ربتها، وأن ترى الحفاة العراة العالة رعاء الشاء يتطاولون في البنيان', 'vol': 1, 'page': 50}, {'text': 'ثم انطلق فلبثت ملياً ثم قال يا عمر أتدري من السائل؟ قلت: الله ورسوله أعلم، قال فإنه جبريل أتاكم يعلمكم دينكم» .\\nرواه مسلم.', 'vol': 1, 'page': 51}, {'text': 'الحديث الثالث\\n«عن أبي عبد الرحمن عبد الله بن عمر بن الخطاب رضي الله تعالى عنهما قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: بني الإسلام على خمس: شهادة أن لا إله إلا الله وأن محمداً رسول الله، وإقام الصلاة، وإيتاء الزكاة، وحج البيت، وصوم رمضان» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 52}, {'text': 'الحديث الرابع\\n«عن أبي عبد الرحمن عبد الله بن مسعود \\ufd41 قال: حدثنا رسول الله صلى الله عليه وآله وسلم وهو الصادق المصدوق: إن أحدكم يجمع خلقه في بطن أمه أربعين يوماً نطفة، ثم يكون علقة مثل ذلك، ثم يكون مضغة مثل ذلك، ثم يرسل إليه الملك فينفخ فيه الروح ويؤمر بأربع كلمات: بكتب رزقه، وأجله، وعمله، وشقي أو سعيد،', 'vol': 1, 'page': 53}, {'text': 'فو الله الذي لا إله غيره إن أحدكم ليعمل بعمل أهل الجنة حتى ما يكون بينه وبينها إلا ذراع فيسبق عليه الكتاب فيعمل بعمل أهل النار فيدخلها، وإن أحدكم ليعمل بعمل أهل النار حتى ما يكون بينه وبينها إلا ذراع فيسبق عليه الكتاب فيعمل بعمل أهل الجنة فيدخلها» رواه البخاري ومسلم.', 'vol': 1, 'page': 54}, {'text': 'الحديث الخامس\\n«عن أم المؤمنين أم عبد الله عائشة \\ufd42 قالت: قال رسول الله صلى الله عليه وآله وسلم: من أحدث في أمرنا هذا ما ليس منه فهو رد» .\\nرواه البخاري ومسلم.\\nوفي رواية لمسلم «من عمل عملاً ليس عليه أمرنا فهو رد» .', 'vol': 1, 'page': 55}, {'text': 'الحديث السادس\\n«عن أبي عبد الله النعمان بن بشير \\ufd44 قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: إن الحلال بين وإن الحرام بين وبينهما أمور مشتبهات لا يعلمهن كثير من الناس، فمن اتقى الشبهات فقد استبرأ لدينه وعرضه، ومن وقع في الشبهات وقع في', 'vol': 1, 'page': 56}, {'text': 'الحرام كالراعي يرعى حول الحمى يوشك أن يرتع فيه، ألا وإن لكل ملك حمى، ألا وإن حمى الله محارمه، ألا وإن في الجسد مضغة إذا صلحت صلح الجسد كله وإذا فسدت فسد الجسد كله ألا وهي القلب» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 57}, {'text': 'الحديث السابع\\n«عن أبي رقية تميم بن أوس الداري رضي الله تعالى عنه أن النبي صلى الله عليه وآله وسلم قال الدين النصيحة.\\nقلنا: لمن؟ قال لله، ولكتابه، ولرسوله، ولأئمة المسلمين وعامتهم» .\\nرواه مسلم.', 'vol': 1, 'page': 58}, {'text': 'الحديث الثامن\\n«عن ابن عمر رضي الله تعالى عنهما أن رسول الله صلى الله تعالى عليه وعلى آله وسلم قال أمرت أن أقاتل الناس حتى يشهدوا أن لا إله إلا الله وأن محمداً رسول الله، ويقيموا الصلاة، ويؤتوا الزكاة: فإذا فعلوا ذلك عصموا مني دماءهم وأموالهم إلا بحق الإسلام وحسابهم على الله تعالى» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 59}, {'text': 'الحديث التاسع\\n«عن أبي هريرة عبد الرحمن بن صخر رضي الله تعالى عنه قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول مانهيتكم عنه فاجتنبوه، وما أمرتكم به فأتوا منه ما استطعتم، فإنما أهلك الذين من قبلكم كثرة مسائلهم واختلافهم على أنبيائهم» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 60}, {'text': 'الحديث العاشر\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم: إن الله تعالى طيب لا يقبل إلا طيباً، وإن الله أمر المؤمنين بما أمر به المرسلين فقال تعالى {يا أيها الرسل كلوا من الطيبات واعملوا صالحا} وقال تعالى {يا أيها الذين آمنوا كلوا من طيبات ما رزقناكم} ثم ذكر الرجل يطيل السفر أشعث أغبر يمد يديه إلى السماء: يا رب يا رب، ومطعمه حرام', 'vol': 1, 'page': 61}, {'text': 'وملبسه حرام وغذي بالحرام فأنى يستجاب له» .\\nرواه مسلم.', 'vol': 1, 'page': 62}, {'text': 'الحديث الحادي عشر\\n«عن أبي محمد الحسن بن علي بن أبي طالب سبط رسول الله صلى الله عليه وآله وسلم وريحانته \\ufd44 قال: حفظت من رسول الله صلى الله عليه وآله وسلم دع ما يريبك إلى ما لا يريبك» .\\nرواه الترمذي والنسائي، وقال الترمذي: حديث حسن صحيح.', 'vol': 1, 'page': 63}, {'text': 'الحديث الثانى عشر\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم من حسن إسلام المرء تركه ما لا يعنيه» .\\nحديث حسن، رواه الترمذي وغيره وهكذا.', 'vol': 1, 'page': 64}, {'text': 'الحديث الثالث عشر\\n«عن أبي حمزة أنس بن مالك رضي الله تعالى عنه خادم رسول الله صلى الله عليه وآله وسلم عن النبي صلى الله عليه وآله وسلم قال لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 65}, {'text': 'الحديث الرابع عشر\\n«عن ابن مسعود رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم لا يحل دم امرئ مسلم إلا بإحدى ثلاث: الثيب الزاني، والنفس بالنفس، والتارك لدينه المفارق للجماعة» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 66}, {'text': 'الحديث الخامس عشر\\n«عن أبي هريرة رضي الله تعالى عنه أن رسول الله صلى الله عليه وآله وسلم قال: من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت، ومن كان يؤمن بالله واليوم الآخر فليكرم جاره، ومن كان يؤمن بالله واليوم الآخر فليكرم ضيفه» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 67}, {'text': 'الحديث السادس عشر\\n«عن أبي هريرة رضي الله تعالى عنه أن رجلاً قال للنبي صلى الله عليه وآله وسلم: أوصني، قال لا تغضب فردد مراراً، قال لا تغضب» .\\nرواه البخاري.', 'vol': 1, 'page': 68}, {'text': 'الحديث السابع عشر\\n«عن أبي يعلى شداد بن أوس رضي الله تعالى عنه عن رسول الله صلى الله عليه وآله وسلم قال إن الله كتب الإحسان على كل شئ، فإذا قتلتم فأحسنوا القتلة وإذا ذبحتم فأحسنوا الذبحة، وليحد أحدكم شفرته وليرح ذبيحته» .\\nرواه مسلم.', 'vol': 1, 'page': 69}, {'text': 'الحديث الثامن عشر\\n«عن أبي ذر جندب بن جنادة، وأبي عبد الرحمن معاذ بن جبل رضي الله تعالى عنهما عن رسول الله صلى الله عليه وآله وسلم قال: إتق الله حيثما كنت، وأتبع السيئة الحسنة تمحها، وخالق الناس بخلق حسن» .\\nرواه الترمذي وقال: حديث حسن، وفي بعض النسخ: حسن صحيح.', 'vol': 1, 'page': 70}, {'text': 'الحديث التاسع عشر\\n«عن أبي العباس عبد الله بن عباس رضي الله تعالى عنهما قال: كنت خلف النبي صلى الله عليه وآله وسلم يوماً فقال يا غلام، إني أعلمك كلمات: إحفظ الله يحفظك، إحفظ الله تجده تجاهك، إذا سألت فاسأل الله، وإذا استعنت فاستعن بالله، واعلم أن الأمة لو اجتمعت على أن ينفعوك بشئ لم ينفعوك إلا بشئ قد كتبه الله لك،', 'vol': 1, 'page': 71}, {'text': 'وإن اجتمعوا على أن يضروك بشئ لم يضروك إلا بشئ قد كتبه الله عليك، رفعت الأقلام وجفت الصحف» .\\nرواه الترمذي وقال حديث حسن صحيح.\\nوفي رواية غير الترمذي «إحفظ الله تجده أمامك، تعرف إلى الله في الرخاء يعرفك في الشدة، واعلم أن ما أخطأك لم يكن ليصيبك، وما أصابك لم يكن ليخطئك، واعلم أن النصر مع الصبر، وأن الفرج مع الكرب، وأن مع العسر يسراً» .', 'vol': 1, 'page': 72}, {'text': 'الحديث العشرون\\n«عن أبي مسعود عقبة بن عمرو الأنصاري البدري \\ufd41 قال: قال رسول الله صلى الله عليه وآله وسلم: إن مما أدرك الناس من كلام النبوة الأولى: إذا لم تستح فاصنع ما شئت» .\\nرواه البخاري.', 'vol': 1, 'page': 73}, {'text': 'الحديث الحادي والعشرون\\n«عن أبي عمرو - وقيل أبي عمرة - سفيان ابن عبد الله \\ufd41 قال: قلت يا رسول الله قل لي في الإسلام قولاً لا أسال عنه أحداً غيرك، قال قل آمنت بالله، ثم استقم» .\\nرواه مسلم.', 'vol': 1, 'page': 74}, {'text': 'الحديث الثانى والعشرون\\n«عن أبي عبد الله جابر بن عبد الله الأنصاري \\ufd44 أن رجلاً سأل رسول الله صلى الله عليه وآله وسلم فقال: أرأيت إذا صليت المكتوبات، وصمت رمضان، وأحللت الحلال، وحرمت الحرام، ولم أزد على ذلك شيئاً، أدخل الجنة؟ قال نعم» .\\nرواه مسلم.\\nومعنى حرمت الحرام: اجتنبته،', 'vol': 1, 'page': 75}, {'text': 'ومعنى أحللت الحلال: فعلته معتقداً حله.', 'vol': 1, 'page': 76}, {'text': 'الحديث الثالث والعشرون\\n«عن أبي مالك الحارث بن الأشعري \\ufd41 قال: قال رسول الله صلى الله عليه وآله وسلم الطهور شطر الإيمان، والحمد لله تملأ الميزان، وسبحان الله والحمد لله تملآن - أو تملأ - ما بين', 'vol': 1, 'page': 77}, {'text': 'السماء والأرض، والصلاة نور، والصدقة برهان، والصبر ضياء، والقرآن حجة لك أو عليك، كل الناس يغدو: فبائع نفسه فمعتقها أو موبقها» .\\nرواه مسلم.', 'vol': 1, 'page': 78}, {'text': 'الحديث الرابع والعشرون\\n«عن أبي ذر الغفاري رضي الله تعالى عنه عن النبي صلى الله تعالى عليه وآله وسلم فيما يرويه عن ربه \\ufdff أنه قال يا عبادي، إني حرمت الظلم على نفسي وجعلته بينكم محرماً فلا تظالموا،', 'vol': 1, 'page': 79}, {'text': 'يا عبادي، كلكم ضال إلا من هديته فاستهدوني أهدكم، يا عبادي، كلكم جائع إلا من أطعمته فاستطعموني أطعمكم، يا عبادي، كلكم عار إلا من كسوته فاستكسوني أكسكم: يا عبادي، إنكم تخطئون بالليل والنهار وأنا أغفر الذنوب جميعاً فاستغفروني أغفر لكم، ياعبادي، إنكم لن تبلغوا ضري فتضروني ولن تبلغوا نفعي فتنفعوني، يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم كانوا على أتقى قلب رجل واحد منكم ما زاد ذلك في ملكي شيئاً:', 'vol': 1, 'page': 80}, {'text': 'يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم كانوا على أفجر قلب رجل واحد منكم ما نقص ذلك من ملكي شيئاً: يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم قاموا في صعيد واحد فسألوني فأعطيت كل واحد مسألته ما نقص ذلك مما عندي إلا كما ينقص المخيط إذا أدخل البحر، يا عبادي، إنما هي أعمالكم أحصيها لكم ثم أوفيكم إياها فمن وجد خيراً فليحمد الله ومن', 'vol': 1, 'page': 81}, {'text': 'وجد غير ذلك فلا يلومن إلا نفسه» .\\nرواه مسلم.', 'vol': 1, 'page': 82}, {'text': 'الحديث الخامس والعشرون\\n«عن أبي ذر \\ufd41 أيضاً أن ناساً من أصحاب رسول الله صلى الله عليه وآله وسلم قالوا للنبي صلى الله تعالى وعليه وآله وسلم: يا رسول الله، ذهب أهل الدثور بالأجور: يصلون كما نصلي ويصومون كما نصوم، ويتصدقون بفضول أموالهم.\\nقال: أوليس قد جعل الله لكم ما تصدقون: إن بكل تسبيحة صدقة، وكل تكبيرة صدقة، وكل', 'vol': 1, 'page': 83}, {'text': 'تحميدة صدقة، وكل تهليلة صدقة، وأمر بمعروف صدقة، ونهي عن منكر صدقة، وفي بضع أحدكم صدقة، قالوا: يا رسول الله، أيأتي أحدنا شهوته ويكون له فيها أجر؟ قال أرأيتم لو وضعها في حرام أكان عليه وزر؟ فكذلك إذا وضعها في الحلال كان له أجر» .\\nرواه مسلم.', 'vol': 1, 'page': 84}, {'text': 'الحديث السادس والعشرون\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم كل سلامى من الناس عليه صدقة كل يوم تطلع فيه الشمس: تعدل بين اثنين صدقة، وتعين الرجل في دابته فتحمله عليها أو ترفع', 'vol': 1, 'page': 85}, {'text': 'له عليها متاعه صدقة، والكلمة الطيبة صدقة، وبكل خطوة تمشيها إلى الصلاة صدقة، وتميط الأذى عن الطريق صدقة» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 86}, {'text': 'الحديث السابع والعشرون\\n«عن النواس بن سمعان رضي الله تعالى عنه عن النبي صلى الله عليه وعلى آله وسلم قال البر حسن الخلق، والإثم ما حاك في نفسك وكرهت أن يطلع عليه الناس» .\\nرواه مسلم\\nوعن وابصة بن معبد رضي الله تعالى عنه قال: «أتيت رسول الله صلى الله عليه وآله وسلم فقال: جئت تسأل عن البر؟ قلت: نعم، وقال: إستفت قلبك، البر ما', 'vol': 1, 'page': 87}, {'text': 'اطمأنت إليه النفس واطمأن إليه القلب، والإثم ما حاك في النفس وتردد في الصدر وإن أفتاك الناس وأفتوك» .\\nحديث حسن.\\nرويناه في مسندي الإمامين أحمد بن حنبل والدرامي بإسناد حسن.', 'vol': 1, 'page': 88}, {'text': 'الحديث الثامن والعشرون\\n«عن أبي نجيح العرباض بن سارية رضي الله تعالى عنه قال: وعظنا رسول الله صلى الله عليه وآله وسلم موعظة وجلت منها القلوب وذرفت منها العيون، فقلنا: يا رسول الله كأنها موعظة مودع فأوصنا، قال أوصيكم بتقوى الله \\ufdff والسمع والطاعة وإن تأمر عليكم عبد،', 'vol': 1, 'page': 89}, {'text': 'فإنه من يعش منكم فسيري اختلافاً كثيراً، فعليكم بسنتي وسنة الخلفاء الراشدين المهديين عضوا عليها بالنواجذ، وإياكم ومحدثات الأمور فإن كل بدعة ضلالة» .\\nرواه أبو داود والترمذي وقال: حديث حسن صحيح.', 'vol': 1, 'page': 90}, {'text': 'الحديث التاسع والعشرون\\n«عن معاذ بن جبل \\ufd41 قال: قلت يا رسول الله أخبرني بعمل يدخلني الجنة ويباعدني عن النار، قال: لقد سألت عن عظيم وإنه ليسير على من يسره الله تعالى عليه: تعبد الله لا تشرك به شيئاً، وتقيم الصلاة، وتؤتي الزكاة، وتصوم رمضان، وتحج البيت ثم قال: ألا أدلك على أبواب الخير؟ : الصوم جنة، والصدقة تطفئ الخطيئة كما يطفئ الماء النار، وصلاة الرجل في جوف الليل', 'vol': 1, 'page': 91}, {'text': 'ثم تلا: {تتجافى جنوبهم عن المضاجع} {حتى إذا بلغ} {يعملون} ثم قال ألا أخبرك برأس الأمر وعموده وذروة سنامه؟ قلت: بلى يا رسول الله.\\nقال رأس الأمر الإسلام، وعموده الصلاة، وذروة سنامه الجهاد', 'vol': 1, 'page': 92}, {'text': 'ثم قال: ألا أخبرك بملاك ذلك كله؟ قلت: بلى يا رسول الله، فأخذ بلسانه وقال كف عليك هذا قلت: يا نبي الله، وإنا لمؤاخذون بما نتكلم به؟ فقال ثكلتك أمك، وهل يكب الناس في النار على وجوههم - أو قال على مناخرهم - إلا حصائد ألسنتهم؟» .\\nرواه الترمذي وقال: حديث حسن صحيح.', 'vol': 1, 'page': 93}, {'text': 'الحديث الثلاثون\\n«عن أبي ثعلبة الخشبي جرثوم بن ناشر رضي الله تعالى عنه عن رسول الله ﷺ قال إن الله تعالى فرض فرائض فلا تضيعوها، وحد حدوداً فلا تعتدوها، وحرم أشياء فلا تنتهكوها،', 'vol': 1, 'page': 94}, {'text': 'وسكت عن أشياء رحمة لكم غير نسيان فلا تبحثوا عنها» .\\nحديث حسن رواه الدارقطني وغيره.', 'vol': 1, 'page': 95}, {'text': 'الحديث الحادي والثلاثون\\n«عن أبي العباس سهل بن سعد الساعدى رضي الله تعالى عنه قال جاء رجل إلى النبي صلى الله عليه وآله وسلم فقال: يا رسول الله، دلني على عمل إذا عملته أحبني الله وأحبني الناس: فقال إزهد في الدنيا يحبك الله، وازهد فيما عند الناس يحبك الناس» .\\nحديث حسن، رواه ابن ماجة وغيره بأسانيد حسنة.', 'vol': 1, 'page': 96}, {'text': 'الحديث الثاني والثلاثون\\n«عن أبي سعيد سعد بن مالك بن سنان الخدري رضي الله تعالى عنه أن رسول الله صلى الله وعليه وآله وسلم قال: لا ضرر ولا ضرار» .\\nحديث حسن، رواه ابن ماجة والدارقطني وغيرهما مسنداً.', 'vol': 1, 'page': 97}, {'text': 'ورواه مالك في الموطإ مرسلاً عن عمرو بن يحيى عن أبيه عن النبي صلى الله عليه وآله وسلم، فأسقط أبا سعيد، وله طرق يقوي بعضها بعضاً.', 'vol': 1, 'page': 98}, {'text': 'الحديث الثالث والثلاثون\\n«عن ابن عباس \\ufd44 أن رسول الله صلى الله عليه وآله وسلم قال: لو يعطى الناس بدعواهم لادعى رجال أموال قوم ودماءهم، لكن البينة على المدعى واليمين على من أنكر» .\\nحديث حسن، رواه البيهقي وغيره هكذا، وبعضه في الصحيحين.', 'vol': 1, 'page': 99}, {'text': 'الحديث الرابع والثلاثون\\n«عن أبي سعيد الخدري \\ufd41 قال: سمعت رسول الله صلى الله عليه وآله وسلم يقوم: من رأى منكم منكراً فليغيره بيده، فإن لم يستطع فبلسانه، فإن لم يستطع فبقلبه، وذلك أضعف الإيمان» .\\nرواه مسلم.', 'vol': 1, 'page': 100}, {'text': 'الحديث الخامس والثلاثون\\n«عن أبي هريرة \\ufd41 قال: قال رسول الله صلى الله عليه وآله وسلم لا تحاسدوا، ولا تناجشوا ولا تباغضوا، ولا تدابروا، ولا يبع بعضكم على بيع بعض، وكونوا عباد الله إخواناً، المسلم أخو المسلم لا يظلمه ولا يخذله ولا يكذبه ولا يحقره، التقوى ههنا - ويشير', 'vol': 1, 'page': 101}, {'text': 'إلى صدور ثلاث مرات - بحسب امرئ من الشر أن يحقر أخاه المسلم، كل المسلم على المسلم حرام: دمه وماله وعرضه» .\\nرواه مسلم.', 'vol': 1, 'page': 102}, {'text': 'الحديث السادس والثلاثون\\n«عن أبي هريرة \\ufd41 عن النبي صلى الله عليه وآله وسلم قال من نفس عن مؤمن كربة من كرب الدنيا نفس الله عنه كربة من كرب يوم القيامة، ومن يسر على معسر يسر الله عليه في الدنيا والآخرة، ومن ستر مسلماً ستره الله في الدنيا والآخرة، والله في عون العبد ما كان العبد في عون أخيه، ومن سلك طريقاً يلتمس فيه علماً سهل الله له به طريقاً إلى الجنة، وما اجتمع قوم في بيت من بيوت الله يتلون كتاب الله ويتدارسونه بينهم إلا نزلت عليهم السكينة', 'vol': 1, 'page': 103}, {'text': 'وغشيتهم الرحمة وحفتهم الملائكة وذكرهم الله فيمن عنده، ومن بطأ به عمله لم يسرع به نسبه» .\\nرواه مسلم بهذا اللفظ.', 'vol': 1, 'page': 104}, {'text': 'الحديث السابع والثلاثون\\n«عن ابن عباس \\ufd44 عن رسول الله صلى الله عليه وآله وسلم فيما يرويه عن ربه تبارك وتعالى قال إن الله كتب الحسنات والسيئات ثم بين ذلك، فمن هم بحسنة فلم يعملها كتبها الله عنده حسنة كاملة، وإن هم بها فعملها كتبها الله عنده عشر حسنات إلى سبعمائة ضعف إلى أضعاف كثيرة، وإن هم بسيئة فلم يعملها كتبها الله عنده حسنة كاملة، وإن هم بها فعملها كتبها الله سيئة واحدة» .', 'vol': 1, 'page': 105}, {'text': 'رواه البخاري ومسلم في صحيحيهما بهذه الحروف فانظر يا أخي وفقنا الله وإياك إلى عظيم لطف الله تعالى، وتأمل هذه الألفاظ، وقوله عنده إشارة إلى الإعتناء بها، وقوله كاملة للتأكيد وشدة الإعتناء بها، وقال في السيئة التي هم بها ثم تركها كتبها الله عنه حسنة كاملة فأكدها بـ (كاملة) وإن عملها كتبها سيئة واحدة، فأكد تقليلها', 'vol': 1, 'page': 106}, {'text': 'بـ (واحدة) ولم يؤكدها بـ (كاملة) فلله الحمد والمنة، سبحانه لا نحصي ثناء عليه، وبالله التوفيق.', 'vol': 1, 'page': 107}, {'text': 'الحديث الثامن والثلاثون\\n«عن أبي هريرة \\ufd41 قال: قال رسول الله صلى الله عليه وآله وسلم: إن الله تعالى قال: من عادى لي ولياً فقد آذنته بالحرب، وما تقرب إلى عبدي بشئ أحب إلي مما افترضته عليه، ولا يزال عبدي يتقرب إلي', 'vol': 1, 'page': 108}, {'text': 'بالنوافل حتى أحبه، فإذا أحببته كنت سمعه الذي يسمع به وبصره الذي يبصر به ويده التي يبطش بها ورجله التي يمشي بها، ولئن سألني لأعطينه، ولئن استعاذني لأعيذنه» .\\nرواه البخاري.', 'vol': 1, 'page': 109}, {'text': 'الحديث التاسع والثلاثون\\n«عن ابن عباس \\ufd44 أن رسول الله صلى الله عليه وآله وسلم قال إن الله تجاوز لي عن أمتى الخطأ والنسيان وما اسكترهوا عليه» .\\nحديث حسن رواه ابن ماجة والبيهقي وغيرهما.', 'vol': 1, 'page': 110}, {'text': 'الحديث الأربعون\\n«عن ابن عمر \\ufd44 قال: أخذ رسول الله صلى الله عليه وآله وسلم بمنكبي فقال: كن في الدنيا كأنك غريب أو عابر سبيل» وكان ابن عمر رضي الله تعالى عنهما يقول: إذا أمسيت فلا تنتظر الصباح، وإذا أصبحت فلا تنتظر', 'vol': 1, 'page': 111}, {'text': 'المساء، وخذ من صحتك لمرضك، ومن حياتك لموتك.\\nرواه البخاري.', 'vol': 1, 'page': 112}, {'text': 'الحديث الحادي والأربعون\\n«عن أبي محمد عبد الله بن عمرو بن العاص \\ufd44 قال: قال رسول الله صلى الله عليه وآله وسلم: لا يؤمن أحدكم حتى يكون هواه تبعاً لما جئت به» .\\nحديث حسن صحيح، رويناه في كتاب الحجة بإسناد صحيح.', 'vol': 1, 'page': 113}, {'text': 'الحديث الثاني والأربعون\\n«عن أنس \\ufd41 قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: قال الله تعالى يابن آدم، إنك ما دعوتني ورجوتني غفرت للك على ما كان منك ولا أبالي، يا ابن آدم لو بلغت ذنوبك عنان السماء ثم', 'vol': 1, 'page': 114}, {'text': 'استغفرتني غفرت لك، يا ابن آدم لو أتيتني بقراب الأرض خطايا ثم لقيتني لا تشرك بي شيئاً لأتيتك بقرابها مغفرة» .\\nرواه الترمذي وقال: حديث حسن صحيح.', 'vol': 1, 'page': 115}]	{"meta": {"id": 12836, "info": "", "name": "الأربعون النووية", "size": 39275, "betaka": "الكتاب: الأربعون النووية\\nالمؤلف: أبو زكريا محيي الدين يحيى بن شرف النووي (المتوفى: 676هـ)\\nعُنِيَ بِهِ: قصي محمد نورس الحلاق، أنور بن أبي بكر الشيخي\\nالناشر: دار المنهاج للنشر والتوزيع، لبنان - بيروت\\nالطبعة: الأولى، 1430 هـ - 2009 م\\nعدد الأجزاء: 1\\n[ترقيم الكتاب موافق للمطبوع]", "author_id": 44, "categories": ["الرقاق والآداب والأذكار"], "page_count": 81}, "pages": [{"vol": 1, "page": 35, "text": "بسم الله الرحمن الرحيم\\n\\nمقدمة المؤلف\\nالحمد لله رب العالمين قيوم السموات والأرضين. مدبر الخلائق أجمعين. باعث الرسل - صلواته وسلامه عليهم- إلى المكلفين لهدايتهم وبيان شرائع الدين بالدلائل القطعية، وواضحات البراهين."}, {"vol": 1, "page": 36, "text": "أحمده على جميع نعمه. وأسأله المزيد من فضله وكرمه.\\nوأشهد أن لا إله إلا الله الواحد القهار. الكريم الغفار وأشهد أن سيدنا محمداً عبده ورسوله وحبيبه وخليله أفضل المخلوقين، المكرم بالقرآن العزيز المعجزة المستمرة على تعاقب السنين، وبالسنن المستنيرة للمسترشدين المخصوص بجوامع الكلم وسماحة الدين صلوات الله وسلامه عليه وعلى سائر النبيين والمرسلين وآل كل وسائر الصالحين."}, {"vol": 1, "page": 37, "text": "أما بعد: فقد روينا عن علي بن أبي طالب، وعبد الله بن مسعود، ومعاذ بن جبل، وأبي الدرداء، وابن عمر، وابن عباس، وأنس بن مالك، وأبي هريرة، وأبي سعيد الخدري رضي الله تعالى عنهم من طرق كثيرات بروايات متنوعات: أن رسول الله ﷺ قال: \\"من حفظ على أمتي أربعين حديثاً من أمر دينها"}, {"vol": 1, "page": 38, "text": "بعثه الله يوم القيامة في زمرة الفقهاء والعلماء\\" وفي رواية: \\"بعثه الله فقيها عالما\\".\\nوفي رواية أبي الدرداء: \\"وكنت له يوم القيامة شافعا وشهيدا\\". وفي رواية ابن مسعود: قيل له: \\"ادخل من أي أبوب الجنة شئت\\" وفي رواية ابن عمر \\"كُتِب في زمرة العلماء وحشر في زمرة الشهداء\\". واتفق الحفاظ على أنه حديث ضعيف وإن كثرت طرقه."}, {"vol": 1, "page": 39, "text": "وقد صنّف العلماء رضي الله تعالى عنهم في هذا الباب ما لا يُحصى من المصنّفات. فأول من علمته صنف فيه: عبد الله بن المبارك، ثم محمد بن أسلم الطوسي العالم الرباني، ثم الحسن بن سفيان النسائي، وأبو بكر"}, {"vol": 1, "page": 40, "text": "الآجري، وأبو بكر بن إبراهيم الأصفهاني، والدارقطني، والحاكم،"}, {"vol": 1, "page": 41, "text": "وأبو نعيم، وأبو عبد الرحمن السلميّ، وأبو سعيد الماليني، وأبو عثمان الصابوني، وعبد الله بن"}, {"vol": 1, "page": 42, "text": "محمد الأنصاري. وأبو بكر البيهقي، وخلائق لا يحصون من المتقدمين والمتأخرين، وقد استخرت الله تعالى في جمع أربعين حديثاً اقتداء بهؤلاء الأئمة الأعلام وحفاظ الإسلام. وقد اتفق العلماء على جواز العمل بالحديث الضعيف"}, {"vol": 1, "page": 43, "text": "في فضائل الأعمال.\\nومع هذا فليس اعتمادي على هذا الحديث، بل على قوله ﷺ في الأحاديث الصحيحة: \\"ليبلغ الشاهد منكم الغائب\\" وقوله ﷺ: \\"نضر الله امرأً سمع مقالتي فوعاها فأدّاها كما سمعها\\".\\nثم من العلماء من جمع الأربعين في أصول الدين، وبعضهم في الفروع، وبعضهم في الجهاد، وبعضهم في الزهد، وبعضهم في الآداب، وبعضهم في الخطب،"}, {"vol": 1, "page": 44, "text": "وكلها مقاصة صالحة رضي الله تعالى عن قاصديها.\\nقد رأيت جمع أربعين أهم من هذا كله، وهي أربعون حديثاً مشتملة على جميع ذلك، وكل حديث منها قاعدة عظيمة من قواعد الدين قد وصفه العلماء بأن مدار الإسلام عليه، أو هو نصف الإسلام أو ثلثه أو نحو ذلك.\\nثم ألتزم في هذه الأربعين أن تكون صحيحة، ومعظمها في صحيحي البخاري ومسلم،"}, {"vol": 1, "page": 45, "text": "وأذكرها محذوفة الأسانيد، ليسهل حفظها، ويعم الانتفاع بها إن شاء الله تعالى، ثم أُتبعها بباب في ضبط خفي ألفاظها. وينبغي لكل راغب في الآخرة أن يعرف هذه الأحاديث، لما اشتملت عليه من المهمات، واحتوت عليه من التنبيه على جميع الطاعات وذلك ظاهر لمن تدبّره، وعلى الله اعتمادي، وإليه تفويضي واستنادي وله الحمد والنعمة، وبه التوفيق والعصمة."}, {"vol": 1, "page": 46, "text": "الحديث الأول\\n«عن أمير المؤمنين أبي حفص عمر بن الخطاب رضي الله تعالى عنه قال: سمعت رسول الله صلى الله تعالى عليه وعلى آله وسلم يقول: إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى، فمن كانت هجرته إلى الله ورسوله فهجرته إلى الله ورسوله، ومن كانت هجرته لدنيا يصيبها أو امرأة ينكحها فهجرته إلى ما هاجر إليه» .\\nرواه إماما المحدثين:"}, {"vol": 1, "page": 47, "text": "أبو عبد الله محمد ابن إسماعيل بن إبراهيم بن المغيرة بن بردزبه البخاري، وأبو الحسين مسلم ابن الحجاج بن مسلم القشيري النيسابوري: في صحيحيهما اللذين هما أصح الكتب المصنفة."}, {"vol": 1, "page": 48, "text": "الحديث الثاني\\n«عن عمر رضي الله تعالى عنه أيضاً قال: بينما نحن جلوس عند رسول الله صلى الله عليه وآله وسلم ذات يوم إذ طلع علينا رجل شديد بياض الثياب شديد سواد الشعر لا يرى عليه أثر السفر ولا يعرفه منا أحد، حتى جلس إلى النبي صلى الله عليه وآله وسلم فأسند ركبتيه إلى ركبتيه ووضع كفيه على فخذيه وقال: يا محمد أخبرني عن الإسلام،"}, {"vol": 1, "page": 49, "text": "فقال رسول الله صلى الله عليه وآله وسلم: الإسلام أن تشهد أن لا إله إلا الله وأن محمداً رسول الله، وتقيم الصلاة، وتؤتي الزكاة، وتصوم رمضان، وتحج البيت إن استطعت إليه سبيلاً قال: صدقت، فعجبنا له يسأله ويصدقه.\\nقال: فأخبرني عن الإيمان، قال أن تؤمن بالله وملائكته وكتبه ورسله واليوم الآخر، وتؤمن بالقدر خيره وشره، قال: صدقت، قال: فأخبرني عن الإحسان، قال أن تعبد الله كأنك تراه، فإن لم تكن تراه فإنه يراك،"}, {"vol": 1, "page": 50, "text": "قال: فأخبرني عن الساعة، قال ما المسئول عنها بأعلم من السائل، قال: فأخبرني عن أماراتها، قال أن تلد الأمة ربتها، وأن ترى الحفاة العراة العالة رعاء الشاء يتطاولون في البنيان"}, {"vol": 1, "page": 51, "text": "ثم انطلق فلبثت ملياً ثم قال يا عمر أتدري من السائل؟ قلت: الله ورسوله أعلم، قال فإنه جبريل أتاكم يعلمكم دينكم» .\\nرواه مسلم."}, {"vol": 1, "page": 52, "text": "الحديث الثالث\\n«عن أبي عبد الرحمن عبد الله بن عمر بن الخطاب رضي الله تعالى عنهما قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: بني الإسلام على خمس: شهادة أن لا إله إلا الله وأن محمداً رسول الله، وإقام الصلاة، وإيتاء الزكاة، وحج البيت، وصوم رمضان» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 53, "text": "الحديث الرابع\\n«عن أبي عبد الرحمن عبد الله بن مسعود ﵁ قال: حدثنا رسول الله صلى الله عليه وآله وسلم وهو الصادق المصدوق: إن أحدكم يجمع خلقه في بطن أمه أربعين يوماً نطفة، ثم يكون علقة مثل ذلك، ثم يكون مضغة مثل ذلك، ثم يرسل إليه الملك فينفخ فيه الروح ويؤمر بأربع كلمات: بكتب رزقه، وأجله، وعمله، وشقي أو سعيد،"}, {"vol": 1, "page": 54, "text": "فو الله الذي لا إله غيره إن أحدكم ليعمل بعمل أهل الجنة حتى ما يكون بينه وبينها إلا ذراع فيسبق عليه الكتاب فيعمل بعمل أهل النار فيدخلها، وإن أحدكم ليعمل بعمل أهل النار حتى ما يكون بينه وبينها إلا ذراع فيسبق عليه الكتاب فيعمل بعمل أهل الجنة فيدخلها» رواه البخاري ومسلم."}, {"vol": 1, "page": 55, "text": "الحديث الخامس\\n«عن أم المؤمنين أم عبد الله عائشة ﵂ قالت: قال رسول الله صلى الله عليه وآله وسلم: من أحدث في أمرنا هذا ما ليس منه فهو رد» .\\nرواه البخاري ومسلم.\\nوفي رواية لمسلم «من عمل عملاً ليس عليه أمرنا فهو رد» ."}, {"vol": 1, "page": 56, "text": "الحديث السادس\\n«عن أبي عبد الله النعمان بن بشير ﵄ قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: إن الحلال بين وإن الحرام بين وبينهما أمور مشتبهات لا يعلمهن كثير من الناس، فمن اتقى الشبهات فقد استبرأ لدينه وعرضه، ومن وقع في الشبهات وقع في"}, {"vol": 1, "page": 57, "text": "الحرام كالراعي يرعى حول الحمى يوشك أن يرتع فيه، ألا وإن لكل ملك حمى، ألا وإن حمى الله محارمه، ألا وإن في الجسد مضغة إذا صلحت صلح الجسد كله وإذا فسدت فسد الجسد كله ألا وهي القلب» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 58, "text": "الحديث السابع\\n«عن أبي رقية تميم بن أوس الداري رضي الله تعالى عنه أن النبي صلى الله عليه وآله وسلم قال الدين النصيحة.\\nقلنا: لمن؟ قال لله، ولكتابه، ولرسوله، ولأئمة المسلمين وعامتهم» .\\nرواه مسلم."}, {"vol": 1, "page": 59, "text": "الحديث الثامن\\n«عن ابن عمر رضي الله تعالى عنهما أن رسول الله صلى الله تعالى عليه وعلى آله وسلم قال أمرت أن أقاتل الناس حتى يشهدوا أن لا إله إلا الله وأن محمداً رسول الله، ويقيموا الصلاة، ويؤتوا الزكاة: فإذا فعلوا ذلك عصموا مني دماءهم وأموالهم إلا بحق الإسلام وحسابهم على الله تعالى» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 60, "text": "الحديث التاسع\\n«عن أبي هريرة عبد الرحمن بن صخر رضي الله تعالى عنه قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول مانهيتكم عنه فاجتنبوه، وما أمرتكم به فأتوا منه ما استطعتم، فإنما أهلك الذين من قبلكم كثرة مسائلهم واختلافهم على أنبيائهم» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 61, "text": "الحديث العاشر\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم: إن الله تعالى طيب لا يقبل إلا طيباً، وإن الله أمر المؤمنين بما أمر به المرسلين فقال تعالى {يا أيها الرسل كلوا من الطيبات واعملوا صالحا} وقال تعالى {يا أيها الذين آمنوا كلوا من طيبات ما رزقناكم} ثم ذكر الرجل يطيل السفر أشعث أغبر يمد يديه إلى السماء: يا رب يا رب، ومطعمه حرام"}, {"vol": 1, "page": 62, "text": "وملبسه حرام وغذي بالحرام فأنى يستجاب له» .\\nرواه مسلم."}, {"vol": 1, "page": 63, "text": "الحديث الحادي عشر\\n«عن أبي محمد الحسن بن علي بن أبي طالب سبط رسول الله صلى الله عليه وآله وسلم وريحانته ﵄ قال: حفظت من رسول الله صلى الله عليه وآله وسلم دع ما يريبك إلى ما لا يريبك» .\\nرواه الترمذي والنسائي، وقال الترمذي: حديث حسن صحيح."}, {"vol": 1, "page": 64, "text": "الحديث الثانى عشر\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم من حسن إسلام المرء تركه ما لا يعنيه» .\\nحديث حسن، رواه الترمذي وغيره وهكذا."}, {"vol": 1, "page": 65, "text": "الحديث الثالث عشر\\n«عن أبي حمزة أنس بن مالك رضي الله تعالى عنه خادم رسول الله صلى الله عليه وآله وسلم عن النبي صلى الله عليه وآله وسلم قال لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 66, "text": "الحديث الرابع عشر\\n«عن ابن مسعود رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم لا يحل دم امرئ مسلم إلا بإحدى ثلاث: الثيب الزاني، والنفس بالنفس، والتارك لدينه المفارق للجماعة» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 67, "text": "الحديث الخامس عشر\\n«عن أبي هريرة رضي الله تعالى عنه أن رسول الله صلى الله عليه وآله وسلم قال: من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت، ومن كان يؤمن بالله واليوم الآخر فليكرم جاره، ومن كان يؤمن بالله واليوم الآخر فليكرم ضيفه» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 68, "text": "الحديث السادس عشر\\n«عن أبي هريرة رضي الله تعالى عنه أن رجلاً قال للنبي صلى الله عليه وآله وسلم: أوصني، قال لا تغضب فردد مراراً، قال لا تغضب» .\\nرواه البخاري."}, {"vol": 1, "page": 69, "text": "الحديث السابع عشر\\n«عن أبي يعلى شداد بن أوس رضي الله تعالى عنه عن رسول الله صلى الله عليه وآله وسلم قال إن الله كتب الإحسان على كل شئ، فإذا قتلتم فأحسنوا القتلة وإذا ذبحتم فأحسنوا الذبحة، وليحد أحدكم شفرته وليرح ذبيحته» .\\nرواه مسلم."}, {"vol": 1, "page": 70, "text": "الحديث الثامن عشر\\n«عن أبي ذر جندب بن جنادة، وأبي عبد الرحمن معاذ بن جبل رضي الله تعالى عنهما عن رسول الله صلى الله عليه وآله وسلم قال: إتق الله حيثما كنت، وأتبع السيئة الحسنة تمحها، وخالق الناس بخلق حسن» .\\nرواه الترمذي وقال: حديث حسن، وفي بعض النسخ: حسن صحيح."}, {"vol": 1, "page": 71, "text": "الحديث التاسع عشر\\n«عن أبي العباس عبد الله بن عباس رضي الله تعالى عنهما قال: كنت خلف النبي صلى الله عليه وآله وسلم يوماً فقال يا غلام، إني أعلمك كلمات: إحفظ الله يحفظك، إحفظ الله تجده تجاهك، إذا سألت فاسأل الله، وإذا استعنت فاستعن بالله، واعلم أن الأمة لو اجتمعت على أن ينفعوك بشئ لم ينفعوك إلا بشئ قد كتبه الله لك،"}, {"vol": 1, "page": 72, "text": "وإن اجتمعوا على أن يضروك بشئ لم يضروك إلا بشئ قد كتبه الله عليك، رفعت الأقلام وجفت الصحف» .\\nرواه الترمذي وقال حديث حسن صحيح.\\nوفي رواية غير الترمذي «إحفظ الله تجده أمامك، تعرف إلى الله في الرخاء يعرفك في الشدة، واعلم أن ما أخطأك لم يكن ليصيبك، وما أصابك لم يكن ليخطئك، واعلم أن النصر مع الصبر، وأن الفرج مع الكرب، وأن مع العسر يسراً» ."}, {"vol": 1, "page": 73, "text": "الحديث العشرون\\n«عن أبي مسعود عقبة بن عمرو الأنصاري البدري ﵁ قال: قال رسول الله صلى الله عليه وآله وسلم: إن مما أدرك الناس من كلام النبوة الأولى: إذا لم تستح فاصنع ما شئت» .\\nرواه البخاري."}, {"vol": 1, "page": 74, "text": "الحديث الحادي والعشرون\\n«عن أبي عمرو - وقيل أبي عمرة - سفيان ابن عبد الله ﵁ قال: قلت يا رسول الله قل لي في الإسلام قولاً لا أسال عنه أحداً غيرك، قال قل آمنت بالله، ثم استقم» .\\nرواه مسلم."}, {"vol": 1, "page": 75, "text": "الحديث الثانى والعشرون\\n«عن أبي عبد الله جابر بن عبد الله الأنصاري ﵄ أن رجلاً سأل رسول الله صلى الله عليه وآله وسلم فقال: أرأيت إذا صليت المكتوبات، وصمت رمضان، وأحللت الحلال، وحرمت الحرام، ولم أزد على ذلك شيئاً، أدخل الجنة؟ قال نعم» .\\nرواه مسلم.\\nومعنى حرمت الحرام: اجتنبته،"}, {"vol": 1, "page": 76, "text": "ومعنى أحللت الحلال: فعلته معتقداً حله."}, {"vol": 1, "page": 77, "text": "الحديث الثالث والعشرون\\n«عن أبي مالك الحارث بن الأشعري ﵁ قال: قال رسول الله صلى الله عليه وآله وسلم الطهور شطر الإيمان، والحمد لله تملأ الميزان، وسبحان الله والحمد لله تملآن - أو تملأ - ما بين"}, {"vol": 1, "page": 78, "text": "السماء والأرض، والصلاة نور، والصدقة برهان، والصبر ضياء، والقرآن حجة لك أو عليك، كل الناس يغدو: فبائع نفسه فمعتقها أو موبقها» .\\nرواه مسلم."}, {"vol": 1, "page": 79, "text": "الحديث الرابع والعشرون\\n«عن أبي ذر الغفاري رضي الله تعالى عنه عن النبي صلى الله تعالى عليه وآله وسلم فيما يرويه عن ربه ﷿ أنه قال يا عبادي، إني حرمت الظلم على نفسي وجعلته بينكم محرماً فلا تظالموا،"}, {"vol": 1, "page": 80, "text": "يا عبادي، كلكم ضال إلا من هديته فاستهدوني أهدكم، يا عبادي، كلكم جائع إلا من أطعمته فاستطعموني أطعمكم، يا عبادي، كلكم عار إلا من كسوته فاستكسوني أكسكم: يا عبادي، إنكم تخطئون بالليل والنهار وأنا أغفر الذنوب جميعاً فاستغفروني أغفر لكم، ياعبادي، إنكم لن تبلغوا ضري فتضروني ولن تبلغوا نفعي فتنفعوني، يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم كانوا على أتقى قلب رجل واحد منكم ما زاد ذلك في ملكي شيئاً:"}, {"vol": 1, "page": 81, "text": "يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم كانوا على أفجر قلب رجل واحد منكم ما نقص ذلك من ملكي شيئاً: يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم قاموا في صعيد واحد فسألوني فأعطيت كل واحد مسألته ما نقص ذلك مما عندي إلا كما ينقص المخيط إذا أدخل البحر، يا عبادي، إنما هي أعمالكم أحصيها لكم ثم أوفيكم إياها فمن وجد خيراً فليحمد الله ومن"}, {"vol": 1, "page": 82, "text": "وجد غير ذلك فلا يلومن إلا نفسه» .\\nرواه مسلم."}, {"vol": 1, "page": 83, "text": "الحديث الخامس والعشرون\\n«عن أبي ذر ﵁ أيضاً أن ناساً من أصحاب رسول الله صلى الله عليه وآله وسلم قالوا للنبي صلى الله تعالى وعليه وآله وسلم: يا رسول الله، ذهب أهل الدثور بالأجور: يصلون كما نصلي ويصومون كما نصوم، ويتصدقون بفضول أموالهم.\\nقال: أوليس قد جعل الله لكم ما تصدقون: إن بكل تسبيحة صدقة، وكل تكبيرة صدقة، وكل"}, {"vol": 1, "page": 84, "text": "تحميدة صدقة، وكل تهليلة صدقة، وأمر بمعروف صدقة، ونهي عن منكر صدقة، وفي بضع أحدكم صدقة، قالوا: يا رسول الله، أيأتي أحدنا شهوته ويكون له فيها أجر؟ قال أرأيتم لو وضعها في حرام أكان عليه وزر؟ فكذلك إذا وضعها في الحلال كان له أجر» .\\nرواه مسلم."}, {"vol": 1, "page": 85, "text": "الحديث السادس والعشرون\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم كل سلامى من الناس عليه صدقة كل يوم تطلع فيه الشمس: تعدل بين اثنين صدقة، وتعين الرجل في دابته فتحمله عليها أو ترفع"}, {"vol": 1, "page": 86, "text": "له عليها متاعه صدقة، والكلمة الطيبة صدقة، وبكل خطوة تمشيها إلى الصلاة صدقة، وتميط الأذى عن الطريق صدقة» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 87, "text": "الحديث السابع والعشرون\\n«عن النواس بن سمعان رضي الله تعالى عنه عن النبي صلى الله عليه وعلى آله وسلم قال البر حسن الخلق، والإثم ما حاك في نفسك وكرهت أن يطلع عليه الناس» .\\nرواه مسلم\\nوعن وابصة بن معبد رضي الله تعالى عنه قال: «أتيت رسول الله صلى الله عليه وآله وسلم فقال: جئت تسأل عن البر؟ قلت: نعم، وقال: إستفت قلبك، البر ما"}, {"vol": 1, "page": 88, "text": "اطمأنت إليه النفس واطمأن إليه القلب، والإثم ما حاك في النفس وتردد في الصدر وإن أفتاك الناس وأفتوك» .\\nحديث حسن.\\nرويناه في مسندي الإمامين أحمد بن حنبل والدرامي بإسناد حسن."}, {"vol": 1, "page": 89, "text": "الحديث الثامن والعشرون\\n«عن أبي نجيح العرباض بن سارية رضي الله تعالى عنه قال: وعظنا رسول الله صلى الله عليه وآله وسلم موعظة وجلت منها القلوب وذرفت منها العيون، فقلنا: يا رسول الله كأنها موعظة مودع فأوصنا، قال أوصيكم بتقوى الله ﷿ والسمع والطاعة وإن تأمر عليكم عبد،"}, {"vol": 1, "page": 90, "text": "فإنه من يعش منكم فسيري اختلافاً كثيراً، فعليكم بسنتي وسنة الخلفاء الراشدين المهديين عضوا عليها بالنواجذ، وإياكم ومحدثات الأمور فإن كل بدعة ضلالة» .\\nرواه أبو داود والترمذي وقال: حديث حسن صحيح."}, {"vol": 1, "page": 91, "text": "الحديث التاسع والعشرون\\n«عن معاذ بن جبل ﵁ قال: قلت يا رسول الله أخبرني بعمل يدخلني الجنة ويباعدني عن النار، قال: لقد سألت عن عظيم وإنه ليسير على من يسره الله تعالى عليه: تعبد الله لا تشرك به شيئاً، وتقيم الصلاة، وتؤتي الزكاة، وتصوم رمضان، وتحج البيت ثم قال: ألا أدلك على أبواب الخير؟ : الصوم جنة، والصدقة تطفئ الخطيئة كما يطفئ الماء النار، وصلاة الرجل في جوف الليل"}, {"vol": 1, "page": 92, "text": "ثم تلا: {تتجافى جنوبهم عن المضاجع} {حتى إذا بلغ} {يعملون} ثم قال ألا أخبرك برأس الأمر وعموده وذروة سنامه؟ قلت: بلى يا رسول الله.\\nقال رأس الأمر الإسلام، وعموده الصلاة، وذروة سنامه الجهاد"}, {"vol": 1, "page": 93, "text": "ثم قال: ألا أخبرك بملاك ذلك كله؟ قلت: بلى يا رسول الله، فأخذ بلسانه وقال كف عليك هذا قلت: يا نبي الله، وإنا لمؤاخذون بما نتكلم به؟ فقال ثكلتك أمك، وهل يكب الناس في النار على وجوههم - أو قال على مناخرهم - إلا حصائد ألسنتهم؟» .\\nرواه الترمذي وقال: حديث حسن صحيح."}, {"vol": 1, "page": 94, "text": "الحديث الثلاثون\\n«عن أبي ثعلبة الخشبي جرثوم بن ناشر رضي الله تعالى عنه عن رسول الله ﷺ قال إن الله تعالى فرض فرائض فلا تضيعوها، وحد حدوداً فلا تعتدوها، وحرم أشياء فلا تنتهكوها،"}, {"vol": 1, "page": 95, "text": "وسكت عن أشياء رحمة لكم غير نسيان فلا تبحثوا عنها» .\\nحديث حسن رواه الدارقطني وغيره."}, {"vol": 1, "page": 96, "text": "الحديث الحادي والثلاثون\\n«عن أبي العباس سهل بن سعد الساعدى رضي الله تعالى عنه قال جاء رجل إلى النبي صلى الله عليه وآله وسلم فقال: يا رسول الله، دلني على عمل إذا عملته أحبني الله وأحبني الناس: فقال إزهد في الدنيا يحبك الله، وازهد فيما عند الناس يحبك الناس» .\\nحديث حسن، رواه ابن ماجة وغيره بأسانيد حسنة."}, {"vol": 1, "page": 97, "text": "الحديث الثاني والثلاثون\\n«عن أبي سعيد سعد بن مالك بن سنان الخدري رضي الله تعالى عنه أن رسول الله صلى الله وعليه وآله وسلم قال: لا ضرر ولا ضرار» .\\nحديث حسن، رواه ابن ماجة والدارقطني وغيرهما مسنداً."}, {"vol": 1, "page": 98, "text": "ورواه مالك في الموطإ مرسلاً عن عمرو بن يحيى عن أبيه عن النبي صلى الله عليه وآله وسلم، فأسقط أبا سعيد، وله طرق يقوي بعضها بعضاً."}, {"vol": 1, "page": 99, "text": "الحديث الثالث والثلاثون\\n«عن ابن عباس ﵄ أن رسول الله صلى الله عليه وآله وسلم قال: لو يعطى الناس بدعواهم لادعى رجال أموال قوم ودماءهم، لكن البينة على المدعى واليمين على من أنكر» .\\nحديث حسن، رواه البيهقي وغيره هكذا، وبعضه في الصحيحين."}, {"vol": 1, "page": 100, "text": "الحديث الرابع والثلاثون\\n«عن أبي سعيد الخدري ﵁ قال: سمعت رسول الله صلى الله عليه وآله وسلم يقوم: من رأى منكم منكراً فليغيره بيده، فإن لم يستطع فبلسانه، فإن لم يستطع فبقلبه، وذلك أضعف الإيمان» .\\nرواه مسلم."}, {"vol": 1, "page": 101, "text": "الحديث الخامس والثلاثون\\n«عن أبي هريرة ﵁ قال: قال رسول الله صلى الله عليه وآله وسلم لا تحاسدوا، ولا تناجشوا ولا تباغضوا، ولا تدابروا، ولا يبع بعضكم على بيع بعض، وكونوا عباد الله إخواناً، المسلم أخو المسلم لا يظلمه ولا يخذله ولا يكذبه ولا يحقره، التقوى ههنا - ويشير"}, {"vol": 1, "page": 102, "text": "إلى صدور ثلاث مرات - بحسب امرئ من الشر أن يحقر أخاه المسلم، كل المسلم على المسلم حرام: دمه وماله وعرضه» .\\nرواه مسلم."}, {"vol": 1, "page": 103, "text": "الحديث السادس والثلاثون\\n«عن أبي هريرة ﵁ عن النبي صلى الله عليه وآله وسلم قال من نفس عن مؤمن كربة من كرب الدنيا نفس الله عنه كربة من كرب يوم القيامة، ومن يسر على معسر يسر الله عليه في الدنيا والآخرة، ومن ستر مسلماً ستره الله في الدنيا والآخرة، والله في عون العبد ما كان العبد في عون أخيه، ومن سلك طريقاً يلتمس فيه علماً سهل الله له به طريقاً إلى الجنة، وما اجتمع قوم في بيت من بيوت الله يتلون كتاب الله ويتدارسونه بينهم إلا نزلت عليهم السكينة"}, {"vol": 1, "page": 104, "text": "وغشيتهم الرحمة وحفتهم الملائكة وذكرهم الله فيمن عنده، ومن بطأ به عمله لم يسرع به نسبه» .\\nرواه مسلم بهذا اللفظ."}, {"vol": 1, "page": 105, "text": "الحديث السابع والثلاثون\\n«عن ابن عباس ﵄ عن رسول الله صلى الله عليه وآله وسلم فيما يرويه عن ربه تبارك وتعالى قال إن الله كتب الحسنات والسيئات ثم بين ذلك، فمن هم بحسنة فلم يعملها كتبها الله عنده حسنة كاملة، وإن هم بها فعملها كتبها الله عنده عشر حسنات إلى سبعمائة ضعف إلى أضعاف كثيرة، وإن هم بسيئة فلم يعملها كتبها الله عنده حسنة كاملة، وإن هم بها فعملها كتبها الله سيئة واحدة» ."}, {"vol": 1, "page": 106, "text": "رواه البخاري ومسلم في صحيحيهما بهذه الحروف فانظر يا أخي وفقنا الله وإياك إلى عظيم لطف الله تعالى، وتأمل هذه الألفاظ، وقوله عنده إشارة إلى الإعتناء بها، وقوله كاملة للتأكيد وشدة الإعتناء بها، وقال في السيئة التي هم بها ثم تركها كتبها الله عنه حسنة كاملة فأكدها بـ (كاملة) وإن عملها كتبها سيئة واحدة، فأكد تقليلها"}, {"vol": 1, "page": 107, "text": "بـ (واحدة) ولم يؤكدها بـ (كاملة) فلله الحمد والمنة، سبحانه لا نحصي ثناء عليه، وبالله التوفيق."}, {"vol": 1, "page": 108, "text": "الحديث الثامن والثلاثون\\n«عن أبي هريرة ﵁ قال: قال رسول الله صلى الله عليه وآله وسلم: إن الله تعالى قال: من عادى لي ولياً فقد آذنته بالحرب، وما تقرب إلى عبدي بشئ أحب إلي مما افترضته عليه، ولا يزال عبدي يتقرب إلي"}, {"vol": 1, "page": 109, "text": "بالنوافل حتى أحبه، فإذا أحببته كنت سمعه الذي يسمع به وبصره الذي يبصر به ويده التي يبطش بها ورجله التي يمشي بها، ولئن سألني لأعطينه، ولئن استعاذني لأعيذنه» .\\nرواه البخاري."}, {"vol": 1, "page": 110, "text": "الحديث التاسع والثلاثون\\n«عن ابن عباس ﵄ أن رسول الله صلى الله عليه وآله وسلم قال إن الله تجاوز لي عن أمتى الخطأ والنسيان وما اسكترهوا عليه» .\\nحديث حسن رواه ابن ماجة والبيهقي وغيرهما."}, {"vol": 1, "page": 111, "text": "الحديث الأربعون\\n«عن ابن عمر ﵄ قال: أخذ رسول الله صلى الله عليه وآله وسلم بمنكبي فقال: كن في الدنيا كأنك غريب أو عابر سبيل» وكان ابن عمر رضي الله تعالى عنهما يقول: إذا أمسيت فلا تنتظر الصباح، وإذا أصبحت فلا تنتظر"}, {"vol": 1, "page": 112, "text": "المساء، وخذ من صحتك لمرضك، ومن حياتك لموتك.\\nرواه البخاري."}, {"vol": 1, "page": 113, "text": "الحديث الحادي والأربعون\\n«عن أبي محمد عبد الله بن عمرو بن العاص ﵄ قال: قال رسول الله صلى الله عليه وآله وسلم: لا يؤمن أحدكم حتى يكون هواه تبعاً لما جئت به» .\\nحديث حسن صحيح، رويناه في كتاب الحجة بإسناد صحيح."}, {"vol": 1, "page": 114, "text": "الحديث الثاني والأربعون\\n«عن أنس ﵁ قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: قال الله تعالى يابن آدم، إنك ما دعوتني ورجوتني غفرت للك على ما كان منك ولا أبالي، يا ابن آدم لو بلغت ذنوبك عنان السماء ثم"}, {"vol": 1, "page": 115, "text": "استغفرتني غفرت لك، يا ابن آدم لو أتيتني بقراب الأرض خطايا ثم لقيتني لا تشرك بي شيئاً لأتيتك بقرابها مغفرة» .\\nرواه الترمذي وقال: حديث حسن صحيح."}], "indexes": {"hadiths": {"1": 12, "2": 14, "3": 18, "4": 19, "5": 21, "6": 22, "7": 24, "8": 25, "9": 26, "10": 27, "11": 29, "12": 30, "13": 31, "14": 32, "15": 33, "16": 34, "17": 35, "18": 36, "19": 37, "20": 39, "21": 40, "22": 41, "23": 43, "24": 45, "25": 49, "26": 51, "27": 53, "28": 55, "29": 57, "30": 60, "31": 62, "32": 63, "33": 65, "34": 66, "35": 67, "36": 69, "37": 71, "38": 74, "39": 76, "40": 77, "41": 79, "42": 80}, "headings": [{"page": 1, "level": 1, "title": "مقدمة المؤلف"}, {"page": 12, "level": 1, "title": "الحديث الأول"}, {"page": 14, "level": 1, "title": "الحديث الثاني"}, {"page": 18, "level": 1, "title": "الحديث الثالث"}, {"page": 19, "level": 1, "title": "الحديث الرابع"}, {"page": 21, "level": 1, "title": "الحديث الخامس"}, {"page": 22, "level": 1, "title": "الحديث السادس"}, {"page": 24, "level": 1, "title": "الحديث السابع"}, {"page": 25, "level": 1, "title": "الحديث الثامن"}, {"page": 26, "level": 1, "title": "الحديث التاسع"}, {"page": 27, "level": 1, "title": "الحديث العاشر"}, {"page": 29, "level": 1, "title": "الحديث الحادي عشر"}, {"page": 30, "level": 1, "title": "الحديث الثانى عشر"}, {"page": 31, "level": 1, "title": "الحديث الثالث عشر"}, {"page": 32, "level": 1, "title": "الحديث الرابع عشر"}, {"page": 33, "level": 1, "title": "الحديث الخامس عشر"}, {"page": 34, "level": 1, "title": "الحديث السادس عشر"}, {"page": 35, "level": 1, "title": "الحديث السابع عشر"}, {"page": 36, "level": 1, "title": "الحديث الثامن عشر"}, {"page": 37, "level": 1, "title": "الحديث التاسع عشر"}, {"page": 39, "level": 1, "title": "الحديث العشرون"}, {"page": 40, "level": 1, "title": "الحديث الحادي والعشرون"}, {"page": 41, "level": 1, "title": "الحديث الثانى والعشرون"}, {"page": 43, "level": 1, "title": "الحديث الثالث والعشرون"}, {"page": 45, "level": 1, "title": "الحديث الرابع والعشرون"}, {"page": 49, "level": 1, "title": "الحديث الخامس والعشرون"}, {"page": 51, "level": 1, "title": "الحديث السادس والعشرون"}, {"page": 53, "level": 1, "title": "الحديث السابع والعشرون"}, {"page": 55, "level": 1, "title": "الحديث الثامن والعشرون"}, {"page": 57, "level": 1, "title": "الحديث التاسع والعشرون"}, {"page": 60, "level": 1, "title": "الحديث الثلاثون"}, {"page": 62, "level": 1, "title": "الحديث الحادي والثلاثون"}, {"page": 63, "level": 1, "title": "الحديث الثاني والثلاثون"}, {"page": 65, "level": 1, "title": "الحديث الثالث والثلاثون"}, {"page": 66, "level": 1, "title": "الحديث الرابع والثلاثون"}, {"page": 67, "level": 1, "title": "الحديث الخامس والثلاثون"}, {"page": 69, "level": 1, "title": "الحديث السادس والثلاثون"}, {"page": 71, "level": 1, "title": "الحديث السابع والثلاثون"}, {"page": 74, "level": 1, "title": "الحديث الثامن والثلاثون"}, {"page": 76, "level": 1, "title": "الحديث التاسع والثلاثون"}, {"page": 77, "level": 1, "title": "الحديث الأربعون"}, {"page": 79, "level": 1, "title": "الحديث الحادي والأربعون"}, {"page": 80, "level": 1, "title": "الحديث الثاني والأربعون"}]}}		44	f	t	2020-06-15 01:28:06.89946+00	2020-06-15 01:28:06.899515+00	\N		\N	\N	81	\N	1	\N	4
3	الاربعون النووية	[{'text': 'بسم الله الرحمن الرحيم\\n\\nمقدمة المؤلف\\nالحمد لله رب العالمين قيوم السموات والأرضين. مدبر الخلائق أجمعين. باعث الرسل - صلواته وسلامه عليهم- إلى المكلفين لهدايتهم وبيان شرائع الدين بالدلائل القطعية، وواضحات البراهين.', 'vol': 1, 'page': 35}, {'text': 'أحمده على جميع نعمه. وأسأله المزيد من فضله وكرمه.\\nوأشهد أن لا إله إلا الله الواحد القهار. الكريم الغفار وأشهد أن سيدنا محمداً عبده ورسوله وحبيبه وخليله أفضل المخلوقين، المكرم بالقرآن العزيز المعجزة المستمرة على تعاقب السنين، وبالسنن المستنيرة للمسترشدين المخصوص بجوامع الكلم وسماحة الدين صلوات الله وسلامه عليه وعلى سائر النبيين والمرسلين وآل كل وسائر الصالحين.', 'vol': 1, 'page': 36}, {'text': 'أما بعد: فقد روينا عن علي بن أبي طالب، وعبد الله بن مسعود، ومعاذ بن جبل، وأبي الدرداء، وابن عمر، وابن عباس، وأنس بن مالك، وأبي هريرة، وأبي سعيد الخدري رضي الله تعالى عنهم من طرق كثيرات بروايات متنوعات: أن رسول الله ﷺ قال: "من حفظ على أمتي أربعين حديثاً من أمر دينها', 'vol': 1, 'page': 37}, {'text': 'بعثه الله يوم القيامة في زمرة الفقهاء والعلماء" وفي رواية: "بعثه الله فقيها عالما".\\nوفي رواية أبي الدرداء: "وكنت له يوم القيامة شافعا وشهيدا". وفي رواية ابن مسعود: قيل له: "ادخل من أي أبوب الجنة شئت" وفي رواية ابن عمر "كُتِب في زمرة العلماء وحشر في زمرة الشهداء". واتفق الحفاظ على أنه حديث ضعيف وإن كثرت طرقه.', 'vol': 1, 'page': 38}, {'text': 'وقد صنّف العلماء رضي الله تعالى عنهم في هذا الباب ما لا يُحصى من المصنّفات. فأول من علمته صنف فيه: عبد الله بن المبارك، ثم محمد بن أسلم الطوسي العالم الرباني، ثم الحسن بن سفيان النسائي، وأبو بكر', 'vol': 1, 'page': 39}, {'text': 'الآجري، وأبو بكر بن إبراهيم الأصفهاني، والدارقطني، والحاكم،', 'vol': 1, 'page': 40}, {'text': 'وأبو نعيم، وأبو عبد الرحمن السلميّ، وأبو سعيد الماليني، وأبو عثمان الصابوني، وعبد الله بن', 'vol': 1, 'page': 41}, {'text': 'محمد الأنصاري. وأبو بكر البيهقي، وخلائق لا يحصون من المتقدمين والمتأخرين، وقد استخرت الله تعالى في جمع أربعين حديثاً اقتداء بهؤلاء الأئمة الأعلام وحفاظ الإسلام. وقد اتفق العلماء على جواز العمل بالحديث الضعيف', 'vol': 1, 'page': 42}, {'text': 'في فضائل الأعمال.\\nومع هذا فليس اعتمادي على هذا الحديث، بل على قوله ﷺ في الأحاديث الصحيحة: "ليبلغ الشاهد منكم الغائب" وقوله ﷺ: "نضر الله امرأً سمع مقالتي فوعاها فأدّاها كما سمعها".\\nثم من العلماء من جمع الأربعين في أصول الدين، وبعضهم في الفروع، وبعضهم في الجهاد، وبعضهم في الزهد، وبعضهم في الآداب، وبعضهم في الخطب،', 'vol': 1, 'page': 43}, {'text': 'وكلها مقاصة صالحة رضي الله تعالى عن قاصديها.\\nقد رأيت جمع أربعين أهم من هذا كله، وهي أربعون حديثاً مشتملة على جميع ذلك، وكل حديث منها قاعدة عظيمة من قواعد الدين قد وصفه العلماء بأن مدار الإسلام عليه، أو هو نصف الإسلام أو ثلثه أو نحو ذلك.\\nثم ألتزم في هذه الأربعين أن تكون صحيحة، ومعظمها في صحيحي البخاري ومسلم،', 'vol': 1, 'page': 44}, {'text': 'وأذكرها محذوفة الأسانيد، ليسهل حفظها، ويعم الانتفاع بها إن شاء الله تعالى، ثم أُتبعها بباب في ضبط خفي ألفاظها. وينبغي لكل راغب في الآخرة أن يعرف هذه الأحاديث، لما اشتملت عليه من المهمات، واحتوت عليه من التنبيه على جميع الطاعات وذلك ظاهر لمن تدبّره، وعلى الله اعتمادي، وإليه تفويضي واستنادي وله الحمد والنعمة، وبه التوفيق والعصمة.', 'vol': 1, 'page': 45}, {'text': 'الحديث الأول\\n«عن أمير المؤمنين أبي حفص عمر بن الخطاب رضي الله تعالى عنه قال: سمعت رسول الله صلى الله تعالى عليه وعلى آله وسلم يقول: إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى، فمن كانت هجرته إلى الله ورسوله فهجرته إلى الله ورسوله، ومن كانت هجرته لدنيا يصيبها أو امرأة ينكحها فهجرته إلى ما هاجر إليه» .\\nرواه إماما المحدثين:', 'vol': 1, 'page': 46}, {'text': 'أبو عبد الله محمد ابن إسماعيل بن إبراهيم بن المغيرة بن بردزبه البخاري، وأبو الحسين مسلم ابن الحجاج بن مسلم القشيري النيسابوري: في صحيحيهما اللذين هما أصح الكتب المصنفة.', 'vol': 1, 'page': 47}, {'text': 'الحديث الثاني\\n«عن عمر رضي الله تعالى عنه أيضاً قال: بينما نحن جلوس عند رسول الله صلى الله عليه وآله وسلم ذات يوم إذ طلع علينا رجل شديد بياض الثياب شديد سواد الشعر لا يرى عليه أثر السفر ولا يعرفه منا أحد، حتى جلس إلى النبي صلى الله عليه وآله وسلم فأسند ركبتيه إلى ركبتيه ووضع كفيه على فخذيه وقال: يا محمد أخبرني عن الإسلام،', 'vol': 1, 'page': 48}, {'text': 'فقال رسول الله صلى الله عليه وآله وسلم: الإسلام أن تشهد أن لا إله إلا الله وأن محمداً رسول الله، وتقيم الصلاة، وتؤتي الزكاة، وتصوم رمضان، وتحج البيت إن استطعت إليه سبيلاً قال: صدقت، فعجبنا له يسأله ويصدقه.\\nقال: فأخبرني عن الإيمان، قال أن تؤمن بالله وملائكته وكتبه ورسله واليوم الآخر، وتؤمن بالقدر خيره وشره، قال: صدقت، قال: فأخبرني عن الإحسان، قال أن تعبد الله كأنك تراه، فإن لم تكن تراه فإنه يراك،', 'vol': 1, 'page': 49}, {'text': 'قال: فأخبرني عن الساعة، قال ما المسئول عنها بأعلم من السائل، قال: فأخبرني عن أماراتها، قال أن تلد الأمة ربتها، وأن ترى الحفاة العراة العالة رعاء الشاء يتطاولون في البنيان', 'vol': 1, 'page': 50}, {'text': 'ثم انطلق فلبثت ملياً ثم قال يا عمر أتدري من السائل؟ قلت: الله ورسوله أعلم، قال فإنه جبريل أتاكم يعلمكم دينكم» .\\nرواه مسلم.', 'vol': 1, 'page': 51}, {'text': 'الحديث الثالث\\n«عن أبي عبد الرحمن عبد الله بن عمر بن الخطاب رضي الله تعالى عنهما قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: بني الإسلام على خمس: شهادة أن لا إله إلا الله وأن محمداً رسول الله، وإقام الصلاة، وإيتاء الزكاة، وحج البيت، وصوم رمضان» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 52}, {'text': 'الحديث الرابع\\n«عن أبي عبد الرحمن عبد الله بن مسعود \\ufd41 قال: حدثنا رسول الله صلى الله عليه وآله وسلم وهو الصادق المصدوق: إن أحدكم يجمع خلقه في بطن أمه أربعين يوماً نطفة، ثم يكون علقة مثل ذلك، ثم يكون مضغة مثل ذلك، ثم يرسل إليه الملك فينفخ فيه الروح ويؤمر بأربع كلمات: بكتب رزقه، وأجله، وعمله، وشقي أو سعيد،', 'vol': 1, 'page': 53}, {'text': 'فو الله الذي لا إله غيره إن أحدكم ليعمل بعمل أهل الجنة حتى ما يكون بينه وبينها إلا ذراع فيسبق عليه الكتاب فيعمل بعمل أهل النار فيدخلها، وإن أحدكم ليعمل بعمل أهل النار حتى ما يكون بينه وبينها إلا ذراع فيسبق عليه الكتاب فيعمل بعمل أهل الجنة فيدخلها» رواه البخاري ومسلم.', 'vol': 1, 'page': 54}, {'text': 'الحديث الخامس\\n«عن أم المؤمنين أم عبد الله عائشة \\ufd42 قالت: قال رسول الله صلى الله عليه وآله وسلم: من أحدث في أمرنا هذا ما ليس منه فهو رد» .\\nرواه البخاري ومسلم.\\nوفي رواية لمسلم «من عمل عملاً ليس عليه أمرنا فهو رد» .', 'vol': 1, 'page': 55}, {'text': 'الحديث السادس\\n«عن أبي عبد الله النعمان بن بشير \\ufd44 قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: إن الحلال بين وإن الحرام بين وبينهما أمور مشتبهات لا يعلمهن كثير من الناس، فمن اتقى الشبهات فقد استبرأ لدينه وعرضه، ومن وقع في الشبهات وقع في', 'vol': 1, 'page': 56}, {'text': 'الحرام كالراعي يرعى حول الحمى يوشك أن يرتع فيه، ألا وإن لكل ملك حمى، ألا وإن حمى الله محارمه، ألا وإن في الجسد مضغة إذا صلحت صلح الجسد كله وإذا فسدت فسد الجسد كله ألا وهي القلب» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 57}, {'text': 'الحديث السابع\\n«عن أبي رقية تميم بن أوس الداري رضي الله تعالى عنه أن النبي صلى الله عليه وآله وسلم قال الدين النصيحة.\\nقلنا: لمن؟ قال لله، ولكتابه، ولرسوله، ولأئمة المسلمين وعامتهم» .\\nرواه مسلم.', 'vol': 1, 'page': 58}, {'text': 'الحديث الثامن\\n«عن ابن عمر رضي الله تعالى عنهما أن رسول الله صلى الله تعالى عليه وعلى آله وسلم قال أمرت أن أقاتل الناس حتى يشهدوا أن لا إله إلا الله وأن محمداً رسول الله، ويقيموا الصلاة، ويؤتوا الزكاة: فإذا فعلوا ذلك عصموا مني دماءهم وأموالهم إلا بحق الإسلام وحسابهم على الله تعالى» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 59}, {'text': 'الحديث التاسع\\n«عن أبي هريرة عبد الرحمن بن صخر رضي الله تعالى عنه قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول مانهيتكم عنه فاجتنبوه، وما أمرتكم به فأتوا منه ما استطعتم، فإنما أهلك الذين من قبلكم كثرة مسائلهم واختلافهم على أنبيائهم» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 60}, {'text': 'الحديث العاشر\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم: إن الله تعالى طيب لا يقبل إلا طيباً، وإن الله أمر المؤمنين بما أمر به المرسلين فقال تعالى {يا أيها الرسل كلوا من الطيبات واعملوا صالحا} وقال تعالى {يا أيها الذين آمنوا كلوا من طيبات ما رزقناكم} ثم ذكر الرجل يطيل السفر أشعث أغبر يمد يديه إلى السماء: يا رب يا رب، ومطعمه حرام', 'vol': 1, 'page': 61}, {'text': 'وملبسه حرام وغذي بالحرام فأنى يستجاب له» .\\nرواه مسلم.', 'vol': 1, 'page': 62}, {'text': 'الحديث الحادي عشر\\n«عن أبي محمد الحسن بن علي بن أبي طالب سبط رسول الله صلى الله عليه وآله وسلم وريحانته \\ufd44 قال: حفظت من رسول الله صلى الله عليه وآله وسلم دع ما يريبك إلى ما لا يريبك» .\\nرواه الترمذي والنسائي، وقال الترمذي: حديث حسن صحيح.', 'vol': 1, 'page': 63}, {'text': 'الحديث الثانى عشر\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم من حسن إسلام المرء تركه ما لا يعنيه» .\\nحديث حسن، رواه الترمذي وغيره وهكذا.', 'vol': 1, 'page': 64}, {'text': 'الحديث الثالث عشر\\n«عن أبي حمزة أنس بن مالك رضي الله تعالى عنه خادم رسول الله صلى الله عليه وآله وسلم عن النبي صلى الله عليه وآله وسلم قال لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 65}, {'text': 'الحديث الرابع عشر\\n«عن ابن مسعود رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم لا يحل دم امرئ مسلم إلا بإحدى ثلاث: الثيب الزاني، والنفس بالنفس، والتارك لدينه المفارق للجماعة» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 66}, {'text': 'الحديث الخامس عشر\\n«عن أبي هريرة رضي الله تعالى عنه أن رسول الله صلى الله عليه وآله وسلم قال: من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت، ومن كان يؤمن بالله واليوم الآخر فليكرم جاره، ومن كان يؤمن بالله واليوم الآخر فليكرم ضيفه» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 67}, {'text': 'الحديث السادس عشر\\n«عن أبي هريرة رضي الله تعالى عنه أن رجلاً قال للنبي صلى الله عليه وآله وسلم: أوصني، قال لا تغضب فردد مراراً، قال لا تغضب» .\\nرواه البخاري.', 'vol': 1, 'page': 68}, {'text': 'الحديث السابع عشر\\n«عن أبي يعلى شداد بن أوس رضي الله تعالى عنه عن رسول الله صلى الله عليه وآله وسلم قال إن الله كتب الإحسان على كل شئ، فإذا قتلتم فأحسنوا القتلة وإذا ذبحتم فأحسنوا الذبحة، وليحد أحدكم شفرته وليرح ذبيحته» .\\nرواه مسلم.', 'vol': 1, 'page': 69}, {'text': 'الحديث الثامن عشر\\n«عن أبي ذر جندب بن جنادة، وأبي عبد الرحمن معاذ بن جبل رضي الله تعالى عنهما عن رسول الله صلى الله عليه وآله وسلم قال: إتق الله حيثما كنت، وأتبع السيئة الحسنة تمحها، وخالق الناس بخلق حسن» .\\nرواه الترمذي وقال: حديث حسن، وفي بعض النسخ: حسن صحيح.', 'vol': 1, 'page': 70}, {'text': 'الحديث التاسع عشر\\n«عن أبي العباس عبد الله بن عباس رضي الله تعالى عنهما قال: كنت خلف النبي صلى الله عليه وآله وسلم يوماً فقال يا غلام، إني أعلمك كلمات: إحفظ الله يحفظك، إحفظ الله تجده تجاهك، إذا سألت فاسأل الله، وإذا استعنت فاستعن بالله، واعلم أن الأمة لو اجتمعت على أن ينفعوك بشئ لم ينفعوك إلا بشئ قد كتبه الله لك،', 'vol': 1, 'page': 71}, {'text': 'وإن اجتمعوا على أن يضروك بشئ لم يضروك إلا بشئ قد كتبه الله عليك، رفعت الأقلام وجفت الصحف» .\\nرواه الترمذي وقال حديث حسن صحيح.\\nوفي رواية غير الترمذي «إحفظ الله تجده أمامك، تعرف إلى الله في الرخاء يعرفك في الشدة، واعلم أن ما أخطأك لم يكن ليصيبك، وما أصابك لم يكن ليخطئك، واعلم أن النصر مع الصبر، وأن الفرج مع الكرب، وأن مع العسر يسراً» .', 'vol': 1, 'page': 72}, {'text': 'الحديث العشرون\\n«عن أبي مسعود عقبة بن عمرو الأنصاري البدري \\ufd41 قال: قال رسول الله صلى الله عليه وآله وسلم: إن مما أدرك الناس من كلام النبوة الأولى: إذا لم تستح فاصنع ما شئت» .\\nرواه البخاري.', 'vol': 1, 'page': 73}, {'text': 'الحديث الحادي والعشرون\\n«عن أبي عمرو - وقيل أبي عمرة - سفيان ابن عبد الله \\ufd41 قال: قلت يا رسول الله قل لي في الإسلام قولاً لا أسال عنه أحداً غيرك، قال قل آمنت بالله، ثم استقم» .\\nرواه مسلم.', 'vol': 1, 'page': 74}, {'text': 'الحديث الثانى والعشرون\\n«عن أبي عبد الله جابر بن عبد الله الأنصاري \\ufd44 أن رجلاً سأل رسول الله صلى الله عليه وآله وسلم فقال: أرأيت إذا صليت المكتوبات، وصمت رمضان، وأحللت الحلال، وحرمت الحرام، ولم أزد على ذلك شيئاً، أدخل الجنة؟ قال نعم» .\\nرواه مسلم.\\nومعنى حرمت الحرام: اجتنبته،', 'vol': 1, 'page': 75}, {'text': 'ومعنى أحللت الحلال: فعلته معتقداً حله.', 'vol': 1, 'page': 76}, {'text': 'الحديث الثالث والعشرون\\n«عن أبي مالك الحارث بن الأشعري \\ufd41 قال: قال رسول الله صلى الله عليه وآله وسلم الطهور شطر الإيمان، والحمد لله تملأ الميزان، وسبحان الله والحمد لله تملآن - أو تملأ - ما بين', 'vol': 1, 'page': 77}, {'text': 'السماء والأرض، والصلاة نور، والصدقة برهان، والصبر ضياء، والقرآن حجة لك أو عليك، كل الناس يغدو: فبائع نفسه فمعتقها أو موبقها» .\\nرواه مسلم.', 'vol': 1, 'page': 78}, {'text': 'الحديث الرابع والعشرون\\n«عن أبي ذر الغفاري رضي الله تعالى عنه عن النبي صلى الله تعالى عليه وآله وسلم فيما يرويه عن ربه \\ufdff أنه قال يا عبادي، إني حرمت الظلم على نفسي وجعلته بينكم محرماً فلا تظالموا،', 'vol': 1, 'page': 79}, {'text': 'يا عبادي، كلكم ضال إلا من هديته فاستهدوني أهدكم، يا عبادي، كلكم جائع إلا من أطعمته فاستطعموني أطعمكم، يا عبادي، كلكم عار إلا من كسوته فاستكسوني أكسكم: يا عبادي، إنكم تخطئون بالليل والنهار وأنا أغفر الذنوب جميعاً فاستغفروني أغفر لكم، ياعبادي، إنكم لن تبلغوا ضري فتضروني ولن تبلغوا نفعي فتنفعوني، يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم كانوا على أتقى قلب رجل واحد منكم ما زاد ذلك في ملكي شيئاً:', 'vol': 1, 'page': 80}, {'text': 'يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم كانوا على أفجر قلب رجل واحد منكم ما نقص ذلك من ملكي شيئاً: يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم قاموا في صعيد واحد فسألوني فأعطيت كل واحد مسألته ما نقص ذلك مما عندي إلا كما ينقص المخيط إذا أدخل البحر، يا عبادي، إنما هي أعمالكم أحصيها لكم ثم أوفيكم إياها فمن وجد خيراً فليحمد الله ومن', 'vol': 1, 'page': 81}, {'text': 'وجد غير ذلك فلا يلومن إلا نفسه» .\\nرواه مسلم.', 'vol': 1, 'page': 82}, {'text': 'الحديث الخامس والعشرون\\n«عن أبي ذر \\ufd41 أيضاً أن ناساً من أصحاب رسول الله صلى الله عليه وآله وسلم قالوا للنبي صلى الله تعالى وعليه وآله وسلم: يا رسول الله، ذهب أهل الدثور بالأجور: يصلون كما نصلي ويصومون كما نصوم، ويتصدقون بفضول أموالهم.\\nقال: أوليس قد جعل الله لكم ما تصدقون: إن بكل تسبيحة صدقة، وكل تكبيرة صدقة، وكل', 'vol': 1, 'page': 83}, {'text': 'تحميدة صدقة، وكل تهليلة صدقة، وأمر بمعروف صدقة، ونهي عن منكر صدقة، وفي بضع أحدكم صدقة، قالوا: يا رسول الله، أيأتي أحدنا شهوته ويكون له فيها أجر؟ قال أرأيتم لو وضعها في حرام أكان عليه وزر؟ فكذلك إذا وضعها في الحلال كان له أجر» .\\nرواه مسلم.', 'vol': 1, 'page': 84}, {'text': 'الحديث السادس والعشرون\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم كل سلامى من الناس عليه صدقة كل يوم تطلع فيه الشمس: تعدل بين اثنين صدقة، وتعين الرجل في دابته فتحمله عليها أو ترفع', 'vol': 1, 'page': 85}, {'text': 'له عليها متاعه صدقة، والكلمة الطيبة صدقة، وبكل خطوة تمشيها إلى الصلاة صدقة، وتميط الأذى عن الطريق صدقة» .\\nرواه البخاري ومسلم.', 'vol': 1, 'page': 86}, {'text': 'الحديث السابع والعشرون\\n«عن النواس بن سمعان رضي الله تعالى عنه عن النبي صلى الله عليه وعلى آله وسلم قال البر حسن الخلق، والإثم ما حاك في نفسك وكرهت أن يطلع عليه الناس» .\\nرواه مسلم\\nوعن وابصة بن معبد رضي الله تعالى عنه قال: «أتيت رسول الله صلى الله عليه وآله وسلم فقال: جئت تسأل عن البر؟ قلت: نعم، وقال: إستفت قلبك، البر ما', 'vol': 1, 'page': 87}, {'text': 'اطمأنت إليه النفس واطمأن إليه القلب، والإثم ما حاك في النفس وتردد في الصدر وإن أفتاك الناس وأفتوك» .\\nحديث حسن.\\nرويناه في مسندي الإمامين أحمد بن حنبل والدرامي بإسناد حسن.', 'vol': 1, 'page': 88}, {'text': 'الحديث الثامن والعشرون\\n«عن أبي نجيح العرباض بن سارية رضي الله تعالى عنه قال: وعظنا رسول الله صلى الله عليه وآله وسلم موعظة وجلت منها القلوب وذرفت منها العيون، فقلنا: يا رسول الله كأنها موعظة مودع فأوصنا، قال أوصيكم بتقوى الله \\ufdff والسمع والطاعة وإن تأمر عليكم عبد،', 'vol': 1, 'page': 89}, {'text': 'فإنه من يعش منكم فسيري اختلافاً كثيراً، فعليكم بسنتي وسنة الخلفاء الراشدين المهديين عضوا عليها بالنواجذ، وإياكم ومحدثات الأمور فإن كل بدعة ضلالة» .\\nرواه أبو داود والترمذي وقال: حديث حسن صحيح.', 'vol': 1, 'page': 90}, {'text': 'الحديث التاسع والعشرون\\n«عن معاذ بن جبل \\ufd41 قال: قلت يا رسول الله أخبرني بعمل يدخلني الجنة ويباعدني عن النار، قال: لقد سألت عن عظيم وإنه ليسير على من يسره الله تعالى عليه: تعبد الله لا تشرك به شيئاً، وتقيم الصلاة، وتؤتي الزكاة، وتصوم رمضان، وتحج البيت ثم قال: ألا أدلك على أبواب الخير؟ : الصوم جنة، والصدقة تطفئ الخطيئة كما يطفئ الماء النار، وصلاة الرجل في جوف الليل', 'vol': 1, 'page': 91}, {'text': 'ثم تلا: {تتجافى جنوبهم عن المضاجع} {حتى إذا بلغ} {يعملون} ثم قال ألا أخبرك برأس الأمر وعموده وذروة سنامه؟ قلت: بلى يا رسول الله.\\nقال رأس الأمر الإسلام، وعموده الصلاة، وذروة سنامه الجهاد', 'vol': 1, 'page': 92}, {'text': 'ثم قال: ألا أخبرك بملاك ذلك كله؟ قلت: بلى يا رسول الله، فأخذ بلسانه وقال كف عليك هذا قلت: يا نبي الله، وإنا لمؤاخذون بما نتكلم به؟ فقال ثكلتك أمك، وهل يكب الناس في النار على وجوههم - أو قال على مناخرهم - إلا حصائد ألسنتهم؟» .\\nرواه الترمذي وقال: حديث حسن صحيح.', 'vol': 1, 'page': 93}, {'text': 'الحديث الثلاثون\\n«عن أبي ثعلبة الخشبي جرثوم بن ناشر رضي الله تعالى عنه عن رسول الله ﷺ قال إن الله تعالى فرض فرائض فلا تضيعوها، وحد حدوداً فلا تعتدوها، وحرم أشياء فلا تنتهكوها،', 'vol': 1, 'page': 94}, {'text': 'وسكت عن أشياء رحمة لكم غير نسيان فلا تبحثوا عنها» .\\nحديث حسن رواه الدارقطني وغيره.', 'vol': 1, 'page': 95}, {'text': 'الحديث الحادي والثلاثون\\n«عن أبي العباس سهل بن سعد الساعدى رضي الله تعالى عنه قال جاء رجل إلى النبي صلى الله عليه وآله وسلم فقال: يا رسول الله، دلني على عمل إذا عملته أحبني الله وأحبني الناس: فقال إزهد في الدنيا يحبك الله، وازهد فيما عند الناس يحبك الناس» .\\nحديث حسن، رواه ابن ماجة وغيره بأسانيد حسنة.', 'vol': 1, 'page': 96}, {'text': 'الحديث الثاني والثلاثون\\n«عن أبي سعيد سعد بن مالك بن سنان الخدري رضي الله تعالى عنه أن رسول الله صلى الله وعليه وآله وسلم قال: لا ضرر ولا ضرار» .\\nحديث حسن، رواه ابن ماجة والدارقطني وغيرهما مسنداً.', 'vol': 1, 'page': 97}, {'text': 'ورواه مالك في الموطإ مرسلاً عن عمرو بن يحيى عن أبيه عن النبي صلى الله عليه وآله وسلم، فأسقط أبا سعيد، وله طرق يقوي بعضها بعضاً.', 'vol': 1, 'page': 98}, {'text': 'الحديث الثالث والثلاثون\\n«عن ابن عباس \\ufd44 أن رسول الله صلى الله عليه وآله وسلم قال: لو يعطى الناس بدعواهم لادعى رجال أموال قوم ودماءهم، لكن البينة على المدعى واليمين على من أنكر» .\\nحديث حسن، رواه البيهقي وغيره هكذا، وبعضه في الصحيحين.', 'vol': 1, 'page': 99}, {'text': 'الحديث الرابع والثلاثون\\n«عن أبي سعيد الخدري \\ufd41 قال: سمعت رسول الله صلى الله عليه وآله وسلم يقوم: من رأى منكم منكراً فليغيره بيده، فإن لم يستطع فبلسانه، فإن لم يستطع فبقلبه، وذلك أضعف الإيمان» .\\nرواه مسلم.', 'vol': 1, 'page': 100}, {'text': 'الحديث الخامس والثلاثون\\n«عن أبي هريرة \\ufd41 قال: قال رسول الله صلى الله عليه وآله وسلم لا تحاسدوا، ولا تناجشوا ولا تباغضوا، ولا تدابروا، ولا يبع بعضكم على بيع بعض، وكونوا عباد الله إخواناً، المسلم أخو المسلم لا يظلمه ولا يخذله ولا يكذبه ولا يحقره، التقوى ههنا - ويشير', 'vol': 1, 'page': 101}, {'text': 'إلى صدور ثلاث مرات - بحسب امرئ من الشر أن يحقر أخاه المسلم، كل المسلم على المسلم حرام: دمه وماله وعرضه» .\\nرواه مسلم.', 'vol': 1, 'page': 102}, {'text': 'الحديث السادس والثلاثون\\n«عن أبي هريرة \\ufd41 عن النبي صلى الله عليه وآله وسلم قال من نفس عن مؤمن كربة من كرب الدنيا نفس الله عنه كربة من كرب يوم القيامة، ومن يسر على معسر يسر الله عليه في الدنيا والآخرة، ومن ستر مسلماً ستره الله في الدنيا والآخرة، والله في عون العبد ما كان العبد في عون أخيه، ومن سلك طريقاً يلتمس فيه علماً سهل الله له به طريقاً إلى الجنة، وما اجتمع قوم في بيت من بيوت الله يتلون كتاب الله ويتدارسونه بينهم إلا نزلت عليهم السكينة', 'vol': 1, 'page': 103}, {'text': 'وغشيتهم الرحمة وحفتهم الملائكة وذكرهم الله فيمن عنده، ومن بطأ به عمله لم يسرع به نسبه» .\\nرواه مسلم بهذا اللفظ.', 'vol': 1, 'page': 104}, {'text': 'الحديث السابع والثلاثون\\n«عن ابن عباس \\ufd44 عن رسول الله صلى الله عليه وآله وسلم فيما يرويه عن ربه تبارك وتعالى قال إن الله كتب الحسنات والسيئات ثم بين ذلك، فمن هم بحسنة فلم يعملها كتبها الله عنده حسنة كاملة، وإن هم بها فعملها كتبها الله عنده عشر حسنات إلى سبعمائة ضعف إلى أضعاف كثيرة، وإن هم بسيئة فلم يعملها كتبها الله عنده حسنة كاملة، وإن هم بها فعملها كتبها الله سيئة واحدة» .', 'vol': 1, 'page': 105}, {'text': 'رواه البخاري ومسلم في صحيحيهما بهذه الحروف فانظر يا أخي وفقنا الله وإياك إلى عظيم لطف الله تعالى، وتأمل هذه الألفاظ، وقوله عنده إشارة إلى الإعتناء بها، وقوله كاملة للتأكيد وشدة الإعتناء بها، وقال في السيئة التي هم بها ثم تركها كتبها الله عنه حسنة كاملة فأكدها بـ (كاملة) وإن عملها كتبها سيئة واحدة، فأكد تقليلها', 'vol': 1, 'page': 106}, {'text': 'بـ (واحدة) ولم يؤكدها بـ (كاملة) فلله الحمد والمنة، سبحانه لا نحصي ثناء عليه، وبالله التوفيق.', 'vol': 1, 'page': 107}, {'text': 'الحديث الثامن والثلاثون\\n«عن أبي هريرة \\ufd41 قال: قال رسول الله صلى الله عليه وآله وسلم: إن الله تعالى قال: من عادى لي ولياً فقد آذنته بالحرب، وما تقرب إلى عبدي بشئ أحب إلي مما افترضته عليه، ولا يزال عبدي يتقرب إلي', 'vol': 1, 'page': 108}, {'text': 'بالنوافل حتى أحبه، فإذا أحببته كنت سمعه الذي يسمع به وبصره الذي يبصر به ويده التي يبطش بها ورجله التي يمشي بها، ولئن سألني لأعطينه، ولئن استعاذني لأعيذنه» .\\nرواه البخاري.', 'vol': 1, 'page': 109}, {'text': 'الحديث التاسع والثلاثون\\n«عن ابن عباس \\ufd44 أن رسول الله صلى الله عليه وآله وسلم قال إن الله تجاوز لي عن أمتى الخطأ والنسيان وما اسكترهوا عليه» .\\nحديث حسن رواه ابن ماجة والبيهقي وغيرهما.', 'vol': 1, 'page': 110}, {'text': 'الحديث الأربعون\\n«عن ابن عمر \\ufd44 قال: أخذ رسول الله صلى الله عليه وآله وسلم بمنكبي فقال: كن في الدنيا كأنك غريب أو عابر سبيل» وكان ابن عمر رضي الله تعالى عنهما يقول: إذا أمسيت فلا تنتظر الصباح، وإذا أصبحت فلا تنتظر', 'vol': 1, 'page': 111}, {'text': 'المساء، وخذ من صحتك لمرضك، ومن حياتك لموتك.\\nرواه البخاري.', 'vol': 1, 'page': 112}, {'text': 'الحديث الحادي والأربعون\\n«عن أبي محمد عبد الله بن عمرو بن العاص \\ufd44 قال: قال رسول الله صلى الله عليه وآله وسلم: لا يؤمن أحدكم حتى يكون هواه تبعاً لما جئت به» .\\nحديث حسن صحيح، رويناه في كتاب الحجة بإسناد صحيح.', 'vol': 1, 'page': 113}, {'text': 'الحديث الثاني والأربعون\\n«عن أنس \\ufd41 قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: قال الله تعالى يابن آدم، إنك ما دعوتني ورجوتني غفرت للك على ما كان منك ولا أبالي، يا ابن آدم لو بلغت ذنوبك عنان السماء ثم', 'vol': 1, 'page': 114}, {'text': 'استغفرتني غفرت لك، يا ابن آدم لو أتيتني بقراب الأرض خطايا ثم لقيتني لا تشرك بي شيئاً لأتيتك بقرابها مغفرة» .\\nرواه الترمذي وقال: حديث حسن صحيح.', 'vol': 1, 'page': 115}]	{"meta": {"id": 12836, "info": "", "name": "الأربعون النووية", "size": 39275, "betaka": "الكتاب: الأربعون النووية\\nالمؤلف: أبو زكريا محيي الدين يحيى بن شرف النووي (المتوفى: 676هـ)\\nعُنِيَ بِهِ: قصي محمد نورس الحلاق، أنور بن أبي بكر الشيخي\\nالناشر: دار المنهاج للنشر والتوزيع، لبنان - بيروت\\nالطبعة: الأولى، 1430 هـ - 2009 م\\nعدد الأجزاء: 1\\n[ترقيم الكتاب موافق للمطبوع]", "author_id": 44, "categories": ["الرقاق والآداب والأذكار"], "page_count": 81}, "pages": [{"vol": 1, "page": 35, "text": "بسم الله الرحمن الرحيم\\n\\nمقدمة المؤلف\\nالحمد لله رب العالمين قيوم السموات والأرضين. مدبر الخلائق أجمعين. باعث الرسل - صلواته وسلامه عليهم- إلى المكلفين لهدايتهم وبيان شرائع الدين بالدلائل القطعية، وواضحات البراهين."}, {"vol": 1, "page": 36, "text": "أحمده على جميع نعمه. وأسأله المزيد من فضله وكرمه.\\nوأشهد أن لا إله إلا الله الواحد القهار. الكريم الغفار وأشهد أن سيدنا محمداً عبده ورسوله وحبيبه وخليله أفضل المخلوقين، المكرم بالقرآن العزيز المعجزة المستمرة على تعاقب السنين، وبالسنن المستنيرة للمسترشدين المخصوص بجوامع الكلم وسماحة الدين صلوات الله وسلامه عليه وعلى سائر النبيين والمرسلين وآل كل وسائر الصالحين."}, {"vol": 1, "page": 37, "text": "أما بعد: فقد روينا عن علي بن أبي طالب، وعبد الله بن مسعود، ومعاذ بن جبل، وأبي الدرداء، وابن عمر، وابن عباس، وأنس بن مالك، وأبي هريرة، وأبي سعيد الخدري رضي الله تعالى عنهم من طرق كثيرات بروايات متنوعات: أن رسول الله ﷺ قال: \\"من حفظ على أمتي أربعين حديثاً من أمر دينها"}, {"vol": 1, "page": 38, "text": "بعثه الله يوم القيامة في زمرة الفقهاء والعلماء\\" وفي رواية: \\"بعثه الله فقيها عالما\\".\\nوفي رواية أبي الدرداء: \\"وكنت له يوم القيامة شافعا وشهيدا\\". وفي رواية ابن مسعود: قيل له: \\"ادخل من أي أبوب الجنة شئت\\" وفي رواية ابن عمر \\"كُتِب في زمرة العلماء وحشر في زمرة الشهداء\\". واتفق الحفاظ على أنه حديث ضعيف وإن كثرت طرقه."}, {"vol": 1, "page": 39, "text": "وقد صنّف العلماء رضي الله تعالى عنهم في هذا الباب ما لا يُحصى من المصنّفات. فأول من علمته صنف فيه: عبد الله بن المبارك، ثم محمد بن أسلم الطوسي العالم الرباني، ثم الحسن بن سفيان النسائي، وأبو بكر"}, {"vol": 1, "page": 40, "text": "الآجري، وأبو بكر بن إبراهيم الأصفهاني، والدارقطني، والحاكم،"}, {"vol": 1, "page": 41, "text": "وأبو نعيم، وأبو عبد الرحمن السلميّ، وأبو سعيد الماليني، وأبو عثمان الصابوني، وعبد الله بن"}, {"vol": 1, "page": 42, "text": "محمد الأنصاري. وأبو بكر البيهقي، وخلائق لا يحصون من المتقدمين والمتأخرين، وقد استخرت الله تعالى في جمع أربعين حديثاً اقتداء بهؤلاء الأئمة الأعلام وحفاظ الإسلام. وقد اتفق العلماء على جواز العمل بالحديث الضعيف"}, {"vol": 1, "page": 43, "text": "في فضائل الأعمال.\\nومع هذا فليس اعتمادي على هذا الحديث، بل على قوله ﷺ في الأحاديث الصحيحة: \\"ليبلغ الشاهد منكم الغائب\\" وقوله ﷺ: \\"نضر الله امرأً سمع مقالتي فوعاها فأدّاها كما سمعها\\".\\nثم من العلماء من جمع الأربعين في أصول الدين، وبعضهم في الفروع، وبعضهم في الجهاد، وبعضهم في الزهد، وبعضهم في الآداب، وبعضهم في الخطب،"}, {"vol": 1, "page": 44, "text": "وكلها مقاصة صالحة رضي الله تعالى عن قاصديها.\\nقد رأيت جمع أربعين أهم من هذا كله، وهي أربعون حديثاً مشتملة على جميع ذلك، وكل حديث منها قاعدة عظيمة من قواعد الدين قد وصفه العلماء بأن مدار الإسلام عليه، أو هو نصف الإسلام أو ثلثه أو نحو ذلك.\\nثم ألتزم في هذه الأربعين أن تكون صحيحة، ومعظمها في صحيحي البخاري ومسلم،"}, {"vol": 1, "page": 45, "text": "وأذكرها محذوفة الأسانيد، ليسهل حفظها، ويعم الانتفاع بها إن شاء الله تعالى، ثم أُتبعها بباب في ضبط خفي ألفاظها. وينبغي لكل راغب في الآخرة أن يعرف هذه الأحاديث، لما اشتملت عليه من المهمات، واحتوت عليه من التنبيه على جميع الطاعات وذلك ظاهر لمن تدبّره، وعلى الله اعتمادي، وإليه تفويضي واستنادي وله الحمد والنعمة، وبه التوفيق والعصمة."}, {"vol": 1, "page": 46, "text": "الحديث الأول\\n«عن أمير المؤمنين أبي حفص عمر بن الخطاب رضي الله تعالى عنه قال: سمعت رسول الله صلى الله تعالى عليه وعلى آله وسلم يقول: إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى، فمن كانت هجرته إلى الله ورسوله فهجرته إلى الله ورسوله، ومن كانت هجرته لدنيا يصيبها أو امرأة ينكحها فهجرته إلى ما هاجر إليه» .\\nرواه إماما المحدثين:"}, {"vol": 1, "page": 47, "text": "أبو عبد الله محمد ابن إسماعيل بن إبراهيم بن المغيرة بن بردزبه البخاري، وأبو الحسين مسلم ابن الحجاج بن مسلم القشيري النيسابوري: في صحيحيهما اللذين هما أصح الكتب المصنفة."}, {"vol": 1, "page": 48, "text": "الحديث الثاني\\n«عن عمر رضي الله تعالى عنه أيضاً قال: بينما نحن جلوس عند رسول الله صلى الله عليه وآله وسلم ذات يوم إذ طلع علينا رجل شديد بياض الثياب شديد سواد الشعر لا يرى عليه أثر السفر ولا يعرفه منا أحد، حتى جلس إلى النبي صلى الله عليه وآله وسلم فأسند ركبتيه إلى ركبتيه ووضع كفيه على فخذيه وقال: يا محمد أخبرني عن الإسلام،"}, {"vol": 1, "page": 49, "text": "فقال رسول الله صلى الله عليه وآله وسلم: الإسلام أن تشهد أن لا إله إلا الله وأن محمداً رسول الله، وتقيم الصلاة، وتؤتي الزكاة، وتصوم رمضان، وتحج البيت إن استطعت إليه سبيلاً قال: صدقت، فعجبنا له يسأله ويصدقه.\\nقال: فأخبرني عن الإيمان، قال أن تؤمن بالله وملائكته وكتبه ورسله واليوم الآخر، وتؤمن بالقدر خيره وشره، قال: صدقت، قال: فأخبرني عن الإحسان، قال أن تعبد الله كأنك تراه، فإن لم تكن تراه فإنه يراك،"}, {"vol": 1, "page": 50, "text": "قال: فأخبرني عن الساعة، قال ما المسئول عنها بأعلم من السائل، قال: فأخبرني عن أماراتها، قال أن تلد الأمة ربتها، وأن ترى الحفاة العراة العالة رعاء الشاء يتطاولون في البنيان"}, {"vol": 1, "page": 51, "text": "ثم انطلق فلبثت ملياً ثم قال يا عمر أتدري من السائل؟ قلت: الله ورسوله أعلم، قال فإنه جبريل أتاكم يعلمكم دينكم» .\\nرواه مسلم."}, {"vol": 1, "page": 52, "text": "الحديث الثالث\\n«عن أبي عبد الرحمن عبد الله بن عمر بن الخطاب رضي الله تعالى عنهما قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: بني الإسلام على خمس: شهادة أن لا إله إلا الله وأن محمداً رسول الله، وإقام الصلاة، وإيتاء الزكاة، وحج البيت، وصوم رمضان» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 53, "text": "الحديث الرابع\\n«عن أبي عبد الرحمن عبد الله بن مسعود ﵁ قال: حدثنا رسول الله صلى الله عليه وآله وسلم وهو الصادق المصدوق: إن أحدكم يجمع خلقه في بطن أمه أربعين يوماً نطفة، ثم يكون علقة مثل ذلك، ثم يكون مضغة مثل ذلك، ثم يرسل إليه الملك فينفخ فيه الروح ويؤمر بأربع كلمات: بكتب رزقه، وأجله، وعمله، وشقي أو سعيد،"}, {"vol": 1, "page": 54, "text": "فو الله الذي لا إله غيره إن أحدكم ليعمل بعمل أهل الجنة حتى ما يكون بينه وبينها إلا ذراع فيسبق عليه الكتاب فيعمل بعمل أهل النار فيدخلها، وإن أحدكم ليعمل بعمل أهل النار حتى ما يكون بينه وبينها إلا ذراع فيسبق عليه الكتاب فيعمل بعمل أهل الجنة فيدخلها» رواه البخاري ومسلم."}, {"vol": 1, "page": 55, "text": "الحديث الخامس\\n«عن أم المؤمنين أم عبد الله عائشة ﵂ قالت: قال رسول الله صلى الله عليه وآله وسلم: من أحدث في أمرنا هذا ما ليس منه فهو رد» .\\nرواه البخاري ومسلم.\\nوفي رواية لمسلم «من عمل عملاً ليس عليه أمرنا فهو رد» ."}, {"vol": 1, "page": 56, "text": "الحديث السادس\\n«عن أبي عبد الله النعمان بن بشير ﵄ قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: إن الحلال بين وإن الحرام بين وبينهما أمور مشتبهات لا يعلمهن كثير من الناس، فمن اتقى الشبهات فقد استبرأ لدينه وعرضه، ومن وقع في الشبهات وقع في"}, {"vol": 1, "page": 57, "text": "الحرام كالراعي يرعى حول الحمى يوشك أن يرتع فيه، ألا وإن لكل ملك حمى، ألا وإن حمى الله محارمه، ألا وإن في الجسد مضغة إذا صلحت صلح الجسد كله وإذا فسدت فسد الجسد كله ألا وهي القلب» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 58, "text": "الحديث السابع\\n«عن أبي رقية تميم بن أوس الداري رضي الله تعالى عنه أن النبي صلى الله عليه وآله وسلم قال الدين النصيحة.\\nقلنا: لمن؟ قال لله، ولكتابه، ولرسوله، ولأئمة المسلمين وعامتهم» .\\nرواه مسلم."}, {"vol": 1, "page": 59, "text": "الحديث الثامن\\n«عن ابن عمر رضي الله تعالى عنهما أن رسول الله صلى الله تعالى عليه وعلى آله وسلم قال أمرت أن أقاتل الناس حتى يشهدوا أن لا إله إلا الله وأن محمداً رسول الله، ويقيموا الصلاة، ويؤتوا الزكاة: فإذا فعلوا ذلك عصموا مني دماءهم وأموالهم إلا بحق الإسلام وحسابهم على الله تعالى» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 60, "text": "الحديث التاسع\\n«عن أبي هريرة عبد الرحمن بن صخر رضي الله تعالى عنه قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول مانهيتكم عنه فاجتنبوه، وما أمرتكم به فأتوا منه ما استطعتم، فإنما أهلك الذين من قبلكم كثرة مسائلهم واختلافهم على أنبيائهم» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 61, "text": "الحديث العاشر\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم: إن الله تعالى طيب لا يقبل إلا طيباً، وإن الله أمر المؤمنين بما أمر به المرسلين فقال تعالى {يا أيها الرسل كلوا من الطيبات واعملوا صالحا} وقال تعالى {يا أيها الذين آمنوا كلوا من طيبات ما رزقناكم} ثم ذكر الرجل يطيل السفر أشعث أغبر يمد يديه إلى السماء: يا رب يا رب، ومطعمه حرام"}, {"vol": 1, "page": 62, "text": "وملبسه حرام وغذي بالحرام فأنى يستجاب له» .\\nرواه مسلم."}, {"vol": 1, "page": 63, "text": "الحديث الحادي عشر\\n«عن أبي محمد الحسن بن علي بن أبي طالب سبط رسول الله صلى الله عليه وآله وسلم وريحانته ﵄ قال: حفظت من رسول الله صلى الله عليه وآله وسلم دع ما يريبك إلى ما لا يريبك» .\\nرواه الترمذي والنسائي، وقال الترمذي: حديث حسن صحيح."}, {"vol": 1, "page": 64, "text": "الحديث الثانى عشر\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم من حسن إسلام المرء تركه ما لا يعنيه» .\\nحديث حسن، رواه الترمذي وغيره وهكذا."}, {"vol": 1, "page": 65, "text": "الحديث الثالث عشر\\n«عن أبي حمزة أنس بن مالك رضي الله تعالى عنه خادم رسول الله صلى الله عليه وآله وسلم عن النبي صلى الله عليه وآله وسلم قال لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 66, "text": "الحديث الرابع عشر\\n«عن ابن مسعود رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم لا يحل دم امرئ مسلم إلا بإحدى ثلاث: الثيب الزاني، والنفس بالنفس، والتارك لدينه المفارق للجماعة» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 67, "text": "الحديث الخامس عشر\\n«عن أبي هريرة رضي الله تعالى عنه أن رسول الله صلى الله عليه وآله وسلم قال: من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت، ومن كان يؤمن بالله واليوم الآخر فليكرم جاره، ومن كان يؤمن بالله واليوم الآخر فليكرم ضيفه» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 68, "text": "الحديث السادس عشر\\n«عن أبي هريرة رضي الله تعالى عنه أن رجلاً قال للنبي صلى الله عليه وآله وسلم: أوصني، قال لا تغضب فردد مراراً، قال لا تغضب» .\\nرواه البخاري."}, {"vol": 1, "page": 69, "text": "الحديث السابع عشر\\n«عن أبي يعلى شداد بن أوس رضي الله تعالى عنه عن رسول الله صلى الله عليه وآله وسلم قال إن الله كتب الإحسان على كل شئ، فإذا قتلتم فأحسنوا القتلة وإذا ذبحتم فأحسنوا الذبحة، وليحد أحدكم شفرته وليرح ذبيحته» .\\nرواه مسلم."}, {"vol": 1, "page": 70, "text": "الحديث الثامن عشر\\n«عن أبي ذر جندب بن جنادة، وأبي عبد الرحمن معاذ بن جبل رضي الله تعالى عنهما عن رسول الله صلى الله عليه وآله وسلم قال: إتق الله حيثما كنت، وأتبع السيئة الحسنة تمحها، وخالق الناس بخلق حسن» .\\nرواه الترمذي وقال: حديث حسن، وفي بعض النسخ: حسن صحيح."}, {"vol": 1, "page": 71, "text": "الحديث التاسع عشر\\n«عن أبي العباس عبد الله بن عباس رضي الله تعالى عنهما قال: كنت خلف النبي صلى الله عليه وآله وسلم يوماً فقال يا غلام، إني أعلمك كلمات: إحفظ الله يحفظك، إحفظ الله تجده تجاهك، إذا سألت فاسأل الله، وإذا استعنت فاستعن بالله، واعلم أن الأمة لو اجتمعت على أن ينفعوك بشئ لم ينفعوك إلا بشئ قد كتبه الله لك،"}, {"vol": 1, "page": 72, "text": "وإن اجتمعوا على أن يضروك بشئ لم يضروك إلا بشئ قد كتبه الله عليك، رفعت الأقلام وجفت الصحف» .\\nرواه الترمذي وقال حديث حسن صحيح.\\nوفي رواية غير الترمذي «إحفظ الله تجده أمامك، تعرف إلى الله في الرخاء يعرفك في الشدة، واعلم أن ما أخطأك لم يكن ليصيبك، وما أصابك لم يكن ليخطئك، واعلم أن النصر مع الصبر، وأن الفرج مع الكرب، وأن مع العسر يسراً» ."}, {"vol": 1, "page": 73, "text": "الحديث العشرون\\n«عن أبي مسعود عقبة بن عمرو الأنصاري البدري ﵁ قال: قال رسول الله صلى الله عليه وآله وسلم: إن مما أدرك الناس من كلام النبوة الأولى: إذا لم تستح فاصنع ما شئت» .\\nرواه البخاري."}, {"vol": 1, "page": 74, "text": "الحديث الحادي والعشرون\\n«عن أبي عمرو - وقيل أبي عمرة - سفيان ابن عبد الله ﵁ قال: قلت يا رسول الله قل لي في الإسلام قولاً لا أسال عنه أحداً غيرك، قال قل آمنت بالله، ثم استقم» .\\nرواه مسلم."}, {"vol": 1, "page": 75, "text": "الحديث الثانى والعشرون\\n«عن أبي عبد الله جابر بن عبد الله الأنصاري ﵄ أن رجلاً سأل رسول الله صلى الله عليه وآله وسلم فقال: أرأيت إذا صليت المكتوبات، وصمت رمضان، وأحللت الحلال، وحرمت الحرام، ولم أزد على ذلك شيئاً، أدخل الجنة؟ قال نعم» .\\nرواه مسلم.\\nومعنى حرمت الحرام: اجتنبته،"}, {"vol": 1, "page": 76, "text": "ومعنى أحللت الحلال: فعلته معتقداً حله."}, {"vol": 1, "page": 77, "text": "الحديث الثالث والعشرون\\n«عن أبي مالك الحارث بن الأشعري ﵁ قال: قال رسول الله صلى الله عليه وآله وسلم الطهور شطر الإيمان، والحمد لله تملأ الميزان، وسبحان الله والحمد لله تملآن - أو تملأ - ما بين"}, {"vol": 1, "page": 78, "text": "السماء والأرض، والصلاة نور، والصدقة برهان، والصبر ضياء، والقرآن حجة لك أو عليك، كل الناس يغدو: فبائع نفسه فمعتقها أو موبقها» .\\nرواه مسلم."}, {"vol": 1, "page": 79, "text": "الحديث الرابع والعشرون\\n«عن أبي ذر الغفاري رضي الله تعالى عنه عن النبي صلى الله تعالى عليه وآله وسلم فيما يرويه عن ربه ﷿ أنه قال يا عبادي، إني حرمت الظلم على نفسي وجعلته بينكم محرماً فلا تظالموا،"}, {"vol": 1, "page": 80, "text": "يا عبادي، كلكم ضال إلا من هديته فاستهدوني أهدكم، يا عبادي، كلكم جائع إلا من أطعمته فاستطعموني أطعمكم، يا عبادي، كلكم عار إلا من كسوته فاستكسوني أكسكم: يا عبادي، إنكم تخطئون بالليل والنهار وأنا أغفر الذنوب جميعاً فاستغفروني أغفر لكم، ياعبادي، إنكم لن تبلغوا ضري فتضروني ولن تبلغوا نفعي فتنفعوني، يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم كانوا على أتقى قلب رجل واحد منكم ما زاد ذلك في ملكي شيئاً:"}, {"vol": 1, "page": 81, "text": "يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم كانوا على أفجر قلب رجل واحد منكم ما نقص ذلك من ملكي شيئاً: يا عبادي، لو أن أولكم وآخركم وإنسكم وجنكم قاموا في صعيد واحد فسألوني فأعطيت كل واحد مسألته ما نقص ذلك مما عندي إلا كما ينقص المخيط إذا أدخل البحر، يا عبادي، إنما هي أعمالكم أحصيها لكم ثم أوفيكم إياها فمن وجد خيراً فليحمد الله ومن"}, {"vol": 1, "page": 82, "text": "وجد غير ذلك فلا يلومن إلا نفسه» .\\nرواه مسلم."}, {"vol": 1, "page": 83, "text": "الحديث الخامس والعشرون\\n«عن أبي ذر ﵁ أيضاً أن ناساً من أصحاب رسول الله صلى الله عليه وآله وسلم قالوا للنبي صلى الله تعالى وعليه وآله وسلم: يا رسول الله، ذهب أهل الدثور بالأجور: يصلون كما نصلي ويصومون كما نصوم، ويتصدقون بفضول أموالهم.\\nقال: أوليس قد جعل الله لكم ما تصدقون: إن بكل تسبيحة صدقة، وكل تكبيرة صدقة، وكل"}, {"vol": 1, "page": 84, "text": "تحميدة صدقة، وكل تهليلة صدقة، وأمر بمعروف صدقة، ونهي عن منكر صدقة، وفي بضع أحدكم صدقة، قالوا: يا رسول الله، أيأتي أحدنا شهوته ويكون له فيها أجر؟ قال أرأيتم لو وضعها في حرام أكان عليه وزر؟ فكذلك إذا وضعها في الحلال كان له أجر» .\\nرواه مسلم."}, {"vol": 1, "page": 85, "text": "الحديث السادس والعشرون\\n«عن أبي هريرة رضي الله تعالى عنه قال: قال رسول الله صلى الله عليه وآله وسلم كل سلامى من الناس عليه صدقة كل يوم تطلع فيه الشمس: تعدل بين اثنين صدقة، وتعين الرجل في دابته فتحمله عليها أو ترفع"}, {"vol": 1, "page": 86, "text": "له عليها متاعه صدقة، والكلمة الطيبة صدقة، وبكل خطوة تمشيها إلى الصلاة صدقة، وتميط الأذى عن الطريق صدقة» .\\nرواه البخاري ومسلم."}, {"vol": 1, "page": 87, "text": "الحديث السابع والعشرون\\n«عن النواس بن سمعان رضي الله تعالى عنه عن النبي صلى الله عليه وعلى آله وسلم قال البر حسن الخلق، والإثم ما حاك في نفسك وكرهت أن يطلع عليه الناس» .\\nرواه مسلم\\nوعن وابصة بن معبد رضي الله تعالى عنه قال: «أتيت رسول الله صلى الله عليه وآله وسلم فقال: جئت تسأل عن البر؟ قلت: نعم، وقال: إستفت قلبك، البر ما"}, {"vol": 1, "page": 88, "text": "اطمأنت إليه النفس واطمأن إليه القلب، والإثم ما حاك في النفس وتردد في الصدر وإن أفتاك الناس وأفتوك» .\\nحديث حسن.\\nرويناه في مسندي الإمامين أحمد بن حنبل والدرامي بإسناد حسن."}, {"vol": 1, "page": 89, "text": "الحديث الثامن والعشرون\\n«عن أبي نجيح العرباض بن سارية رضي الله تعالى عنه قال: وعظنا رسول الله صلى الله عليه وآله وسلم موعظة وجلت منها القلوب وذرفت منها العيون، فقلنا: يا رسول الله كأنها موعظة مودع فأوصنا، قال أوصيكم بتقوى الله ﷿ والسمع والطاعة وإن تأمر عليكم عبد،"}, {"vol": 1, "page": 90, "text": "فإنه من يعش منكم فسيري اختلافاً كثيراً، فعليكم بسنتي وسنة الخلفاء الراشدين المهديين عضوا عليها بالنواجذ، وإياكم ومحدثات الأمور فإن كل بدعة ضلالة» .\\nرواه أبو داود والترمذي وقال: حديث حسن صحيح."}, {"vol": 1, "page": 91, "text": "الحديث التاسع والعشرون\\n«عن معاذ بن جبل ﵁ قال: قلت يا رسول الله أخبرني بعمل يدخلني الجنة ويباعدني عن النار، قال: لقد سألت عن عظيم وإنه ليسير على من يسره الله تعالى عليه: تعبد الله لا تشرك به شيئاً، وتقيم الصلاة، وتؤتي الزكاة، وتصوم رمضان، وتحج البيت ثم قال: ألا أدلك على أبواب الخير؟ : الصوم جنة، والصدقة تطفئ الخطيئة كما يطفئ الماء النار، وصلاة الرجل في جوف الليل"}, {"vol": 1, "page": 92, "text": "ثم تلا: {تتجافى جنوبهم عن المضاجع} {حتى إذا بلغ} {يعملون} ثم قال ألا أخبرك برأس الأمر وعموده وذروة سنامه؟ قلت: بلى يا رسول الله.\\nقال رأس الأمر الإسلام، وعموده الصلاة، وذروة سنامه الجهاد"}, {"vol": 1, "page": 93, "text": "ثم قال: ألا أخبرك بملاك ذلك كله؟ قلت: بلى يا رسول الله، فأخذ بلسانه وقال كف عليك هذا قلت: يا نبي الله، وإنا لمؤاخذون بما نتكلم به؟ فقال ثكلتك أمك، وهل يكب الناس في النار على وجوههم - أو قال على مناخرهم - إلا حصائد ألسنتهم؟» .\\nرواه الترمذي وقال: حديث حسن صحيح."}, {"vol": 1, "page": 94, "text": "الحديث الثلاثون\\n«عن أبي ثعلبة الخشبي جرثوم بن ناشر رضي الله تعالى عنه عن رسول الله ﷺ قال إن الله تعالى فرض فرائض فلا تضيعوها، وحد حدوداً فلا تعتدوها، وحرم أشياء فلا تنتهكوها،"}, {"vol": 1, "page": 95, "text": "وسكت عن أشياء رحمة لكم غير نسيان فلا تبحثوا عنها» .\\nحديث حسن رواه الدارقطني وغيره."}, {"vol": 1, "page": 96, "text": "الحديث الحادي والثلاثون\\n«عن أبي العباس سهل بن سعد الساعدى رضي الله تعالى عنه قال جاء رجل إلى النبي صلى الله عليه وآله وسلم فقال: يا رسول الله، دلني على عمل إذا عملته أحبني الله وأحبني الناس: فقال إزهد في الدنيا يحبك الله، وازهد فيما عند الناس يحبك الناس» .\\nحديث حسن، رواه ابن ماجة وغيره بأسانيد حسنة."}, {"vol": 1, "page": 97, "text": "الحديث الثاني والثلاثون\\n«عن أبي سعيد سعد بن مالك بن سنان الخدري رضي الله تعالى عنه أن رسول الله صلى الله وعليه وآله وسلم قال: لا ضرر ولا ضرار» .\\nحديث حسن، رواه ابن ماجة والدارقطني وغيرهما مسنداً."}, {"vol": 1, "page": 98, "text": "ورواه مالك في الموطإ مرسلاً عن عمرو بن يحيى عن أبيه عن النبي صلى الله عليه وآله وسلم، فأسقط أبا سعيد، وله طرق يقوي بعضها بعضاً."}, {"vol": 1, "page": 99, "text": "الحديث الثالث والثلاثون\\n«عن ابن عباس ﵄ أن رسول الله صلى الله عليه وآله وسلم قال: لو يعطى الناس بدعواهم لادعى رجال أموال قوم ودماءهم، لكن البينة على المدعى واليمين على من أنكر» .\\nحديث حسن، رواه البيهقي وغيره هكذا، وبعضه في الصحيحين."}, {"vol": 1, "page": 100, "text": "الحديث الرابع والثلاثون\\n«عن أبي سعيد الخدري ﵁ قال: سمعت رسول الله صلى الله عليه وآله وسلم يقوم: من رأى منكم منكراً فليغيره بيده، فإن لم يستطع فبلسانه، فإن لم يستطع فبقلبه، وذلك أضعف الإيمان» .\\nرواه مسلم."}, {"vol": 1, "page": 101, "text": "الحديث الخامس والثلاثون\\n«عن أبي هريرة ﵁ قال: قال رسول الله صلى الله عليه وآله وسلم لا تحاسدوا، ولا تناجشوا ولا تباغضوا، ولا تدابروا، ولا يبع بعضكم على بيع بعض، وكونوا عباد الله إخواناً، المسلم أخو المسلم لا يظلمه ولا يخذله ولا يكذبه ولا يحقره، التقوى ههنا - ويشير"}, {"vol": 1, "page": 102, "text": "إلى صدور ثلاث مرات - بحسب امرئ من الشر أن يحقر أخاه المسلم، كل المسلم على المسلم حرام: دمه وماله وعرضه» .\\nرواه مسلم."}, {"vol": 1, "page": 103, "text": "الحديث السادس والثلاثون\\n«عن أبي هريرة ﵁ عن النبي صلى الله عليه وآله وسلم قال من نفس عن مؤمن كربة من كرب الدنيا نفس الله عنه كربة من كرب يوم القيامة، ومن يسر على معسر يسر الله عليه في الدنيا والآخرة، ومن ستر مسلماً ستره الله في الدنيا والآخرة، والله في عون العبد ما كان العبد في عون أخيه، ومن سلك طريقاً يلتمس فيه علماً سهل الله له به طريقاً إلى الجنة، وما اجتمع قوم في بيت من بيوت الله يتلون كتاب الله ويتدارسونه بينهم إلا نزلت عليهم السكينة"}, {"vol": 1, "page": 104, "text": "وغشيتهم الرحمة وحفتهم الملائكة وذكرهم الله فيمن عنده، ومن بطأ به عمله لم يسرع به نسبه» .\\nرواه مسلم بهذا اللفظ."}, {"vol": 1, "page": 105, "text": "الحديث السابع والثلاثون\\n«عن ابن عباس ﵄ عن رسول الله صلى الله عليه وآله وسلم فيما يرويه عن ربه تبارك وتعالى قال إن الله كتب الحسنات والسيئات ثم بين ذلك، فمن هم بحسنة فلم يعملها كتبها الله عنده حسنة كاملة، وإن هم بها فعملها كتبها الله عنده عشر حسنات إلى سبعمائة ضعف إلى أضعاف كثيرة، وإن هم بسيئة فلم يعملها كتبها الله عنده حسنة كاملة، وإن هم بها فعملها كتبها الله سيئة واحدة» ."}, {"vol": 1, "page": 106, "text": "رواه البخاري ومسلم في صحيحيهما بهذه الحروف فانظر يا أخي وفقنا الله وإياك إلى عظيم لطف الله تعالى، وتأمل هذه الألفاظ، وقوله عنده إشارة إلى الإعتناء بها، وقوله كاملة للتأكيد وشدة الإعتناء بها، وقال في السيئة التي هم بها ثم تركها كتبها الله عنه حسنة كاملة فأكدها بـ (كاملة) وإن عملها كتبها سيئة واحدة، فأكد تقليلها"}, {"vol": 1, "page": 107, "text": "بـ (واحدة) ولم يؤكدها بـ (كاملة) فلله الحمد والمنة، سبحانه لا نحصي ثناء عليه، وبالله التوفيق."}, {"vol": 1, "page": 108, "text": "الحديث الثامن والثلاثون\\n«عن أبي هريرة ﵁ قال: قال رسول الله صلى الله عليه وآله وسلم: إن الله تعالى قال: من عادى لي ولياً فقد آذنته بالحرب، وما تقرب إلى عبدي بشئ أحب إلي مما افترضته عليه، ولا يزال عبدي يتقرب إلي"}, {"vol": 1, "page": 109, "text": "بالنوافل حتى أحبه، فإذا أحببته كنت سمعه الذي يسمع به وبصره الذي يبصر به ويده التي يبطش بها ورجله التي يمشي بها، ولئن سألني لأعطينه، ولئن استعاذني لأعيذنه» .\\nرواه البخاري."}, {"vol": 1, "page": 110, "text": "الحديث التاسع والثلاثون\\n«عن ابن عباس ﵄ أن رسول الله صلى الله عليه وآله وسلم قال إن الله تجاوز لي عن أمتى الخطأ والنسيان وما اسكترهوا عليه» .\\nحديث حسن رواه ابن ماجة والبيهقي وغيرهما."}, {"vol": 1, "page": 111, "text": "الحديث الأربعون\\n«عن ابن عمر ﵄ قال: أخذ رسول الله صلى الله عليه وآله وسلم بمنكبي فقال: كن في الدنيا كأنك غريب أو عابر سبيل» وكان ابن عمر رضي الله تعالى عنهما يقول: إذا أمسيت فلا تنتظر الصباح، وإذا أصبحت فلا تنتظر"}, {"vol": 1, "page": 112, "text": "المساء، وخذ من صحتك لمرضك، ومن حياتك لموتك.\\nرواه البخاري."}, {"vol": 1, "page": 113, "text": "الحديث الحادي والأربعون\\n«عن أبي محمد عبد الله بن عمرو بن العاص ﵄ قال: قال رسول الله صلى الله عليه وآله وسلم: لا يؤمن أحدكم حتى يكون هواه تبعاً لما جئت به» .\\nحديث حسن صحيح، رويناه في كتاب الحجة بإسناد صحيح."}, {"vol": 1, "page": 114, "text": "الحديث الثاني والأربعون\\n«عن أنس ﵁ قال: سمعت رسول الله صلى الله عليه وآله وسلم يقول: قال الله تعالى يابن آدم، إنك ما دعوتني ورجوتني غفرت للك على ما كان منك ولا أبالي، يا ابن آدم لو بلغت ذنوبك عنان السماء ثم"}, {"vol": 1, "page": 115, "text": "استغفرتني غفرت لك، يا ابن آدم لو أتيتني بقراب الأرض خطايا ثم لقيتني لا تشرك بي شيئاً لأتيتك بقرابها مغفرة» .\\nرواه الترمذي وقال: حديث حسن صحيح."}], "indexes": {"hadiths": {"1": 12, "2": 14, "3": 18, "4": 19, "5": 21, "6": 22, "7": 24, "8": 25, "9": 26, "10": 27, "11": 29, "12": 30, "13": 31, "14": 32, "15": 33, "16": 34, "17": 35, "18": 36, "19": 37, "20": 39, "21": 40, "22": 41, "23": 43, "24": 45, "25": 49, "26": 51, "27": 53, "28": 55, "29": 57, "30": 60, "31": 62, "32": 63, "33": 65, "34": 66, "35": 67, "36": 69, "37": 71, "38": 74, "39": 76, "40": 77, "41": 79, "42": 80}, "headings": [{"page": 1, "level": 1, "title": "مقدمة المؤلف"}, {"page": 12, "level": 1, "title": "الحديث الأول"}, {"page": 14, "level": 1, "title": "الحديث الثاني"}, {"page": 18, "level": 1, "title": "الحديث الثالث"}, {"page": 19, "level": 1, "title": "الحديث الرابع"}, {"page": 21, "level": 1, "title": "الحديث الخامس"}, {"page": 22, "level": 1, "title": "الحديث السادس"}, {"page": 24, "level": 1, "title": "الحديث السابع"}, {"page": 25, "level": 1, "title": "الحديث الثامن"}, {"page": 26, "level": 1, "title": "الحديث التاسع"}, {"page": 27, "level": 1, "title": "الحديث العاشر"}, {"page": 29, "level": 1, "title": "الحديث الحادي عشر"}, {"page": 30, "level": 1, "title": "الحديث الثانى عشر"}, {"page": 31, "level": 1, "title": "الحديث الثالث عشر"}, {"page": 32, "level": 1, "title": "الحديث الرابع عشر"}, {"page": 33, "level": 1, "title": "الحديث الخامس عشر"}, {"page": 34, "level": 1, "title": "الحديث السادس عشر"}, {"page": 35, "level": 1, "title": "الحديث السابع عشر"}, {"page": 36, "level": 1, "title": "الحديث الثامن عشر"}, {"page": 37, "level": 1, "title": "الحديث التاسع عشر"}, {"page": 39, "level": 1, "title": "الحديث العشرون"}, {"page": 40, "level": 1, "title": "الحديث الحادي والعشرون"}, {"page": 41, "level": 1, "title": "الحديث الثانى والعشرون"}, {"page": 43, "level": 1, "title": "الحديث الثالث والعشرون"}, {"page": 45, "level": 1, "title": "الحديث الرابع والعشرون"}, {"page": 49, "level": 1, "title": "الحديث الخامس والعشرون"}, {"page": 51, "level": 1, "title": "الحديث السادس والعشرون"}, {"page": 53, "level": 1, "title": "الحديث السابع والعشرون"}, {"page": 55, "level": 1, "title": "الحديث الثامن والعشرون"}, {"page": 57, "level": 1, "title": "الحديث التاسع والعشرون"}, {"page": 60, "level": 1, "title": "الحديث الثلاثون"}, {"page": 62, "level": 1, "title": "الحديث الحادي والثلاثون"}, {"page": 63, "level": 1, "title": "الحديث الثاني والثلاثون"}, {"page": 65, "level": 1, "title": "الحديث الثالث والثلاثون"}, {"page": 66, "level": 1, "title": "الحديث الرابع والثلاثون"}, {"page": 67, "level": 1, "title": "الحديث الخامس والثلاثون"}, {"page": 69, "level": 1, "title": "الحديث السادس والثلاثون"}, {"page": 71, "level": 1, "title": "الحديث السابع والثلاثون"}, {"page": 74, "level": 1, "title": "الحديث الثامن والثلاثون"}, {"page": 76, "level": 1, "title": "الحديث التاسع والثلاثون"}, {"page": 77, "level": 1, "title": "الحديث الأربعون"}, {"page": 79, "level": 1, "title": "الحديث الحادي والأربعون"}, {"page": 80, "level": 1, "title": "الحديث الثاني والأربعون"}]}}		44	f	t	2020-06-15 06:45:55.63373+00	2020-06-15 06:45:55.633779+00	\N		\N	\N	81	\N	2	\N	4
\.


--
-- Name: books_book_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.books_book_id_seq', 3, true);


--
-- Data for Name: books_bookcomment; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.books_bookcomment (id, comment, page, line, book_id, user_id) FROM stdin;
\.


--
-- Name: books_bookcomment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.books_bookcomment_id_seq', 1, false);


--
-- Data for Name: books_bookhighlight; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.books_bookhighlight (id, page, line, start, "end", book_id, user_id) FROM stdin;
\.


--
-- Name: books_bookhighlight_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.books_bookhighlight_id_seq', 1, false);


--
-- Data for Name: books_bookmark; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.books_bookmark (id, page, book_id, user_id) FROM stdin;
\.


--
-- Name: books_bookmark_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.books_bookmark_id_seq', 1, false);


--
-- Data for Name: books_bookmedia; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.books_bookmedia (id, type, url, approved, book_id, user_id) FROM stdin;
\.


--
-- Name: books_bookmedia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.books_bookmedia_id_seq', 1, false);


--
-- Data for Name: books_bookrating; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.books_bookrating (id, rating, book_id, user_id) FROM stdin;
3	3	1	4
4	2	2	4
5	4	2	3
\.


--
-- Name: books_bookrating_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.books_bookrating_id_seq', 4, true);


--
-- Data for Name: books_bookreview; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.books_bookreview (id, comment, book_id, user_id) FROM stdin;
\.


--
-- Name: books_bookreview_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.books_bookreview_id_seq', 1, false);


--
-- Data for Name: categories_category; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.categories_category (id, name) FROM stdin;
1	الرقاق والآداب والأذكار
2	الحديث
\.


--
-- Name: categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.categories_category_id_seq', 2, true);


--
-- Data for Name: categories_subcategory; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.categories_subcategory (id, name, category_id) FROM stdin;
\.


--
-- Name: categories_subcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.categories_subcategory_id_seq', 1, true);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2020-06-15 04:53:20.000226+00	4	adhm_n4@yahoo.com	2	[{"changed": {"fields": ["Staff status"]}}]	23	3
2	2020-06-15 04:56:48.627584+00	4	adhm_n4@yahoo.com	2	[{"changed": {"fields": ["User permissions"]}}]	23	3
3	2020-06-15 05:15:29.339109+00	4	adhm_n4@yahoo.com	2	[{"changed": {"fields": ["Groups"]}}]	23	3
4	2020-06-15 07:18:10.650895+00	1	الرقاق والآداب والأذكار	2	[]	16	3
5	2020-06-15 07:18:18.086178+00	2	Test	1	[{"added": {}}]	16	3
6	2020-06-15 07:18:31.80632+00	1	Sub Test	1	[{"added": {}}]	17	3
7	2020-06-15 07:18:45.495724+00	2	Test	3		16	3
8	2020-06-15 07:18:54.737899+00	1	Sub Test	3		17	3
9	2020-06-15 07:26:41.13154+00	3	admin@al-shamelah.com	2	[{"changed": {"fields": ["password"]}}]	23	3
10	2020-06-15 07:27:43.691683+00	5		1	[{"added": {}}]	23	3
11	2020-06-15 07:27:58.530552+00	5		2	[{"changed": {"fields": ["Groups"]}}]	23	3
12	2020-06-15 07:41:16.959437+00	4	adhm_n4@yahoo.com	2	[{"changed": {"fields": ["Name"]}}]	23	3
13	2020-06-15 07:52:09.239818+00	4	adhm_n4@yahoo.com	2	[]	23	3
14	2020-06-16 03:09:00.948625+00	5		3		23	3
15	2020-06-16 03:12:47.815823+00	7		1	[{"added": {}}]	23	3
16	2020-06-16 03:13:09.903617+00	7	ahmed@al-shamelah.com	2	[{"changed": {"fields": ["Name", "Email address", "Staff status", "Superuser status"]}}]	23	3
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 16, true);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	books	bookmedia
2	books	bookaudio
3	books	bookpdf
4	admin	logentry
5	auth	permission
6	auth	group
7	contenttypes	contenttype
8	sessions	session
9	sites	site
10	authtoken	token
11	account	emailaddress
12	account	emailconfirmation
13	socialaccount	socialaccount
14	socialaccount	socialapp
15	socialaccount	socialtoken
16	categories	category
17	categories	subcategory
18	books	book
19	books	bookrating
20	books	bookcomment
21	books	bookmark
22	books	bookhighlight
23	users	user
24	users	otp
25	users	emailotp
26	users	phoneotp
27	books	bookreview
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 27, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
8	contenttypes	0001_initial	2020-06-15 00:17:10.713258+00
9	contenttypes	0002_remove_content_type_name	2020-06-15 00:17:10.723198+00
10	auth	0001_initial	2020-06-15 00:17:10.734824+00
11	auth	0002_alter_permission_name_max_length	2020-06-15 00:17:10.743258+00
12	auth	0003_alter_user_email_max_length	2020-06-15 00:17:10.747877+00
13	auth	0004_alter_user_username_opts	2020-06-15 00:17:10.752264+00
14	auth	0005_alter_user_last_login_null	2020-06-15 00:17:10.756272+00
15	auth	0006_require_contenttypes_0002	2020-06-15 00:17:10.757474+00
16	auth	0007_alter_validators_add_error_messages	2020-06-15 00:17:10.762509+00
17	auth	0008_alter_user_username_max_length	2020-06-15 00:17:10.767797+00
18	auth	0009_alter_user_last_name_max_length	2020-06-15 00:17:10.771803+00
19	auth	0010_alter_group_name_max_length	2020-06-15 00:17:10.77675+00
20	auth	0011_update_proxy_permissions	2020-06-15 00:17:10.792642+00
21	users	0001_initial	2020-06-15 00:17:10.811015+00
22	account	0001_initial	2020-06-15 00:17:10.833215+00
23	account	0002_email_max_length	2020-06-15 00:17:10.845438+00
24	admin	0001_initial	2020-06-15 00:17:10.854735+00
25	admin	0002_logentry_remove_auto_add	2020-06-15 00:17:10.863799+00
26	admin	0003_logentry_add_action_flag_choices	2020-06-15 00:17:10.872444+00
27	authtoken	0001_initial	2020-06-15 00:17:10.881377+00
28	authtoken	0002_auto_20160226_1747	2020-06-15 00:17:10.93362+00
29	categories	0001_initial	2020-06-15 00:17:10.941073+00
30	sessions	0001_initial	2020-06-15 00:17:10.946372+00
31	sites	0001_initial	2020-06-15 00:17:10.951121+00
32	sites	0002_alter_domain_unique	2020-06-15 00:17:10.955068+00
33	socialaccount	0001_initial	2020-06-15 00:17:10.992383+00
34	socialaccount	0002_token_max_lengths	2020-06-15 00:17:11.015116+00
35	socialaccount	0003_extra_data_default_dict	2020-06-15 00:17:11.022377+00
36	books	0001_initial	2020-06-15 00:17:48.636496+00
37	users	0002_auto_20200615_0021	2020-06-15 00:21:56.545694+00
38	books	0002_auto_20200615_0114	2020-06-15 01:14:11.815689+00
39	books	0003_auto_20200615_0241	2020-06-15 02:41:31.901159+00
40	categories	0002_auto_20200616_1853	2020-06-16 18:53:44.886141+00
41	books	0004_bookreview	2020-06-21 19:56:58.036411+00
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 41, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
zqcuk5be27hu4q02xbd25kbcny20jhs4	MjIwMzUyYzg4OTE3NjRjNzMyMzYzOWVmNjc0NTFiNmM1ODNmMDMzZTp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiYWxsYXV0aC5hY2NvdW50LmF1dGhfYmFja2VuZHMuQXV0aGVudGljYXRpb25CYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZjhlNzg2MDhjMDNmNmY0MTU5OGQyNTUzYmM4ODEzZWI2ODIyNjNmYSJ9	2020-06-29 01:22:46.26851+00
ft4rg48rdlzv3ejxerons03a48tsto65	MjIwMzUyYzg4OTE3NjRjNzMyMzYzOWVmNjc0NTFiNmM1ODNmMDMzZTp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiYWxsYXV0aC5hY2NvdW50LmF1dGhfYmFja2VuZHMuQXV0aGVudGljYXRpb25CYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZjhlNzg2MDhjMDNmNmY0MTU5OGQyNTUzYmM4ODEzZWI2ODIyNjNmYSJ9	2020-06-29 07:21:04.930994+00
tit68i3ahyqy8pe3roj1eztnqm6umlsi	MDc0NjhhMGQyMWNkYmNkYTc3ZWExNmI4MDkxOGFlNDJiODVmNmMyMzp7ImFjY291bnRfdmVyaWZpZWRfZW1haWwiOm51bGwsImFjY291bnRfdXNlciI6IjYiLCJfYXV0aF91c2VyX2lkIjoiNiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImFsbGF1dGguYWNjb3VudC5hdXRoX2JhY2tlbmRzLkF1dGhlbnRpY2F0aW9uQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6IjViODA2ZDQ5NjdkYTNiYmMzZjU1ODA2NTQ1M2ViMTk2YmI4MWRiMzgifQ==	2020-06-29 16:05:44.904592+00
0gfcs6lxvazrrdnq50zzi9vqted0ncev	NmQxNjI5ODZjYTAwZGIxN2FlMzIwYTE0NTkzNTY1MDA4YWJkMDIwYjp7Il9hdXRoX3VzZXJfaWQiOiI3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiYWxsYXV0aC5hY2NvdW50LmF1dGhfYmFja2VuZHMuQXV0aGVudGljYXRpb25CYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMWEzZGU0ZjM5ZjJkNTEwYzU5NGEzYTkyODFhYzM5NDliNjRjYTY4MCJ9	2020-06-30 03:13:44.163205+00
4fd0zpxgn2qrx7zblxm88u0eogqw37jr	N2Q1ZjgwODk0MjQ1NWQyMWM1NzAwYzMyZmVmYTc4MzcyMGZlMDI4Mjp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiYWxsYXV0aC5hY2NvdW50LmF1dGhfYmFja2VuZHMuQXV0aGVudGljYXRpb25CYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNjU0NTA0YjZjNjRhMjJlMGFkODc0NzAxYmEzZTY2NzhlMTFjMTJhYyJ9	2020-06-30 20:54:56.759858+00
2b31joxm6v1oe56tsrz1wl0dri865swr	OGFlYzU2YWYyODYyYjIzYzVlNzdkZGI4MDZiMmM2MGRkMzI5ZWZlOTp7ImFjY291bnRfdmVyaWZpZWRfZW1haWwiOm51bGwsImFjY291bnRfdXNlciI6ImciLCJfYXV0aF91c2VyX2lkIjoiMTYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJhbGxhdXRoLmFjY291bnQuYXV0aF9iYWNrZW5kcy5BdXRoZW50aWNhdGlvbkJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkYTYyNjlhMDExMWUyODkzMWFlYTI2ZTE1NTY2M2IzZTkwMDJhZmY3In0=	2020-07-05 05:12:51.016558+00
07iblivtxokojzzln42lr4edw1r3ce8b	ZmEyYmNhNDRhNzQ1NGY2M2NkYzJjMzQ5MzJhOWJmYmIyMGYzNjg1Zjp7Il9hdXRoX3VzZXJfaWQiOiIxNyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImFsbGF1dGguYWNjb3VudC5hdXRoX2JhY2tlbmRzLkF1dGhlbnRpY2F0aW9uQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImE0NTg0NDEzYjQxZDIzYjA2MzY0MWQzZDc3NTVjMjQ1ZjA3NzMzMTIifQ==	2020-07-05 05:59:09.697019+00
wy85z2tpmg3bftiak8garb6sf8jgbymf	YzM2NmQ2ZDg1MWY2YzYyMzk2MTIzNjRjZThjMTAzNDVhNjQ5ZmFlYzp7ImFjY291bnRfdmVyaWZpZWRfZW1haWwiOm51bGwsImFjY291bnRfdXNlciI6ImoiLCJfYXV0aF91c2VyX2lkIjoiMTkiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJhbGxhdXRoLmFjY291bnQuYXV0aF9iYWNrZW5kcy5BdXRoZW50aWNhdGlvbkJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyOGM0Yzk2ZGRmZWY3ODZiNmUzODliOWQ5MzJmMDIzYTllZWM3NzUwIn0=	2020-07-05 06:37:52.200306+00
x3cd51g2uhd7pkdrfo3prxhbem8by5o5	MDQ5YzQ4M2YyNTU5OGUzZTI2MWY2ZjllZjA3MDBjMTcyM2ZlOWMwMjp7Il9hdXRoX3VzZXJfaWQiOiIyOSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImFsbGF1dGguYWNjb3VudC5hdXRoX2JhY2tlbmRzLkF1dGhlbnRpY2F0aW9uQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImVkOWY0NDM1NTA4ZjE3M2ZhMzE3ZjBhYjgyZmZiZmJhMDFlNGI0YzUifQ==	2020-07-05 09:45:05.579294+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.django_site (id, domain, name) FROM stdin;
1	Al-Shamelah.com	Al-Shamelah App
\.


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, true);


--
-- Data for Name: socialaccount_socialaccount; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.socialaccount_socialaccount (id, provider, uid, last_login, date_joined, extra_data, user_id) FROM stdin;
\.


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.socialaccount_socialaccount_id_seq', 1, false);


--
-- Data for Name: socialaccount_socialapp; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.socialaccount_socialapp (id, provider, name, client_id, secret, key) FROM stdin;
\.


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_id_seq', 1, false);


--
-- Data for Name: socialaccount_socialapp_sites; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM stdin;
\.


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_sites_id_seq', 1, false);


--
-- Data for Name: socialaccount_socialtoken; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.socialaccount_socialtoken (id, token, token_secret, expires_at, account_id, app_id) FROM stdin;
\.


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.socialaccount_socialtoken_id_seq', 1, false);


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.spatial_ref_sys  FROM stdin;
\.


--
-- Data for Name: users_otp; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.users_otp (id, code, type, creation_time, last_update_time, verified, user_id) FROM stdin;
2	536564	E	2020-06-15 01:22:33.188113+00	2020-06-15 01:22:33.18815+00	f	4
3	758903	E	2020-06-15 16:05:29.201861+00	2020-06-15 16:05:29.201895+00	f	6
4	670407	E	2020-06-21 02:11:53.68385+00	2020-06-21 02:11:53.683885+00	f	8
5	337176	E	2020-06-21 02:14:40.898334+00	2020-06-21 02:14:40.898368+00	f	9
6	622116	E	2020-06-21 02:20:19.642502+00	2020-06-21 02:20:19.642535+00	f	10
7	516286	E	2020-06-21 02:22:59.324231+00	2020-06-21 02:22:59.324265+00	f	11
8	285972	E	2020-06-21 02:24:33.314827+00	2020-06-21 02:24:33.314858+00	f	12
9	820589	E	2020-06-21 02:44:44.932316+00	2020-06-21 02:44:44.932349+00	f	13
10	475205	E	2020-06-21 02:48:27.161017+00	2020-06-21 02:48:27.16105+00	f	14
11	024489	E	2020-06-21 02:51:25.563375+00	2020-06-21 02:51:25.563411+00	f	15
12	149724	E	2020-06-21 05:12:35.268782+00	2020-06-21 05:12:35.268814+00	f	16
13	047540	E	2020-06-21 05:58:51.79866+00	2020-06-21 05:58:51.798695+00	f	17
14	629927	E	2020-06-21 06:08:02.843409+00	2020-06-21 06:08:02.843444+00	f	18
15	513528	E	2020-06-21 06:37:36.122947+00	2020-06-21 06:37:36.12298+00	f	19
16	107646	E	2020-06-21 06:48:54.146492+00	2020-06-21 06:48:54.146529+00	f	20
17	035201	E	2020-06-21 07:09:17.478202+00	2020-06-21 07:09:17.478234+00	f	21
18	548541	E	2020-06-21 07:26:37.177708+00	2020-06-21 07:26:37.177744+00	f	22
19	871706	E	2020-06-21 07:41:40.986039+00	2020-06-21 07:41:40.986079+00	f	23
20	919778	E	2020-06-21 08:27:19.367909+00	2020-06-21 08:27:19.367946+00	f	24
21	863936	E	2020-06-21 08:31:01.309457+00	2020-06-21 08:31:01.309492+00	f	25
22	387091	E	2020-06-21 08:41:10.866288+00	2020-06-21 08:41:10.866328+00	f	26
23	653607	E	2020-06-21 08:52:29.160446+00	2020-06-21 08:52:29.160486+00	f	27
24	026751	E	2020-06-21 08:54:12.148102+00	2020-06-21 08:54:12.148138+00	f	28
25	619650	E	2020-06-21 09:44:49.874261+00	2020-06-21 09:44:49.874298+00	f	29
\.


--
-- Name: users_otp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.users_otp_id_seq', 25, true);


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.users_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, name, phone_code, phone, phone_verified, birthday, gender, membership, address, country, photo) FROM stdin;
15	pbkdf2_sha256$180000$gMfGKuIgRBOp$CMPYv3ixJafsia59kFq3tLh8rNdlqQszLlPE6rk/bMs=	2020-06-21 02:51:29.871254+00	f	asad			asad@sad.com	f	t	2020-06-21 02:51:25.463618+00	\N	\N	\N	f	\N	\N	\N			
16	pbkdf2_sha256$180000$haVBlbCvbulA$Wuky1vuURrGSrIM6DgEsmTFVjkO8YvsNJqABz3iNhjk=	2020-06-21 05:12:51.006537+00	f	sdsd			sdsd@ddf.com	f	t	2020-06-21 05:12:35.169546+00	\N	\N	\N	f	\N	\N	\N			
17	pbkdf2_sha256$180000$XX3ZIRj5ezmu$/cGYq6HHfKbODMFzpE9XOtq8HeYSqzIOMroOM+C6QNw=	2020-06-21 05:59:09.684607+00	f	ismad			ismad@sds.com	f	t	2020-06-21 05:58:51.696325+00	\N	\N	\N	f	\N	\N	\N			
18	pbkdf2_sha256$180000$zEoLwQofo2J3$V7lAztIJbQA12ZMyz4oA8Y6V3lmlL6hntnb3pcgY48M=	2020-06-21 06:08:07.157704+00	f	ahsh			Ahsh@ddd.com	f	t	2020-06-21 06:08:02.741318+00	\N	\N	\N	f	\N	\N	\N			
19	pbkdf2_sha256$180000$5yksNCURKrkq$e5iCnOCr3Mzs0aCAyZ5vo9mw2WK3DXP/wx2h0gusawI=	2020-06-21 06:37:52.189374+00	f	user			user@example.com	f	t	2020-06-21 06:37:36.020155+00	\N	\N	\N	f	\N	\N	\N			
20	pbkdf2_sha256$180000$YVbgABfX5NWK$GQGF+XA+jiIocsaIVeQkwWJkB8K7vXzKn+uofxtLIBo=	2020-06-21 06:49:10.188156+00	f	shs			Shs@djd.com	f	t	2020-06-21 06:48:54.042135+00	\N	\N	\N	f	\N	\N	\N			
21	pbkdf2_sha256$180000$r7s0HhRlkawA$GDLC8vmaNxUlGAYmm23djy6IzDHUW82xHqt7q+qUQjU=	2020-06-21 07:09:32.83964+00	f	sjsj			Sjsj@dfdjdj.com	f	t	2020-06-21 07:09:17.374549+00	\N	\N	\N	f	\N	\N	\N			
4	pbkdf2_sha256$180000$Ube2p0qwtLnY$S298Is3TzKq/NX1dpVweWhy5iVWeUA2MyssSQXP0cPo=	2020-06-15 04:54:30+00	f	adhm_n4			adhm_n4@yahoo.com	t	t	2020-06-15 01:22:33+00	Ahmed	\N	\N	f	\N	\N	\N			
6	pbkdf2_sha256$180000$Em45BBx63fCk$jHbp/6+gUCUhOuA/iTG+o60akp1DcJOBnS+TC042us4=	2020-06-15 16:05:44.893744+00	f	fatma1211994			fatma1211994@hotmail.com	f	t	2020-06-15 16:05:29.063219+00	\N	\N	\N	f	\N	\N	\N			
22	pbkdf2_sha256$180000$bLgpsGit8jwM$4uGLNbXUoM2iFN8LELNIcOrZYGJI5OzZkuE7AP8ZKpk=	2020-06-21 07:26:52.879082+00	f	jxjd			Jxjd@xnxn.com	f	t	2020-06-21 07:26:37.057464+00	\N	\N	\N	f	\N	\N	\N			
7	pbkdf2_sha256$180000$cNBvNzZSV2q1$wmaNLlkKpeMRR4DM46OwBb9z1N43xhQx9I80wgVnUNY=	2020-06-16 03:13:44.161022+00	t	ahmed			ahmed@al-shamelah.com	t	t	2020-06-16 03:12:47.727719+00	Ahmed	\N	\N	f	\N	\N	\N			
3	pbkdf2_sha256$180000$T3ywRu7Wwju5$xCELFQGiG7pUig3V7eiOuYKeQ6Y2xtiYlRijvg7i7Nw=	2020-06-16 20:54:56.755896+00	t	admin			admin@al-shamelah.com	t	t	2020-06-15 01:22:26.079216+00	\N	\N	\N	f	\N	\N	\N			
8	pbkdf2_sha256$180000$ZUm4uYHXTKes$cwjoHBhU8hWwJ6/xCqP5x2nsTshGOCAgecZqGbT6bJ8=	2020-06-21 02:12:09.553034+00	f	okaoko			okaoko@ssd.com	f	t	2020-06-21 02:11:53.491455+00	\N	\N	\N	f	\N	\N	\N			
9	pbkdf2_sha256$180000$Sxmhe0uMz1lk$QgLvG1Jxuue4MzXM8614ZBRGpo+N74xi0578yaawkpA=	2020-06-21 02:14:44.460772+00	f	asd			asd@dfdf.com	f	t	2020-06-21 02:14:40.795366+00	\N	\N	\N	f	\N	\N	\N			
10	pbkdf2_sha256$180000$pDtfHl4HyogO$Adlpr4aL1S+c1fXFWJrEzyHwIGEuye0Ac9bJKU4m3kg=	2020-06-21 02:20:35.292322+00	f	moh			moh@df.com	f	t	2020-06-21 02:20:19.534828+00	\N	\N	\N	f	\N	\N	\N			
11	pbkdf2_sha256$180000$Izc7twDzSI97$OJxYjccu6icyr0O8lWurVNoTMBz4Hb6oMepjJcnIsQQ=	2020-06-21 02:23:03.564493+00	f	ism			ism@sdfd.com	f	t	2020-06-21 02:22:59.224541+00	\N	\N	\N	f	\N	\N	\N			
12	pbkdf2_sha256$180000$Ojnedrcvqu8S$GQXzlKevfMKvW+fqCHzjHWqjemC+pdXf+hVnKFB+aWo=	2020-06-21 02:24:37.622515+00	f	ismaosfdf			ismaosfdf@wesad.com	f	t	2020-06-21 02:24:33.215472+00	\N	\N	\N	f	\N	\N	\N			
13	pbkdf2_sha256$180000$ZYdcjzculbtp$vEjsE4cbFSIiZFJ8o45gYxykKkRwlxcgqkeyftmeCA0=	2020-06-21 02:45:00.52186+00	f	mohsa			mohsa@dfdf.com	f	t	2020-06-21 02:44:44.820684+00	\N	\N	\N	f	\N	\N	\N			
14	pbkdf2_sha256$180000$l9BRV67mCQ90$K603fDS4MIU5BOJYw9MdUvf2WC9XqHg9r9b813/Jc8g=	2020-06-21 02:48:29.539726+00	f	mohww			mohww@df.com	f	t	2020-06-21 02:48:27.060159+00	\N	\N	\N	f	\N	\N	\N			
23	pbkdf2_sha256$180000$kNkUeV7Jhj8G$JOU5iZU9WXd8JU+GpY8xt/NTlEuK2GbBuCQRAw9UBJA=	2020-06-21 07:41:56.441129+00	f	sdhnhsh			sdhnhsh@sjk.com	f	t	2020-06-21 07:41:40.879528+00	\N	\N	\N	f	\N	\N	\N			
24	pbkdf2_sha256$180000$qvvfreIQlg5U$9JOIie6Bc65rV4k/tOi3GFQkzEEMaMQJVrmXeRsOQ8c=	2020-06-21 08:27:36.450252+00	f	gfgh			Gfgh@fgh.com	f	t	2020-06-21 08:27:19.262917+00	\N	\N	\N	f	\N	\N	\N			
25	pbkdf2_sha256$180000$fZK7TdAzw8ju$6pOqEIzF5uEaoZCuyLqIorySZ4FLFtH0pps8K1wl8uY=	2020-06-21 08:31:04.728178+00	f	xbxbs			Xbxbs@dhdj.com	f	t	2020-06-21 08:31:01.199857+00	\N	\N	\N	f	\N	\N	\N			
26	pbkdf2_sha256$180000$XKqLL9ttQ56C$sMn8pVkOkO/E2ChCsylu9mBvZlVJCjzcRMC3AsgBFG0=	2020-06-21 08:41:13.072886+00	f	dhfhdh			Dhfhdh@xjdj.com	f	t	2020-06-21 08:41:10.752349+00	\N	\N	\N	f	\N	\N	\N			
27	pbkdf2_sha256$180000$CqxfgKqXYdOX$lP7ibM2fvgDuGlK9c4iXXQO8IdWESmj7L1eNrUuRbXU=	2020-06-21 08:52:45.133144+00	f	xnxn			Xnxn@nxnx.com	f	t	2020-06-21 08:52:29.058725+00	\N	\N	\N	f	\N	\N	\N			
28	pbkdf2_sha256$180000$B2EE3Mw0kiQg$90c2FKdRLbEev9+XuO4LqOrtkiJ6FacMTT+W4joP7kE=	2020-06-21 08:54:16.521443+00	f	moh0			Moh@hdhd.com	f	t	2020-06-21 08:54:12.038495+00	\N	\N	\N	f	\N	\N	\N			
29	pbkdf2_sha256$180000$odoHyUQGUEX6$PgrdnC931h9yzzXgwqASw483i+ki+4UR7HQDAM/HT0Y=	2020-06-21 09:45:05.566891+00	f	ism9			ism@ism.com	f	t	2020-06-21 09:44:49.755258+00	\N	\N	\N	f	\N	\N	\N			
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
4	4	1
5	4	3
9	6	1
10	8	1
11	9	1
12	10	1
13	11	1
14	12	1
15	13	1
16	14	1
17	15	1
18	16	1
19	17	1
20	18	1
21	19	1
22	20	1
23	21	1
24	22	1
25	23	1
26	24	1
27	25	1
28	26	1
29	27	1
30	28	1
31	29	1
\.


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 31, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.users_user_id_seq', 29, true);


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: alshamelah_admin
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
135	6	128
136	6	129
137	6	130
138	6	131
139	6	132
140	6	133
141	6	105
142	6	106
143	6	107
144	6	108
145	6	109
146	6	110
147	6	111
148	6	112
149	6	113
150	6	114
151	6	115
152	6	116
153	6	117
154	6	118
155	6	119
156	6	120
157	6	121
158	6	122
159	6	123
160	6	124
161	6	125
162	6	126
163	6	127
164	8	128
165	8	129
166	8	130
167	8	131
168	8	132
169	8	133
170	8	105
171	8	106
172	8	107
173	8	108
174	8	109
175	8	110
176	8	111
177	8	112
178	8	113
179	8	114
75	4	139
76	4	128
77	4	129
78	4	130
79	4	131
80	4	132
81	4	133
82	4	105
83	4	106
84	4	107
85	4	108
86	4	109
87	4	110
88	4	111
89	4	112
90	4	113
91	4	114
92	4	115
93	4	116
94	4	117
95	4	118
96	4	119
97	4	120
98	4	121
99	4	122
100	4	123
101	4	124
102	4	125
103	4	126
104	4	127
180	8	115
181	8	116
182	8	117
183	8	118
184	8	119
185	8	120
186	8	121
187	8	122
188	8	123
189	8	124
190	8	125
191	8	126
192	8	127
193	9	128
194	9	129
195	9	130
196	9	131
197	9	132
198	9	133
199	9	105
200	9	106
201	9	107
202	9	108
203	9	109
204	9	110
205	9	111
206	9	112
207	9	113
208	9	114
209	9	115
210	9	116
211	9	117
212	9	118
213	9	119
214	9	120
215	9	121
216	9	122
217	9	123
218	9	124
219	9	125
220	9	126
221	9	127
222	10	128
223	10	129
224	10	130
225	10	131
226	10	132
227	10	133
228	10	105
229	10	106
230	10	107
231	10	108
232	10	109
233	10	110
234	10	111
235	10	112
236	10	113
237	10	114
238	10	115
239	10	116
240	10	117
241	10	118
242	10	119
243	10	120
244	10	121
245	10	122
246	10	123
247	10	124
248	10	125
249	10	126
250	10	127
251	11	128
252	11	129
253	11	130
254	11	131
255	11	132
256	11	133
257	11	105
258	11	106
259	11	107
260	11	108
261	11	109
262	11	110
263	11	111
264	11	112
265	11	113
266	11	114
267	11	115
268	11	116
269	11	117
270	11	118
271	11	119
272	11	120
273	11	121
274	11	122
275	11	123
276	11	124
277	11	125
278	11	126
279	11	127
280	12	128
281	12	129
282	12	130
283	12	131
284	12	132
285	12	133
286	12	105
287	12	106
288	12	107
289	12	108
290	12	109
291	12	110
292	12	111
293	12	112
294	12	113
295	12	114
296	12	115
297	12	116
298	12	117
299	12	118
300	12	119
301	12	120
302	12	121
303	12	122
304	12	123
305	12	124
306	12	125
307	12	126
308	12	127
309	13	128
310	13	129
311	13	130
312	13	131
313	13	132
314	13	133
315	13	105
316	13	106
317	13	107
318	13	108
319	13	109
320	13	110
321	13	111
322	13	112
323	13	113
324	13	114
325	13	115
326	13	116
327	13	117
328	13	118
329	13	119
330	13	120
331	13	121
332	13	122
333	13	123
334	13	124
335	13	125
336	13	126
337	13	127
338	14	128
339	14	129
340	14	130
341	14	131
342	14	132
343	14	133
344	14	105
345	14	106
346	14	107
347	14	108
348	14	109
349	14	110
350	14	111
351	14	112
352	14	113
353	14	114
354	14	115
355	14	116
356	14	117
357	14	118
358	14	119
359	14	120
360	14	121
361	14	122
362	14	123
363	14	124
364	14	125
365	14	126
366	14	127
367	15	128
368	15	129
369	15	130
370	15	131
371	15	132
372	15	133
373	15	105
374	15	106
375	15	107
376	15	108
377	15	109
378	15	110
379	15	111
380	15	112
381	15	113
382	15	114
383	15	115
384	15	116
385	15	117
386	15	118
387	15	119
388	15	120
389	15	121
390	15	122
391	15	123
392	15	124
393	15	125
394	15	126
395	15	127
396	16	128
397	16	129
398	16	130
399	16	131
400	16	132
401	16	133
402	16	105
403	16	106
404	16	107
405	16	108
406	16	109
407	16	110
408	16	111
409	16	112
410	16	113
411	16	114
412	16	115
413	16	116
414	16	117
415	16	118
416	16	119
417	16	120
418	16	121
419	16	122
420	16	123
421	16	124
422	16	125
423	16	126
424	16	127
425	17	128
426	17	129
427	17	130
428	17	131
429	17	132
430	17	133
431	17	105
432	17	106
433	17	107
434	17	108
435	17	109
436	17	110
437	17	111
438	17	112
439	17	113
440	17	114
441	17	115
442	17	116
443	17	117
444	17	118
445	17	119
446	17	120
447	17	121
448	17	122
449	17	123
450	17	124
451	17	125
452	17	126
453	17	127
454	18	128
455	18	129
456	18	130
457	18	131
458	18	132
459	18	133
460	18	105
461	18	106
462	18	107
463	18	108
464	18	109
465	18	110
466	18	111
467	18	112
468	18	113
469	18	114
470	18	115
471	18	116
472	18	117
473	18	118
474	18	119
475	18	120
476	18	121
477	18	122
478	18	123
479	18	124
480	18	125
481	18	126
482	18	127
483	19	128
484	19	129
485	19	130
486	19	131
487	19	132
488	19	133
489	19	105
490	19	106
491	19	107
492	19	108
493	19	109
494	19	110
495	19	111
496	19	112
497	19	113
498	19	114
499	19	115
500	19	116
501	19	117
502	19	118
503	19	119
504	19	120
505	19	121
506	19	122
507	19	123
508	19	124
509	19	125
510	19	126
511	19	127
512	20	128
513	20	129
514	20	130
515	20	131
516	20	132
517	20	133
518	20	105
519	20	106
520	20	107
521	20	108
522	20	109
523	20	110
524	20	111
525	20	112
526	20	113
527	20	114
528	20	115
529	20	116
530	20	117
531	20	118
532	20	119
533	20	120
534	20	121
535	20	122
536	20	123
537	20	124
538	20	125
539	20	126
540	20	127
541	21	128
542	21	129
543	21	130
544	21	131
545	21	132
546	21	133
547	21	105
548	21	106
549	21	107
550	21	108
551	21	109
552	21	110
553	21	111
554	21	112
555	21	113
556	21	114
557	21	115
558	21	116
559	21	117
560	21	118
561	21	119
562	21	120
563	21	121
564	21	122
565	21	123
566	21	124
567	21	125
568	21	126
569	21	127
570	22	128
571	22	129
572	22	130
573	22	131
574	22	132
575	22	133
576	22	105
577	22	106
578	22	107
579	22	108
580	22	109
581	22	110
582	22	111
583	22	112
584	22	113
585	22	114
586	22	115
587	22	116
588	22	117
589	22	118
590	22	119
591	22	120
592	22	121
593	22	122
594	22	123
595	22	124
596	22	125
597	22	126
598	22	127
599	23	128
600	23	129
601	23	130
602	23	131
603	23	132
604	23	133
605	23	105
606	23	106
607	23	107
608	23	108
609	23	109
610	23	110
611	23	111
612	23	112
613	23	113
614	23	114
615	23	115
616	23	116
617	23	117
618	23	118
619	23	119
620	23	120
621	23	121
622	23	122
623	23	123
624	23	124
625	23	125
626	23	126
627	23	127
628	24	128
629	24	129
630	24	130
631	24	131
632	24	132
633	24	133
634	24	105
635	24	106
636	24	107
637	24	108
638	24	109
639	24	110
640	24	111
641	24	112
642	24	113
643	24	114
644	24	115
645	24	116
646	24	117
647	24	118
648	24	119
649	24	120
650	24	121
651	24	122
652	24	123
653	24	124
654	24	125
655	24	126
656	24	127
657	25	128
658	25	129
659	25	130
660	25	131
661	25	132
662	25	133
663	25	105
664	25	106
665	25	107
666	25	108
667	25	109
668	25	110
669	25	111
670	25	112
671	25	113
672	25	114
673	25	115
674	25	116
675	25	117
676	25	118
677	25	119
678	25	120
679	25	121
680	25	122
681	25	123
682	25	124
683	25	125
684	25	126
685	25	127
686	26	128
687	26	129
688	26	130
689	26	131
690	26	132
691	26	133
692	26	105
693	26	106
694	26	107
695	26	108
696	26	109
697	26	110
698	26	111
699	26	112
700	26	113
701	26	114
702	26	115
703	26	116
704	26	117
705	26	118
706	26	119
707	26	120
708	26	121
709	26	122
710	26	123
711	26	124
712	26	125
713	26	126
714	26	127
715	27	128
716	27	129
717	27	130
718	27	131
719	27	132
720	27	133
721	27	105
722	27	106
723	27	107
724	27	108
725	27	109
726	27	110
727	27	111
728	27	112
729	27	113
730	27	114
731	27	115
732	27	116
733	27	117
734	27	118
735	27	119
736	27	120
737	27	121
738	27	122
739	27	123
740	27	124
741	27	125
742	27	126
743	27	127
744	28	128
745	28	129
746	28	130
747	28	131
748	28	132
749	28	133
750	28	105
751	28	106
752	28	107
753	28	108
754	28	109
755	28	110
756	28	111
757	28	112
758	28	113
759	28	114
760	28	115
761	28	116
762	28	117
763	28	118
764	28	119
765	28	120
766	28	121
767	28	122
768	28	123
769	28	124
770	28	125
771	28	126
772	28	127
773	29	128
774	29	129
775	29	130
776	29	131
777	29	132
778	29	133
779	29	105
780	29	106
781	29	107
782	29	108
783	29	109
784	29	110
785	29	111
786	29	112
787	29	113
788	29	114
789	29	115
790	29	116
791	29	117
792	29	118
793	29	119
794	29	120
795	29	121
796	29	122
797	29	123
798	29	124
799	29	125
800	29	126
801	29	127
\.


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alshamelah_admin
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 801, true);


--
-- Data for Name: geocode_settings; Type: TABLE DATA; Schema: tiger; Owner: alshamelah_admin
--

COPY tiger.geocode_settings  FROM stdin;
\.


--
-- Data for Name: pagc_gaz; Type: TABLE DATA; Schema: tiger; Owner: alshamelah_admin
--

COPY tiger.pagc_gaz  FROM stdin;
\.


--
-- Data for Name: pagc_lex; Type: TABLE DATA; Schema: tiger; Owner: alshamelah_admin
--

COPY tiger.pagc_lex  FROM stdin;
\.


--
-- Data for Name: pagc_rules; Type: TABLE DATA; Schema: tiger; Owner: alshamelah_admin
--

COPY tiger.pagc_rules  FROM stdin;
\.


--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: alshamelah_admin
--

COPY topology.topology  FROM stdin;
\.


--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: alshamelah_admin
--

COPY topology.layer  FROM stdin;
\.


--
-- Name: account_emailaddress_email_key; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_email_key UNIQUE (email);


--
-- Name: account_emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_pkey PRIMARY KEY (id);


--
-- Name: account_emailconfirmation_key_key; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_key_key UNIQUE (key);


--
-- Name: account_emailconfirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: books_book_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_book
    ADD CONSTRAINT books_book_pkey PRIMARY KEY (id);


--
-- Name: books_bookcomment_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookcomment
    ADD CONSTRAINT books_bookcomment_pkey PRIMARY KEY (id);


--
-- Name: books_bookhighlight_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookhighlight
    ADD CONSTRAINT books_bookhighlight_pkey PRIMARY KEY (id);


--
-- Name: books_bookmark_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookmark
    ADD CONSTRAINT books_bookmark_pkey PRIMARY KEY (id);


--
-- Name: books_bookmedia_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookmedia
    ADD CONSTRAINT books_bookmedia_pkey PRIMARY KEY (id);


--
-- Name: books_bookrating_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookrating
    ADD CONSTRAINT books_bookrating_pkey PRIMARY KEY (id);


--
-- Name: books_bookreview_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookreview
    ADD CONSTRAINT books_bookreview_pkey PRIMARY KEY (id);


--
-- Name: categories_category_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.categories_category
    ADD CONSTRAINT categories_category_pkey PRIMARY KEY (id);


--
-- Name: categories_subcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.categories_subcategory
    ADD CONSTRAINT categories_subcategory_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount_provider_uid_fc810c6e_uniq; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_provider_uid_fc810c6e_uniq UNIQUE (provider, uid);


--
-- Name: socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq UNIQUE (socialapp_id, site_id);


--
-- Name: socialaccount_socialapp_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.socialaccount_socialapp
    ADD CONSTRAINT socialaccount_socialapp_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialapp_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp_sites_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq UNIQUE (app_id, account_id);


--
-- Name: socialaccount_socialtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_pkey PRIMARY KEY (id);


--
-- Name: users_otp_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.users_otp
    ADD CONSTRAINT users_otp_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups_user_id_group_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_group_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions_user_id_permission_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_permission_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: account_emailaddress_email_03be32b2_like; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX account_emailaddress_email_03be32b2_like ON public.account_emailaddress USING btree (email varchar_pattern_ops);


--
-- Name: account_emailaddress_user_id_2c513194; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX account_emailaddress_user_id_2c513194 ON public.account_emailaddress USING btree (user_id);


--
-- Name: account_emailconfirmation_email_address_id_5b7f8c58; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX account_emailconfirmation_email_address_id_5b7f8c58 ON public.account_emailconfirmation USING btree (email_address_id);


--
-- Name: account_emailconfirmation_key_f43612bd_like; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX account_emailconfirmation_key_f43612bd_like ON public.account_emailconfirmation USING btree (key varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: books_book_category_id_406d8649; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX books_book_category_id_406d8649 ON public.books_book USING btree (category_id);


--
-- Name: books_book_sub_category_id_66d18b10; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX books_book_sub_category_id_66d18b10 ON public.books_book USING btree (sub_category_id);


--
-- Name: books_book_uploader_id_04cff269; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX books_book_uploader_id_04cff269 ON public.books_book USING btree (uploader_id);


--
-- Name: books_bookcomment_book_id_7126326d; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX books_bookcomment_book_id_7126326d ON public.books_bookcomment USING btree (book_id);


--
-- Name: books_bookcomment_user_id_d01950a9; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX books_bookcomment_user_id_d01950a9 ON public.books_bookcomment USING btree (user_id);


--
-- Name: books_bookhighlight_book_id_e72716de; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX books_bookhighlight_book_id_e72716de ON public.books_bookhighlight USING btree (book_id);


--
-- Name: books_bookhighlight_user_id_024f05a0; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX books_bookhighlight_user_id_024f05a0 ON public.books_bookhighlight USING btree (user_id);


--
-- Name: books_bookmark_book_id_8c8d1eb9; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX books_bookmark_book_id_8c8d1eb9 ON public.books_bookmark USING btree (book_id);


--
-- Name: books_bookmark_user_id_9e892ce0; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX books_bookmark_user_id_9e892ce0 ON public.books_bookmark USING btree (user_id);


--
-- Name: books_bookmedia_book_id_326676c7; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX books_bookmedia_book_id_326676c7 ON public.books_bookmedia USING btree (book_id);


--
-- Name: books_bookmedia_user_id_3fe6f13b; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX books_bookmedia_user_id_3fe6f13b ON public.books_bookmedia USING btree (user_id);


--
-- Name: books_bookrating_book_id_4b490330; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX books_bookrating_book_id_4b490330 ON public.books_bookrating USING btree (book_id);


--
-- Name: books_bookrating_user_id_c9383f7b; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX books_bookrating_user_id_c9383f7b ON public.books_bookrating USING btree (user_id);


--
-- Name: books_bookreview_book_id_9c5fb3f1; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX books_bookreview_book_id_9c5fb3f1 ON public.books_bookreview USING btree (book_id);


--
-- Name: books_bookreview_user_id_a5746a0f; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX books_bookreview_user_id_a5746a0f ON public.books_bookreview USING btree (user_id);


--
-- Name: categories_subcategory_category_id_58b66954; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX categories_subcategory_category_id_58b66954 ON public.categories_subcategory USING btree (category_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: socialaccount_socialaccount_user_id_8146e70c; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX socialaccount_socialaccount_user_id_8146e70c ON public.socialaccount_socialaccount USING btree (user_id);


--
-- Name: socialaccount_socialapp_sites_site_id_2579dee5; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX socialaccount_socialapp_sites_site_id_2579dee5 ON public.socialaccount_socialapp_sites USING btree (site_id);


--
-- Name: socialaccount_socialapp_sites_socialapp_id_97fb6e7d; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX socialaccount_socialapp_sites_socialapp_id_97fb6e7d ON public.socialaccount_socialapp_sites USING btree (socialapp_id);


--
-- Name: socialaccount_socialtoken_account_id_951f210e; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX socialaccount_socialtoken_account_id_951f210e ON public.socialaccount_socialtoken USING btree (account_id);


--
-- Name: socialaccount_socialtoken_app_id_636a42d7; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX socialaccount_socialtoken_app_id_636a42d7 ON public.socialaccount_socialtoken USING btree (app_id);


--
-- Name: users_otp_user_id_cd09ace3; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX users_otp_user_id_cd09ace3 ON public.users_otp USING btree (user_id);


--
-- Name: users_user_groups_group_id_9afc8d0e; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX users_user_groups_group_id_9afc8d0e ON public.users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_user_id_5f6f5a90; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX users_user_groups_user_id_5f6f5a90 ON public.users_user_groups USING btree (user_id);


--
-- Name: users_user_user_permissions_permission_id_0b93982e; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX users_user_user_permissions_permission_id_0b93982e ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_user_id_20aca447; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX users_user_user_permissions_user_id_20aca447 ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: alshamelah_admin
--

CREATE INDEX users_user_username_06e46fe6_like ON public.users_user USING btree (username varchar_pattern_ops);


--
-- Name: account_emailaddress_user_id_2c513194_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_user_id_2c513194_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_emailconfirm_email_address_id_5b7f8c58_fk_account_e; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirm_email_address_id_5b7f8c58_fk_account_e FOREIGN KEY (email_address_id) REFERENCES public.account_emailaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token_user_id_35299eff_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_book_category_id_406d8649_fk_categories_category_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_book
    ADD CONSTRAINT books_book_category_id_406d8649_fk_categories_category_id FOREIGN KEY (category_id) REFERENCES public.categories_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_book_sub_category_id_66d18b10_fk_categorie; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_book
    ADD CONSTRAINT books_book_sub_category_id_66d18b10_fk_categorie FOREIGN KEY (sub_category_id) REFERENCES public.categories_subcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_book_uploader_id_04cff269_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_book
    ADD CONSTRAINT books_book_uploader_id_04cff269_fk_users_user_id FOREIGN KEY (uploader_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_bookcomment_book_id_7126326d_fk_books_book_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookcomment
    ADD CONSTRAINT books_bookcomment_book_id_7126326d_fk_books_book_id FOREIGN KEY (book_id) REFERENCES public.books_book(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_bookcomment_user_id_d01950a9_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookcomment
    ADD CONSTRAINT books_bookcomment_user_id_d01950a9_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_bookhighlight_book_id_e72716de_fk_books_book_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookhighlight
    ADD CONSTRAINT books_bookhighlight_book_id_e72716de_fk_books_book_id FOREIGN KEY (book_id) REFERENCES public.books_book(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_bookhighlight_user_id_024f05a0_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookhighlight
    ADD CONSTRAINT books_bookhighlight_user_id_024f05a0_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_bookmark_book_id_8c8d1eb9_fk_books_book_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookmark
    ADD CONSTRAINT books_bookmark_book_id_8c8d1eb9_fk_books_book_id FOREIGN KEY (book_id) REFERENCES public.books_book(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_bookmark_user_id_9e892ce0_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookmark
    ADD CONSTRAINT books_bookmark_user_id_9e892ce0_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_bookmedia_book_id_326676c7_fk_books_book_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookmedia
    ADD CONSTRAINT books_bookmedia_book_id_326676c7_fk_books_book_id FOREIGN KEY (book_id) REFERENCES public.books_book(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_bookmedia_user_id_3fe6f13b_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookmedia
    ADD CONSTRAINT books_bookmedia_user_id_3fe6f13b_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_bookrating_book_id_4b490330_fk_books_book_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookrating
    ADD CONSTRAINT books_bookrating_book_id_4b490330_fk_books_book_id FOREIGN KEY (book_id) REFERENCES public.books_book(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_bookrating_user_id_c9383f7b_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookrating
    ADD CONSTRAINT books_bookrating_user_id_c9383f7b_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_bookreview_book_id_9c5fb3f1_fk_books_book_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookreview
    ADD CONSTRAINT books_bookreview_book_id_9c5fb3f1_fk_books_book_id FOREIGN KEY (book_id) REFERENCES public.books_book(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_bookreview_user_id_a5746a0f_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.books_bookreview
    ADD CONSTRAINT books_bookreview_user_id_a5746a0f_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: categories_subcatego_category_id_58b66954_fk_categorie; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.categories_subcategory
    ADD CONSTRAINT categories_subcatego_category_id_58b66954_fk_categorie FOREIGN KEY (category_id) REFERENCES public.categories_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_c564eba6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_social_account_id_951f210e_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_account_id_951f210e_fk_socialacc FOREIGN KEY (account_id) REFERENCES public.socialaccount_socialaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_social_app_id_636a42d7_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_app_id_636a42d7_fk_socialacc FOREIGN KEY (app_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_social_site_id_2579dee5_fk_django_si; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_site_id_2579dee5_fk_django_si FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc FOREIGN KEY (socialapp_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_otp_user_id_cd09ace3_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.users_otp
    ADD CONSTRAINT users_otp_user_id_cd09ace3_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups_user_id_5f6f5a90_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_perm_permission_id_0b93982e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_perm_permission_id_0b93982e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions_user_id_20aca447_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: alshamelah_admin
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: alshamelah_admin
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM alshamelah_admin;
GRANT ALL ON SCHEMA public TO alshamelah_admin;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

